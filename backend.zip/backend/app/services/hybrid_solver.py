from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
import uuid
import numpy as np
# Temporarily disable quantum imports for deployment
# from qiskit import QuantumCircuit
# from qiskit_aer import Aer
# from qiskit import execute
# from qiskit.algorithms import QAOA
# from qiskit.algorithms.optimizers import COBYLA
# from qiskit.primitives import Sampler
# from qiskit_optimization import QuadraticProgram
# from qiskit_optimization.algorithms import MinimumEigenOptimizer

from .classical_solver import ClassicalVRPSolver

# Forward declaration for Order
class Order:
    pass

# Forward declaration for Vehicle
class Vehicle:
    pass

class HybridVRPSolver:
    """Hybrid Vehicle Routing Problem solver combining classical and quantum optimization"""

    def __init__(self):
        self.classical_solver = ClassicalVRPSolver()
        # self.backend = Aer.get_backend('qasm_simulator')  # Temporarily disabled

    async def solve(
        self, 
        orders: List[Order], 
        vehicles: List[Vehicle], 
        constraints: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Solve VRP using hybrid classical + quantum optimization"""
        
        # Step 1: Get baseline classical solution
        print("Running classical baseline optimization...")
        classical_solution = await self.classical_solver.solve(orders, vehicles, constraints)
        
        # Step 2: Identify inefficient route segments for quantum improvement
        inefficient_segments = self._identify_inefficient_segments(classical_solution)
        
        if not inefficient_segments:
            print("No inefficient segments found, returning classical solution")
            return classical_solution

        # Step 3: Apply quantum optimization to selected segments
        print(f"Applying quantum optimization to {len(inefficient_segments)} segments...")
        improved_routes = []
        total_improvement = 0
        
        for route in classical_solution['routes']:
            improved_route = await self._improve_route_with_quantum(route, inefficient_segments)
            improved_routes.append(improved_route)
            
            # Calculate improvement for this route
            route_improvement = self._calculate_route_improvement(route, improved_route)
            total_improvement += route_improvement

        # Step 4: Recalculate metrics
        total_distance = sum(route['total_distance'] for route in improved_routes)
        total_time = sum(route['total_time'] for route in improved_routes)
        total_cost = self._calculate_total_cost(improved_routes, vehicles)
        
        # Calculate overall improvement percentage
        classical_distance = classical_solution['total_distance']
        improvement_percentage = ((classical_distance - total_distance) / classical_distance) * 100 if classical_distance > 0 else 0

        return {
            "solver_type": "hybrid",
            "routes": improved_routes,
            "total_distance": total_distance,
            "total_time": total_time,
            "total_cost": total_cost,
            "vehicles_used": len(improved_routes),
            "orders_assigned": len(orders),
            "improvement_percentage": improvement_percentage,
            "classical_baseline": classical_solution,
            "quantum_segments_optimized": len(inefficient_segments),
            "solver_parameters": {
                "classical_solver": "OR-Tools",
                "quantum_solver": "QAOA",
                "max_segment_size": 10,
                "quantum_shots": 1000
            }
        }

    def _identify_inefficient_segments(self, solution: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Identify route segments that could benefit from quantum optimization"""
        inefficient_segments = []
        
        for route in solution['routes']:
            stops = route['stops']
            
            # Look for segments with 6-10 stops (good for quantum optimization)
            if len(stops) >= 6 and len(stops) <= 10:
                # Calculate segment efficiency (distance per stop)
                total_distance = route['total_distance']
                efficiency = total_distance / len(stops)
                
                # If efficiency is below threshold, mark for quantum optimization
                if efficiency > 15:  # More than 15 km per stop is inefficient
                    inefficient_segments.append({
                        "route_index": solution['routes'].index(route),
                        "stops": stops,
                        "efficiency": efficiency,
                        "original_distance": total_distance
                    })
            elif len(stops) > 10:
                # For longer routes, identify sub-segments
                for i in range(0, len(stops) - 5, 6):  # Sliding window of 6-10 stops
                    segment_size = min(10, len(stops) - i)
                    segment_stops = stops[i:i + segment_size]
                    
                    # Estimate segment distance (simplified)
                    segment_distance = self._estimate_segment_distance(segment_stops)
                    efficiency = segment_distance / len(segment_stops)
                    
                    if efficiency > 15:
                        inefficient_segments.append({
                            "route_index": solution['routes'].index(route),
                            "segment_start": i,
                            "stops": segment_stops,
                            "efficiency": efficiency,
                            "original_distance": segment_distance
                        })

        # Limit to top 3 most inefficient segments to keep quantum computation manageable
        inefficient_segments.sort(key=lambda x: x['efficiency'], reverse=True)
        return inefficient_segments[:3]

    def _estimate_segment_distance(self, stops: List[Dict[str, Any]]) -> float:
        """Estimate distance for a segment of stops"""
        if len(stops) < 2:
            return 0
        
        total_distance = 0
        for i in range(len(stops) - 1):
            if stops[i]['latitude'] and stops[i]['longitude'] and stops[i+1]['latitude'] and stops[i+1]['longitude']:
                # Simple Euclidean distance (in km)
                lat1, lon1 = float(stops[i]['latitude']), float(stops[i]['longitude'])
                lat2, lon2 = float(stops[i+1]['latitude']), float(stops[i+1]['longitude'])
                
                # Haversine distance
                R = 6371  # Earth radius in km
                lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
                dlat = lat2 - lat1
                dlon = lon2 - lon1
                a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
                c = 2 * np.arcsin(np.sqrt(a))
                distance = R * c
                total_distance += distance
        
        return total_distance

    async def _improve_route_with_quantum(
        self, 
        route: Dict[str, Any], 
        inefficient_segments: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Improve a route using quantum optimization for specific segments"""
        
        improved_route = route.copy()
        improved_stops = route['stops'].copy()
        
        # Find segments that belong to this route
        route_segments = [seg for seg in inefficient_segments if seg.get('route_index') == 0 or seg.get('route_index') == route.get('route_index', 0)]
        
        for segment in route_segments:
            if 'segment_start' in segment:
                # This is a sub-segment
                start_idx = segment['segment_start']
                end_idx = start_idx + len(segment['stops'])
                segment_stops = segment['stops']
                
                # Apply quantum optimization to this segment
                optimized_segment = await self._optimize_segment_quantum(segment_stops)
                
                # Replace the segment in the route
                improved_stops[start_idx:end_idx] = optimized_segment
            else:
                # This is the entire route
                optimized_stops = await self._optimize_segment_quantum(segment['stops'])
                improved_stops = optimized_stops
        
        # Recalculate route metrics
        improved_route['stops'] = improved_stops
        improved_route['total_distance'] = self._estimate_segment_distance(improved_stops)
        improved_route['total_time'] = improved_route['total_distance'] / 50 * 60  # Assuming 50 km/h
        improved_route['total_cost'] = improved_route['total_distance'] * 0.5
        
        # Update stop times
        current_time = 0
        for stop in improved_stops:
            stop['estimated_arrival'] = datetime.now() + timedelta(hours=8, minutes=current_time)
            current_time += stop.get('service_time', 10) + 5  # Add travel time
            stop['estimated_departure'] = datetime.now() + timedelta(hours=8, minutes=current_time)
        
        return improved_route

    async def _optimize_segment_quantum(self, stops: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Optimize a segment of stops using QAOA"""
        
        if len(stops) <= 2:
            return stops  # No optimization needed for 1-2 stops
        
        try:
            # Create distance matrix for the segment
            n_stops = len(stops)
            distance_matrix = np.zeros((n_stops, n_stops))
            
            for i in range(n_stops):
                for j in range(n_stops):
                    if i != j:
                        lat1, lon1 = float(stops[i]['latitude']), float(stops[i]['longitude'])
                        lat2, lon2 = float(stops[j]['latitude']), float(stops[j]['longitude'])
                        
                        # Haversine distance
                        R = 6371  # Earth radius in km
                        lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
                        dlat = lat2 - lat1
                        dlon = lon2 - lon1
                        a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
                        c = 2 * np.arcsin(np.sqrt(a))
                        distance = R * c
                        distance_matrix[i][j] = distance
            
            # Create QUBO formulation for TSP (Traveling Salesman Problem)
            qubo = self._create_tsp_qubo(distance_matrix)
            
            # Solve using QAOA
            optimizer = QAOA(
                optimizer=COBYLA(maxiter=100),
                reps=2,
                sampler=Sampler()
            )
            
            qp = QuadraticProgram()
            qp.from_ising(qubo[0], qubo[1])
            
            quantum_optimizer = MinimumEigenOptimizer(optimizer)
            result = quantum_optimizer.solve(qp)
            
            # Extract solution
            solution_order = self._extract_tsp_solution(result, n_stops)
            
            # Reorder stops according to quantum solution
            optimized_stops = [stops[i] for i in solution_order]
            
            return optimized_stops
            
        except Exception as e:
            print(f"Quantum optimization failed: {e}. Using original order.")
            return stops

    def _create_tsp_qubo(self, distance_matrix: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Create QUBO formulation for Traveling Salesman Problem"""
        n = distance_matrix.shape[0]
        
        # Simplified QUBO for TSP
        # This is a basic implementation - in production, you'd use a more sophisticated formulation
        linear = np.zeros(n * n)
        quadratic = np.zeros((n * n, n * n))
        
        # Penalty for visiting each city exactly once
        penalty = 1000
        
        for i in range(n):
            for pos in range(n):
                idx = i * n + pos
                linear[idx] = -penalty
                
                # Add quadratic terms for constraints
                for j in range(n):
                    if i != j:
                        for pos2 in range(n):
                            if pos != pos2:
                                idx2 = j * n + pos2
                                quadratic[idx, idx2] = 2 * penalty
                
                # Add distance terms
                for j in range(n):
                    if i != j:
                        for pos in range(n):
                            for pos2 in range(n):
                                if pos == (pos2 + 1) % n or pos2 == (pos + 1) % n:
                                    idx = i * n + pos
                                    idx2 = j * n + pos2
                                    quadratic[idx, idx2] += distance_matrix[i][j]
        
        return linear, quadratic

    def _extract_tsp_solution(self, result, n_cities: int) -> List[int]:
        """Extract city order from QAOA solution"""
        # This is a simplified extraction - in production, you'd use proper decoding
        x = result.x
        
        # Find the most likely position for each city
        solution_order = []
        used_positions = set()
        
        for city in range(n_cities):
            best_pos = 0
            best_value = 0
            
            for pos in range(n_cities):
                idx = city * n_cities + pos
                if idx < len(x) and pos not in used_positions:
                    if x[idx] > best_value:
                        best_value = x[idx]
                        best_pos = pos
            
            solution_order.append(best_pos)
            used_positions.add(best_pos)
        
        # Convert positions to city order
        city_order = [0] * n_cities
        for city, pos in enumerate(solution_order):
            city_order[pos] = city
        
        return city_order

    def _calculate_route_improvement(self, original_route: Dict[str, Any], improved_route: Dict[str, Any]) -> float:
        """Calculate improvement percentage for a route"""
        original_distance = original_route['total_distance']
        improved_distance = improved_route['total_distance']
        
        if original_distance == 0:
            return 0
        
        improvement = ((original_distance - improved_distance) / original_distance) * 100
        return improvement

    def _calculate_total_cost(self, routes: List[Dict[str, Any]], vehicles: List[Vehicle]) -> float:
        """Calculate total cost of all routes"""
        total_cost = 0
        
        for route in routes:
            # Distance cost (₹5 per km)
            distance_cost = route['total_distance'] * 5
            
            # Time cost (₹100 per hour)
            time_cost = (route['total_time'] / 60) * 100
            
            total_cost += distance_cost + time_cost
        
        return total_cost
