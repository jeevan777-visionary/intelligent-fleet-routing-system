from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import uuid

from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
import numpy as np

from ..models.orders import Order
from ..models.fleet import Vehicle

class ClassicalVRPSolver:
    """Classical Vehicle Routing Problem solver using Google OR-Tools"""

    def __init__(self):
        self.manager = None
        self.routing = None
        self.distance_matrix = None
        self.time_matrix = None

    async def solve(
        self, 
        orders: List[Order], 
        vehicles: List[Vehicle], 
        constraints: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Solve VRP using classical OR-Tools solver"""
        
        # Prepare data
        data = self._prepare_data(orders, vehicles, constraints)
        
        # Create routing model
        self.manager = pywrapcp.RoutingIndexManager(
            len(data['distance_matrix']),
            len(vehicles),
            data['depot']
        )
        
        self.routing = pywrapcp.RoutingModel(self.manager)

        # Register transit callback
        transit_callback_index = self.routing.RegisterTransitCallback(
            lambda from_index, to_index: self._distance_callback(
                from_index, to_index, data
            )
        )

        # Define cost of each arc
        self.routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

        # Add capacity constraint
        self._add_capacity_constraint(data)

        # Add time window constraint
        self._add_time_window_constraint(data)

        # Add maximum route duration constraint
        if constraints.get('max_route_duration'):
            self._add_max_duration_constraint(data, constraints['max_route_duration'])

        # Add maximum distance constraint
        if constraints.get('max_route_distance'):
            self._add_max_distance_constraint(data, constraints['max_route_distance'])

        # Setting first solution heuristic
        search_parameters = pywrapcp.DefaultRoutingSearchParameters()
        search_parameters.first_solution_strategy = (
            routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
        )
        search_parameters.local_search_metaheuristic = (
            routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
        )
        search_parameters.time_limit.FromSeconds(30)

        # Solve the problem
        solution = self.routing.SolveWithParameters(search_parameters)

        if not solution:
            raise ValueError("No solution found")

        # Extract solution
        routes = self._extract_solution(solution, data, orders, vehicles)
        
        # Calculate metrics
        total_distance = sum(route['total_distance'] for route in routes)
        total_time = sum(route['total_time'] for route in routes)
        total_cost = self._calculate_total_cost(routes, vehicles)

        return {
            "solver_type": "classical",
            "routes": routes,
            "total_distance": total_distance,
            "total_time": total_time,
            "total_cost": total_cost,
            "vehicles_used": len(routes),
            "orders_assigned": len(orders),
            "improvement_percentage": 0,  # Baseline, no improvement
            "solver_parameters": {
                "first_solution_strategy": "PATH_CHEAPEST_ARC",
                "local_search_metaheuristic": "GUIDED_LOCAL_SEARCH",
                "time_limit": 30
            }
        }

    def _prepare_data(self, orders: List[Order], vehicles: List[Vehicle], constraints: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare data for OR-Tools solver"""
        
        # Create distance and time matrices
        locations = []
        
        # Add depot (assuming first depot as start point)
        depot_location = (19.0760, 72.8777)  # Mumbai coordinates as default
        locations.append(depot_location)
        
        # Add order locations
        for order in orders:
            if order.pickup_latitude and order.pickup_longitude:
                locations.append((float(order.pickup_latitude), float(order.pickup_longitude)))
            else:
                # Generate random coordinates for demo
                locations.append((
                    depot_location[0] + np.random.uniform(-0.1, 0.1),
                    depot_location[1] + np.random.uniform(-0.1, 0.1)
                ))

        # Calculate distance matrix (simplified - using Euclidean distance)
        n_locations = len(locations)
        distance_matrix = []
        time_matrix = []

        for i in range(n_locations):
            distance_row = []
            time_row = []
            for j in range(n_locations):
                # Calculate distance (in km)
                lat1, lon1 = locations[i]
                lat2, lon2 = locations[j]
                distance = self._haversine_distance(lat1, lon1, lat2, lon2)
                distance_row.append(int(distance * 1000))  # Convert to meters
                
                # Calculate time (assuming average speed of 50 km/h)
                time = distance / 50 * 60  # Convert to minutes
                time_row.append(int(time))
            
            distance_matrix.append(distance_row)
            time_matrix.append(time_row)

        # Vehicle capacities
        vehicle_capacities = []
        for vehicle in vehicles:
            capacity = int(vehicle.capacity_weight or 1000)  # Default 1000 kg
            vehicle_capacities.append(capacity)

        # Order demands
        demands = [0]  # Depot has no demand
        for order in orders:
            demand = int(order.weight or 100)  # Default 100 kg
            demands.append(demand)

        # Time windows (in minutes from start of day)
        time_windows = []
        # Depot time window (6:00 AM to 8:00 PM)
        time_windows.append((360, 720))
        
        for order in orders:
            if order.time_window_start and order.time_window_end:
                start_minutes = order.time_window_start.hour * 60 + order.time_window_start.minute
                end_minutes = order.time_window_end.hour * 60 + order.time_window_end.minute
                time_windows.append((start_minutes, end_minutes))
            else:
                # Default time window (8:00 AM to 6:00 PM)
                time_windows.append((480, 660))

        return {
            'distance_matrix': distance_matrix,
            'time_matrix': time_matrix,
            'vehicle_capacities': vehicle_capacities,
            'demands': demands,
            'time_windows': time_windows,
            'depot': 0,
            'orders': orders,
            'vehicles': vehicles,
            'locations': locations
        }

    def _haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate haversine distance between two points"""
        R = 6371  # Earth radius in kilometers
        
        lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
        c = 2 * np.arcsin(np.sqrt(a))
        
        return R * c

    def _distance_callback(self, from_index: int, to_index: int, data: Dict[str, Any]) -> int:
        """Distance callback for routing"""
        from_node = self.manager.IndexToNode(from_index)
        to_node = self.manager.IndexToNode(to_index)
        return data['distance_matrix'][from_node][to_node]

    def _add_capacity_constraint(self, data: Dict[str, Any]):
        """Add vehicle capacity constraint"""
        capacity_callback_index = self.routing.RegisterUnaryTransitCallback(
            lambda from_index: self._capacity_callback(from_index, data)
        )
        self.routing.AddDimensionWithVehicleCapacity(
            capacity_callback_index,
            0,  # null capacity slack
            data['vehicle_capacities'],  # vehicle maximum capacities
            True,  # start cumul to zero
            'Capacity'
        )

    def _add_time_window_constraint(self, data: Dict[str, Any]):
        """Add time window constraint"""
        time_callback_index = self.routing.RegisterTransitCallback(
            lambda from_index, to_index: self._time_callback(from_index, to_index, data)
        )
        self.routing.AddDimension(
            time_callback_index,
            30,  # allow waiting time
            30,  # maximum time per vehicle
            False,  # don't force start cumul to zero
            'Time'
        )
        time_dimension = self.routing.GetDimensionOrDie('Time')
        
        # Add time window constraints
        for location_idx, time_window in enumerate(data['time_windows']):
            index = self.manager.NodeToIndex(location_idx)
            time_dimension.CumulVar(index).SetRange(time_window[0], time_window[1])

    def _add_max_duration_constraint(self, data: Dict[str, Any], max_duration: int):
        """Add maximum route duration constraint"""
        time_dimension = self.routing.GetDimensionOrDie('Time')
        for vehicle_id in range(len(data['vehicles'])):
            time_dimension.CumulVar(self.routing.End(vehicle_id)).SetMax(max_duration)

    def _add_max_distance_constraint(self, data: Dict[str, Any], max_distance: int):
        """Add maximum route distance constraint"""
        distance_callback_index = self.routing.RegisterTransitCallback(
            lambda from_index, to_index: self._distance_callback(from_index, to_index, data)
        )
        self.routing.AddDimension(
            distance_callback_index,
            0,  # slack
            max_distance,  # maximum distance per vehicle
            True,  # start cumul to zero
            'Distance'
        )
        distance_dimension = self.routing.GetDimensionOrDie('Distance')
        for vehicle_id in range(len(data['vehicles'])):
            distance_dimension.CumulVar(self.routing.End(vehicle_id)).SetMax(max_distance)

    def _capacity_callback(self, from_index: int, data: Dict[str, Any]) -> int:
        """Capacity callback for routing"""
        from_node = self.manager.IndexToNode(from_index)
        return data['demands'][from_node]

    def _time_callback(self, from_index: int, to_index: int, data: Dict[str, Any]) -> int:
        """Time callback for routing"""
        from_node = self.manager.IndexToNode(from_index)
        to_node = self.manager.IndexToNode(to_index)
        return data['time_matrix'][from_node][to_node]

    def _extract_solution(
        self, 
        solution, 
        data: Dict[str, Any], 
        orders: List[Order], 
        vehicles: List[Vehicle]
    ) -> List[Dict[str, Any]]:
        """Extract solution from OR-Tools result"""
        routes = []
        
        for vehicle_id in range(len(data['vehicles'])):
            index = self.routing.Start(vehicle_id)
            route_stops = []
            total_distance = 0
            total_time = 0
            
            while not self.routing.IsEnd(index):
                node_index = self.manager.IndexToNode(index)
                
                if node_index != 0:  # Not depot
                    order_idx = node_index - 1
                    if order_idx < len(orders):
                        order = orders[order_idx]
                        
                        # Calculate arrival and departure times
                        time_dimension = self.routing.GetDimensionOrDie('Time')
                        arrival_time = time_dimension.CumulVar(index).Min()
                        departure_time = arrival_time + 10  # 10 minutes service time
                        
                        stop_data = {
                            "order_id": order.id,
                            "sequence": len(route_stops) + 1,
                            "type": "delivery",
                            "address": order.delivery_address,
                            "latitude": float(order.delivery_latitude) if order.delivery_latitude else None,
                            "longitude": float(order.delivery_longitude) if order.delivery_longitude else None,
                            "estimated_arrival": datetime.now() + timedelta(minutes=arrival_time),
                            "estimated_departure": datetime.now() + timedelta(minutes=departure_time),
                            "service_time": 10
                        }
                        route_stops.append(stop_data)
                
                index = solution.Value(self.routing.NextVar(index))
            
            if route_stops:  # Only add routes with stops
                vehicle = vehicles[vehicle_id]
                route_data = {
                    "vehicle_id": vehicle.id,
                    "driver_id": None,  # Will be assigned separately
                    "stops": route_stops,
                    "total_distance": total_distance,
                    "total_time": total_time,
                    "total_cost": total_distance * 0.5,  # Simplified cost calculation
                    "start_time": datetime.now() + timedelta(hours=8),  # 8 AM start
                    "end_time": datetime.now() + timedelta(hours=8, minutes=total_time)
                }
                routes.append(route_data)
        
        return routes

    def _calculate_total_cost(self, routes: List[Dict[str, Any]], vehicles: List[Vehicle]) -> float:
        """Calculate total cost of all routes"""
        total_cost = 0
        
        for route in routes:
            # Distance cost (₹5 per km)
            distance_cost = route['total_distance'] * 5
            
            # Time cost (₹100 per hour)
            time_cost = (route['total_time'] / 60) * 100
            
            total_cost += distance_cost + time_cost
        
        return total_cost
