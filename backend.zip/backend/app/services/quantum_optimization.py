"""
Hybrid Quantum-Classical Optimization Service

This service combines classical OR-Tools optimization with quantum-inspired algorithms
to solve complex Vehicle Routing Problems (VRP).
"""

import numpy as np
from typing import List, Dict, Tuple, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import logging
from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
from qiskit import QuantumCircuit, transpile
from qiskit_algorithms import QAOA
from qiskit.primitives import Sampler
from qiskit_optimization import QuadraticProgram
from qiskit_optimization.converters import QuadraticProgramToQubo

logger = logging.getLogger(__name__)

@dataclass
class Location:
    """Represents a delivery location"""
    id: str
    name: str
    latitude: float
    longitude: float
    demand: float = 0.0
    time_window: Tuple[int, int] = (0, 1440)  # minutes from midnight
    service_time: int = 15  # minutes

@dataclass
class Vehicle:
    """Represents a delivery vehicle"""
    id: str
    capacity: float
    start_location: Location
    end_location: Location
    max_distance: float = 500.0  # km
    max_time: int = 480  # minutes (8 hours)

@dataclass
class Route:
    """Represents an optimized route"""
    vehicle_id: str
    stops: List[str]
    distance: float
    time: int
    load: float
    quantum_score: float = 0.0

class HybridQuantumOptimizer:
    """
    Hybrid Quantum-Classical optimizer for Vehicle Routing Problems
    """
    
    def __init__(self):
        self.classical_time = 0.0
        self.quantum_time = 0.0
        self.improvement = 0.0
        
    def optimize_vrp(self, 
                    vehicles: List[Vehicle], 
                    locations: List[Location],
                    use_quantum: bool = True) -> Dict[str, Any]:
        """
        Optimize Vehicle Routing Problem using hybrid approach
        
        Args:
            vehicles: List of available vehicles
            locations: List of delivery locations (including depot)
            use_quantum: Whether to apply quantum enhancement
            
        Returns:
            Dictionary containing optimization results
        """
        start_time = datetime.now()
        
        # Stage 1: Classical Optimization with OR-Tools
        logger.info("Starting classical optimization...")
        classical_routes = self._classical_optimization(vehicles, locations)
        classical_time = (datetime.now() - start_time).total_seconds()
        
        if not use_quantum:
            return {
                'routes': classical_routes,
                'classical_time': classical_time,
                'quantum_time': 0,
                'improvement': 0.0,
                'algorithm': 'Classical OR-Tools'
            }
        
        # Stage 2: Quantum Enhancement
        logger.info("Starting quantum enhancement...")
        quantum_start = datetime.now()
        
        # Identify inefficient route segments for quantum optimization
        inefficient_segments = self._identify_inefficient_segments(classical_routes)
        
        # Apply QAOA to optimize selected segments
        enhanced_routes = self._quantum_enhancement(
            classical_routes, 
            inefficient_segments, 
            locations
        )
        
        quantum_time = (datetime.now() - quantum_start).total_seconds()
        total_time = (datetime.now() - start_time).total_seconds()
        
        # Calculate improvement
        improvement = self._calculate_improvement(classical_routes, enhanced_routes)
        
        logger.info(f"Optimization completed in {total_time:.2f}s")
        logger.info(f"Improvement: {improvement:.2f}%")
        
        return {
            'routes': enhanced_routes,
            'classical_time': classical_time,
            'quantum_time': quantum_time,
            'total_time': total_time,
            'improvement': improvement,
            'algorithm': 'Hybrid Quantum-Classical',
            'inefficient_segments': len(inefficient_segments)
        }
    
    def _classical_optimization(self, 
                               vehicles: List[Vehicle], 
                               locations: List[Location]) -> List[Route]:
        """
        Classical optimization using Google OR-Tools
        """
        # Create distance matrix
        distance_matrix = self._create_distance_matrix(locations)
        
        # Create OR-Tools routing model
        manager = pywrapcp.RoutingIndexManager(
            len(distance_matrix), 
            len(vehicles), 
            0  # depot is at index 0
        )
        routing = pywrapcp.RoutingModel(manager)
        
        # Define cost of each arc
        def distance_callback(from_index, to_index):
            from_node = manager.IndexToNode(from_index)
            to_node = manager.IndexToNode(to_index)
            return int(distance_matrix[from_node][to_node] * 1000)  # Convert to meters
        
        transit_callback_index = routing.RegisterTransitCallback(distance_callback)
        routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)
        
        # Add capacity constraint
        def demand_callback(from_index):
            from_node = manager.IndexToNode(from_index)
            return int(locations[from_node].demand * 100)  # Convert to centi-units
        
        demand_callback_index = routing.RegisterUnaryTransitCallback(demand_callback)
        routing.AddDimensionWithVehicleCapacity(
            demand_callback_index,
            0,  # null capacity slack
            [int(v.capacity * 100) for v in vehicles],  # vehicle capacities
            True,  # start cumul to zero
            'Capacity'
        )
        
        # Add time window constraint
        time_callback_index = routing.RegisterTransitCallback(distance_callback)
        routing.AddDimension(
            time_callback_index,
            30,  # allow waiting time
            1440,  # maximum time per vehicle
            False,  # don't force start cumul to zero
            'Time'
        )
        time_dimension = routing.GetDimensionOrDie('Time')
        
        # Add time window constraints
        for location_idx, location in enumerate(locations):
            if location_idx == 0:  # Skip depot
                continue
            index = routing.NodeToIndex(location_idx)
            time_dimension.CumulVar(index).SetRange(
                location.time_window[0], 
                location.time_window[1]
            )
        
        # Set search parameters
        search_parameters = pywrapcp.DefaultRoutingSearchParameters()
        search_parameters.first_solution_strategy = (
            routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
        )
        search_parameters.local_search_metaheuristic = (
            routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
        )
        search_parameters.time_limit.FromSeconds(30)
        
        # Solve the problem
        solution = routing.SolveWithParameters(search_parameters)
        
        if not solution:
            logger.warning("No solution found")
            return []
        
        # Extract routes
        routes = []
        for vehicle_idx, vehicle in enumerate(vehicles):
            index = routing.Start(vehicle_idx)
            route_stops = []
            route_distance = 0
            route_load = 0
            
            while not routing.IsEnd(index):
                node_index = manager.IndexToNode(index)
                route_stops.append(locations[node_index].id)
                route_load += locations[node_index].demand
                
                previous_index = index
                index = solution.Value(routing.NextVar(index))
                route_distance += routing.GetArcCostForVehicle(previous_index, index, vehicle_idx)
            
            # Add depot at the end
            route_stops.append(locations[0].id)
            
            routes.append(Route(
                vehicle_id=vehicle.id,
                stops=route_stops,
                distance=route_distance / 1000,  # Convert back to km
                time=solution.Min(time_dimension.CumulVar(routing.End(vehicle_idx))),
                load=route_load,
                quantum_score=0.0
            ))
        
        return routes
    
    def _create_distance_matrix(self, locations: List[Location]) -> np.ndarray:
        """
        Create distance matrix using Haversine formula
        """
        n = len(locations)
        matrix = np.zeros((n, n))
        
        for i in range(n):
            for j in range(n):
                if i != j:
                    matrix[i][j] = self._haversine_distance(
                        locations[i].latitude, locations[i].longitude,
                        locations[j].latitude, locations[j].longitude
                    )
        
        return matrix
    
    def _haversine_distance(self, lat1: float, lon1: float, 
                           lat2: float, lon2: float) -> float:
        """
        Calculate Haversine distance between two points
        """
        R = 6371  # Earth's radius in kilometers
        
        lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
        c = 2 * np.arcsin(np.sqrt(a))
        
        return R * c
    
    def _identify_inefficient_segments(self, routes: List[Route]) -> List[Dict]:
        """
        Identify route segments that could benefit from quantum optimization
        """
        inefficient_segments = []
        
        for route in routes:
            if len(route.stops) <= 3:  # Skip very short routes
                continue
            
            # Look for segments with high distance-to-stops ratio
            segments = []
            for i in range(len(route.stops) - 1):
                segment_length = route.distance / (len(route.stops) - 1)
                if segment_length > 5.0:  # Segments longer than 5km
                    segments.append({
                        'route_id': route.vehicle_id,
                        'segment_index': i,
                        'stops': route.stops[i:i+3],  # Consider 3-stop segments
                        'length': segment_length
                    })
            
            # Select top segments for quantum optimization
            segments.sort(key=lambda x: x['length'], reverse=True)
            inefficient_segments.extend(segments[:2])  # Top 2 segments per route
        
        return inefficient_segments
    
    def _quantum_enhancement(self, 
                           classical_routes: List[Route],
                           inefficient_segments: List[Dict],
                           locations: List[Location]) -> List[Route]:
        """
        Apply quantum enhancement to inefficient segments
        """
        enhanced_routes = classical_routes.copy()
        
        for segment in inefficient_segments:
            try:
                # Create QUBO problem for segment optimization
                qubo = self._create_segment_qubo(segment, locations)
                
                # Solve using QAOA
                optimized_order = self._solve_qubo_qaoa(qubo)
                
                # Apply optimization to route
                enhanced_routes = self._apply_segment_optimization(
                    enhanced_routes, segment, optimized_order
                )
                
            except Exception as e:
                logger.warning(f"Quantum optimization failed for segment {segment}: {e}")
                # Fall back to classical solution
                continue
        
        return enhanced_routes
    
    def _create_segment_qubo(self, segment: Dict, locations: List[Location]) -> QuadraticProgram:
        """
        Create QUBO formulation for segment optimization
        """
        # Extract segment locations
        segment_location_ids = segment['stops']
        segment_locations = [loc for loc in locations if loc.id in segment_location_ids]
        
        n = len(segment_locations)
        qubo = QuadraticProgram()
        
        # Binary variables for visitation order
        for i in range(n):
            for j in range(n):
                qubo.binary_var(f'x_{i}_{j}')
        
        # Add constraints: each location visited exactly once
        for i in range(n):
            qubo.linear_constraint(
                linear={f'x_{i}_{j}': 1 for j in range(n)},
                sense='==',
                rhs=1,
                name=f'visit_once_{i}'
            )
        
        for j in range(n):
            qubo.linear_constraint(
                linear={f'x_{i}_{j}': 1 for i in range(n)},
                sense='==',
                rhs=1,
                name=f'position_once_{j}'
            )
        
        # Objective: minimize total distance
        distance_matrix = self._create_distance_matrix(segment_locations)
        
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    if j != k:
                        distance = distance_matrix[j][k]
                        qubo.quadratic_coefficient(f'x_{i}_{j}', f'x_{(i+1)%n}_{k}', distance)
        
        return qubo
    
    def _solve_qubo_qaoa(self, qubo: QuadraticProgram) -> List[int]:
        """
        Solve QUBO using QAOA algorithm
        """
        # Convert QUBO to Ising Hamiltonian
        converter = QuadraticProgramToQubo()
        qubo_conv = converter.convert(qubo)
        
        # Create QAOA instance
        qaoa = QAOA(sampler=Sampler(), optimizer=None, reps=2)
        
        # Solve
        result = qaoa.compute_minimum_eigenvalue(qubo_conv.to_ising()[0])
        
        # Extract solution
        solution = result.best_measurement()
        
        # Convert binary solution to order
        n = int(np.sqrt(len(solution['bitstring'])))
        order = []
        
        for i in range(n):
            for j in range(n):
                if solution['bitstring'][i * n + j] == '1':
                    order.append(j)
                    break
        
        return order
    
    def _apply_segment_optimization(self, 
                                 routes: List[Route],
                                 segment: Dict,
                                 optimized_order: List[int]) -> List[Route]:
        """
        Apply quantum-optimized order to the route
        """
        route_idx = next(i for i, r in enumerate(routes) if r.vehicle_id == segment['route_id'])
        route = routes[route_idx]
        
        # Reorder segment stops
        segment_stops = segment['stops']
        reordered_stops = [segment_stops[i] for i in optimized_order]
        
        # Replace segment in route
        start_idx = route.stops.index(segment_stops[0])
        end_idx = route.stops.index(segment_stops[-1]) + 1
        
        new_stops = (
            route.stops[:start_idx] + 
            reordered_stops + 
            route.stops[end_idx:]
        )
        
        # Update route
        route.stops = new_stops
        route.quantum_score = 0.85  # Mock quantum score
        
        return routes
    
    def _calculate_improvement(self, 
                             classical_routes: List[Route], 
                             enhanced_routes: List[Route]) -> float:
        """
        Calculate improvement percentage between classical and enhanced routes
        """
        classical_distance = sum(r.distance for r in classical_routes)
        enhanced_distance = sum(r.distance for r in enhanced_routes)
        
        if classical_distance == 0:
            return 0.0
        
        improvement = ((classical_distance - enhanced_distance) / classical_distance) * 100
        return max(0, improvement)  # Ensure non-negative

# Example usage and testing
if __name__ == "__main__":
    # Create sample data
    depot = Location("depot", "Central Depot", 18.5204, 73.8567)
    locations = [
        depot,
        Location("c1", "Customer 1", 18.5314, 73.8446, demand=10),
        Location("c2", "Customer 2", 18.5167, 73.8511, demand=15),
        Location("c3", "Customer 3", 18.5333, 73.8933, demand=8),
        Location("c4", "Customer 4", 18.5417, 73.9056, demand=12),
    ]
    
    vehicles = [
        Vehicle("v1", 30, depot, depot),
        Vehicle("v2", 25, depot, depot),
    ]
    
    # Run optimization
    optimizer = HybridQuantumOptimizer()
    result = optimizer.optimize_vrp(vehicles, locations, use_quantum=True)
    
    print("Optimization Results:")
    print(f"Algorithm: {result['algorithm']}")
    print(f"Classical Time: {result['classical_time']:.2f}s")
    print(f"Quantum Time: {result['quantum_time']:.2f}s")
    print(f"Improvement: {result['improvement']:.2f}%")
    print(f"Routes: {len(result['routes'])}")
    
    for route in result['routes']:
        print(f"  {route.vehicle_id}: {route.stops} ({route.distance:.2f}km)")
