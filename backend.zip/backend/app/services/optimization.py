from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid
from sqlalchemy.orm import Session

from ..models.routing import OptimizationRun, Route, RouteStop, ConstraintsProfile
from ..models.orders import Order
from ..models.fleet import Vehicle, Driver
from .classical_solver import ClassicalVRPSolver
from .hybrid_solver import HybridVRPSolver

class OptimizationService:
    def __init__(self, db: Session):
        self.db = db
        self.classical_solver = ClassicalVRPSolver()
        self.hybrid_solver = HybridVRPSolver()

    async def run_optimization(
        self,
        organization_id: uuid.UUID,
        solver_type: str,
        constraints_profile_id: uuid.UUID,
        name: Optional[str] = None
    ) -> OptimizationRun:
        """Run route optimization using specified solver type"""
        
        # Create optimization run record
        optimization_run = OptimizationRun(
            organization_id=organization_id,
            name=name or f"{solver_type.title()} Optimization",
            solver_type=solver_type,
            constraints_profile_id=constraints_profile_id,
            status="running",
            started_at=datetime.utcnow()
        )
        self.db.add(optimization_run)
        self.db.commit()
        self.db.refresh(optimization_run)

        try:
            # Get data for optimization
            orders = self._get_pending_orders(organization_id)
            vehicles = self._get_available_vehicles(organization_id)
            constraints = self._get_constraints(constraints_profile_id)

            if not orders:
                raise ValueError("No pending orders found")
            if not vehicles:
                raise ValueError("No available vehicles found")

            # Run optimization
            if solver_type == "classical":
                results = await self.classical_solver.solve(orders, vehicles, constraints)
            elif solver_type == "hybrid":
                results = await self.hybrid_solver.solve(orders, vehicles, constraints)
            else:
                raise ValueError(f"Unknown solver type: {solver_type}")

            # Save results
            await self._save_optimization_results(optimization_run, results)

            # Update run status
            optimization_run.status = "completed"
            optimization_run.completed_at = datetime.utcnow()
            optimization_run.total_distance = results.get("total_distance", 0)
            optimization_run.total_time = results.get("total_time", 0)
            optimization_run.total_cost = results.get("total_cost", 0)
            optimization_run.vehicles_used = len(results.get("routes", []))
            optimization_run.orders_assigned = len(orders)
            optimization_run.improvement_percentage = results.get("improvement_percentage", 0)
            optimization_run.results = results

            self.db.commit()
            return optimization_run

        except Exception as e:
            optimization_run.status = "failed"
            optimization_run.completed_at = datetime.utcnow()
            optimization_run.results = {"error": str(e)}
            self.db.commit()
            raise e

    def _get_pending_orders(self, organization_id: uuid.UUID) -> List[Order]:
        """Get all pending orders for optimization"""
        return self.db.query(Order).filter(
            Order.organization_id == organization_id,
            Order.status == "pending"
        ).all()

    def _get_available_vehicles(self, organization_id: uuid.UUID) -> List[Vehicle]:
        """Get all available vehicles for optimization"""
        return self.db.query(Vehicle).filter(
            Vehicle.organization_id == organization_id,
            Vehicle.is_active == True,
            Vehicle.maintenance_status == "operational"
        ).all()

    def _get_constraints(self, constraints_profile_id: uuid.UUID) -> Dict[str, Any]:
        """Get optimization constraints profile"""
        profile = self.db.query(ConstraintsProfile).filter(
            ConstraintsProfile.id == constraints_profile_id
        ).first()
        
        if not profile:
            raise ValueError("Constraints profile not found")

        return {
            "max_route_duration": profile.max_route_duration,
            "max_route_distance": profile.max_route_distance,
            "max_stops_per_route": profile.max_stops_per_route,
            "vehicle_capacity_constraints": profile.vehicle_capacity_constraints or {},
            "time_window_constraints": profile.time_window_constraints or {},
            "driver_constraints": profile.driver_constraints or {}
        }

    async def _save_optimization_results(self, optimization_run: OptimizationRun, results: Dict[str, Any]):
        """Save optimization results to database"""
        routes_data = results.get("routes", [])
        
        for i, route_data in enumerate(routes_data):
            # Create route
            route = Route(
                optimization_run_id=optimization_run.id,
                organization_id=optimization_run.organization_id,
                vehicle_id=route_data.get("vehicle_id"),
                driver_id=route_data.get("driver_id"),
                route_number=i + 1,
                start_time=route_data.get("start_time"),
                end_time=route_data.get("end_time"),
                total_distance=route_data.get("total_distance", 0),
                total_time=route_data.get("total_time", 0),
                total_cost=route_data.get("total_cost", 0),
                status="planned"
            )
            self.db.add(route)
            self.db.flush()

            # Create route stops
            stops_data = route_data.get("stops", [])
            for stop_data in stops_data:
                stop = RouteStop(
                    route_id=route.id,
                    order_id=stop_data.get("order_id"),
                    stop_sequence=stop_data.get("sequence"),
                    stop_type=stop_data.get("type"),
                    address=stop_data.get("address"),
                    latitude=stop_data.get("latitude"),
                    longitude=stop_data.get("longitude"),
                    estimated_arrival=stop_data.get("estimated_arrival"),
                    estimated_departure=stop_data.get("estimated_departure"),
                    service_time=stop_data.get("service_time"),
                    status="pending"
                )
                self.db.add(stop)

        # Update order statuses
        assigned_order_ids = [
            stop.get("order_id") 
            for route in routes_data 
            for stop in route.get("stops", [])
            if stop.get("order_id")
        ]
        
        self.db.query(Order).filter(
            Order.id.in_(assigned_order_ids)
        ).update({"status": "assigned"}, synchronize_session=False)
