from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any
import uuid
import logging
from datetime import datetime

# Import schemas
from schemas.fleet import VehicleBase, VehicleCreate, VehicleUpdate, Vehicle, DriverBase, DriverCreate, Driver, DepotBase, DepotCreate, DepotResponse, DriverResponse
from schemas.orders import OrderBase, OrderCreate, OrderUpdate, Order, OrderResponse
from schemas.routing import RouteBase, RouteCreate, RouteUpdate, Route, RouteResponse, ConstraintsProfileBase, ConstraintsProfileCreate, ConstraintsProfileResponse, OptimizationRunBase, OptimizationRunCreate, OptimizationRunResponse
from schemas.events import EventBase, EventCreate, EventResponse, MetricBase, MetricCreate, MetricResponse

router = APIRouter()
logger = logging.getLogger(__name__)

# Mock data storage
vehicles_db = []
orders_db = []
events_db = []
metrics_db = []

@router.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now()}

# Dashboard metrics
@router.get("/dashboard/metrics")
async def get_dashboard_metrics():
    return {
        "totalOrders": len(orders_db),
        "activeVehicles": len([v for v in vehicles_db if v.get("status") == "active"]),
        "completedDeliveries": len([o for o in orders_db if o.get("status") == "delivered"]),
        "averageDeliveryTime": "1.5 days",
        "distanceReduction": "35%",
        "costSavings": "₹1,250/day"
    }

# Fleet vehicles
@router.get("/fleet/vehicles")
async def get_vehicles():
    if not vehicles_db:
        # Return mock data if no vehicles
        return [
            {
                "id": "1",
                "name": "MH12 AB 1234",
                "driver": "Raj Kumar",
                "lat": 17.3850,
                "lng": 78.4867,
                "status": "active",
                "type": "Bike"
            },
            {
                "id": "2", 
                "name": "MH12 CD 5678",
                "driver": "Sarah Johnson",
                "lat": 17.3950,
                "lng": 78.4967,
                "status": "active",
                "type": "Van"
            },
            {
                "id": "3",
                "name": "MH12 EF 9012", 
                "driver": "Mike Chen",
                "lat": 17.4050,
                "lng": 78.5067,
                "status": "active",
                "type": "Bike"
            }
        ]
    return vehicles_db

@router.post("/fleet/vehicles")
async def create_vehicle(vehicle: VehicleCreate):
    new_vehicle = {
        "id": str(uuid.uuid4()),
        **vehicle.dict(),
        "status": "active",
        "created_at": datetime.now()
    }
    vehicles_db.append(new_vehicle)
    return new_vehicle

# Orders
@router.get("/orders")
async def get_orders():
    return orders_db

@router.post("/orders")
async def create_order(order: OrderCreate):
    new_order = {
        "id": str(uuid.uuid4()),
        **order.dict(),
        "status": "pending",
        "created_at": datetime.now()
    }
    orders_db.append(new_order)
    return new_order

@router.put("/orders/{order_id}")
async def update_order(order_id: str, order_update: OrderUpdate):
    for order in orders_db:
        if order["id"] == order_id:
            order.update(order_update.dict(exclude_unset=True))
            return order
    raise HTTPException(status_code=404, detail="Order not found")

# Optimization
@router.post("/optimize/run")
async def run_optimization(request: Dict[str, Any]):
    try:
        # Import quantum optimization service
        from app.services.quantum_optimization import HybridQuantumOptimizer, Location, Vehicle
        
        # Create sample data for demonstration
        depot = Location("depot", "Central Depot", 18.5204, 73.8567)
        locations = [
            depot,
            Location("c1", "Customer A", 18.5314, 73.8446, demand=10),
            Location("c2", "Customer B", 18.5167, 73.8511, demand=15),
            Location("c3", "Customer C", 18.5333, 73.8933, demand=8),
            Location("c4", "Customer D", 18.5417, 73.9056, demand=12),
            Location("c5", "Customer E", 18.5250, 73.8700, demand=18),
            Location("c6", "Customer F", 18.5400, 73.8800, demand=7),
        ]
        
        vehicles = [
            Vehicle("VH001", 30, depot, depot),
            Vehicle("VH002", 25, depot, depot),
        ]
        
        # Run optimization
        optimizer = HybridQuantumOptimizer()
        use_quantum = request.get('algorithm', 'hybrid') == 'hybrid'
        result = optimizer.optimize_vrp(vehicles, locations, use_quantum=use_quantum)
        
        # Format response
        routes = []
        for route in result['routes']:
            route_data = {
                "vehicle": route.vehicle_id,
                "driver": "Raj Kumar" if route.vehicle_id == "VH001" else "Sarah Johnson",
                "optimized_route": route.stops,
                "distance": f"{route.distance:.1f} km",
                "time": f"{route.time} min",
                "quantum_score": route.quantum_score
            }
            routes.append(route_data)
        
        return {
            "optimization_id": str(uuid.uuid4()),
            "algorithm": result['algorithm'],
            "qubits_used": 8 if use_quantum else 0,
            "classical_time": f"{result['classical_time']:.1f} seconds",
            "quantum_time": f"{result['quantum_time']:.1f} seconds" if use_quantum else "0 seconds",
            "improvement": f"{result['improvement']:.1f}% faster",
            "routes": routes,
            "savings": {
                "distance": f"{result['improvement'] * 0.8:.1f}%",
                "time": f"{result['improvement']:.1f}%", 
                "fuel": f"{result['improvement'] * 0.6:.1f}%",
                "cost": f"₹{result['improvement'] * 50:.0f}/day"
            },
            "status": "completed",
            "created_at": datetime.now()
        }
        
    except Exception as e:
        logger.error(f"Optimization failed: {e}")
        raise HTTPException(status_code=500, detail=f"Optimization failed: {str(e)}")

# Events
@router.get("/events")
async def get_events():
    return events_db

@router.post("/events")
async def create_event(event: EventCreate):
    new_event = {
        "id": str(uuid.uuid4()),
        **event.dict(),
        "created_at": datetime.now()
    }
    events_db.append(new_event)
    return new_event

# Metrics
@router.get("/metrics")
async def get_metrics():
    return metrics_db

@router.post("/metrics")
async def create_metric(metric: MetricCreate):
    new_metric = {
        "id": str(uuid.uuid4()),
        **metric.dict(),
        "timestamp": datetime.now()
    }
    metrics_db.append(new_metric)
    return new_metric
