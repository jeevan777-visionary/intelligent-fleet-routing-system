from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any
import uuid
from datetime import datetime

# Import schemas
from app.schemas.fleet import VehicleBase, VehicleCreate, VehicleUpdate, Vehicle, DriverBase, DriverCreate, Driver, DepotBase, DepotCreate, DepotResponse, DriverResponse
from app.schemas.orders import OrderBase, OrderCreate, OrderUpdate, Order, OrderResponse
from app.schemas.routing import RouteBase, RouteCreate, RouteUpdate, Route, RouteResponse, ConstraintsProfileBase, ConstraintsProfileCreate, ConstraintsProfileResponse, OptimizationRunBase, OptimizationRunCreate, OptimizationRunResponse
from app.schemas.events import EventBase, EventCreate, EventResponse, MetricBase, MetricCreate, MetricResponse

router = APIRouter()

# Mock data storage
vehicles_db = []
orders_db = []
events_db = []
metrics_db = []

@router.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now()}

# Dashboard metrics
@router.get("/dashboard/metrics")
async def get_dashboard_metrics():
    return {
        "totalOrders": len(orders_db),
        "activeVehicles": len([v for v in vehicles_db if v.get("status") == "active"]),
        "completedDeliveries": len([o for o in orders_db if o.get("status") == "delivered"]),
        "averageDeliveryTime": "1.5 days",
        "distanceReduction": "35%",
        "costSavings": "₹1,250/day"
    }

# Fleet vehicles
@router.get("/fleet/vehicles")
async def get_vehicles():
    if not vehicles_db:
        # Return mock data if no vehicles
        return [
            {
                "id": "1",
                "name": "MH12 AB 1234",
                "driver": "Raj Kumar",
                "lat": 17.3850,
                "lng": 78.4867,
                "status": "active",
                "type": "Bike"
            },
            {
                "id": "2", 
                "name": "MH12 CD 5678",
                "driver": "Sarah Johnson",
                "lat": 17.3950,
                "lng": 78.4967,
                "status": "active",
                "type": "Van"
            },
            {
                "id": "3",
                "name": "MH12 EF 9012", 
                "driver": "Mike Chen",
                "lat": 17.4050,
                "lng": 78.5067,
                "status": "active",
                "type": "Bike"
            }
        ]
    return vehicles_db

@router.post("/fleet/vehicles")
async def create_vehicle(vehicle: VehicleCreate):
    new_vehicle = {
        "id": str(uuid.uuid4()),
        **vehicle.dict(),
        "status": "active",
        "created_at": datetime.now()
    }
    vehicles_db.append(new_vehicle)
    return new_vehicle

# Orders
@router.get("/orders")
async def get_orders():
    return orders_db

@router.post("/orders")
async def create_order(order: OrderCreate):
    new_order = {
        "id": str(uuid.uuid4()),
        **order.dict(),
        "status": "pending",
        "created_at": datetime.now()
    }
    orders_db.append(new_order)
    return new_order

@router.put("/orders/{order_id}")
async def update_order(order_id: str, order_update: OrderUpdate):
    for order in orders_db:
        if order["id"] == order_id:
            order.update(order_update.dict(exclude_unset=True))
            return order
    raise HTTPException(status_code=404, detail="Order not found")

# Optimization
@router.post("/optimize/run")
async def run_optimization(request: Dict[str, Any]):
    return {
        "optimization_id": str(uuid.uuid4()),
        "algorithm": "QAOA (Quantum Approximate Optimization Algorithm)",
        "qubits_used": 8,
        "classical_time": "180 seconds",
        "quantum_time": "45 seconds", 
        "improvement": "75% faster",
        "routes": [
            {
                "vehicle": "MH12 AB 1234",
                "driver": "Raj Kumar",
                "optimized_route": ["Depot", "Customer A", "Customer C", "Customer B", "Depot"],
                "distance": "12.5 km",
                "time": "45 mins",
                "quantum_score": 0.92
            }
        ],
        "savings": {
            "distance": "35%",
            "time": "50%", 
            "fuel": "28%",
            "cost": "₹1,250/day"
        },
        "status": "completed",
        "created_at": datetime.now()
    }

# Events
@router.get("/events")
async def get_events():
    return events_db

@router.post("/events")
async def create_event(event: EventCreate):
    new_event = {
        "id": str(uuid.uuid4()),
        **event.dict(),
        "created_at": datetime.now()
    }
    events_db.append(new_event)
    return new_event

# Metrics
@router.get("/metrics")
async def get_metrics():
    return metrics_db

@router.post("/metrics")
async def create_metric(metric: MetricCreate):
    new_metric = {
        "id": str(uuid.uuid4()),
        **metric.dict(),
        "timestamp": datetime.now()
    }
    metrics_db.append(new_metric)
    return new_metric
