from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime

class EventBase(BaseModel):
    type: str
    description: str

class EventCreate(EventBase):
    pass

class EventResponse(EventBase):
    id: str
    created_at: datetime

class MetricBase(BaseModel):
    name: str
    value: float
    unit: str

class MetricCreate(MetricBase):
    pass

class MetricResponse(MetricBase):
    id: str
    timestamp: datetime
