from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class OrderBase(BaseModel):
    customer: str
    pickup: str
    delivery: str
    priority: str = "medium"

class OrderCreate(OrderBase):
    pass

class OrderResponse(OrderBase):
    id: str

class OrderUpdate(BaseModel):
    status: Optional[str] = None
    vehicle: Optional[str] = None

class Order(OrderBase):
    id: str
    status: str
    estimatedDelivery: datetime
    vehicle: Optional[str] = None
    
    class Config:
        from_attributes = True
