from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime

class RouteBase(BaseModel):
    vehicle_id: str
    order_id: str
    start_location: Dict[str, float]
    end_location: Dict[str, float]
    waypoints: Optional[List[Dict[str, float]]] = []

class RouteCreate(RouteBase):
    pass

class RouteUpdate(BaseModel):
    status: Optional[str] = None
    progress: Optional[float] = None
    estimated_time: Optional[int] = None

class Route(RouteBase):
    id: str
    status: str
    progress: float
    estimated_time: int
    created_at: datetime
    updated_at: datetime

class RouteResponse(BaseModel):
    id: str
    vehicle_id: str
    order_id: str
    status: str
    progress: float
    estimated_time: int
    created_at: datetime

class ConstraintsProfileBase(BaseModel):
    name: str
    max_distance: float
    max_time: int
    vehicle_capacity: int
    priority_rules: Dict[str, Any]

class ConstraintsProfileCreate(ConstraintsProfileBase):
    pass

class ConstraintsProfileResponse(ConstraintsProfileBase):
    id: str
    created_at: datetime
    updated_at: datetime

class OptimizationRunBase(BaseModel):
    algorithm: str
    parameters: Dict[str, Any]
    constraints_profile_id: str

class OptimizationRunCreate(OptimizationRunBase):
    pass

class OptimizationRunResponse(OptimizationRunBase):
    id: str
    status: str
    results: Dict[str, Any]
    created_at: datetime
    completed_at: Optional[datetime] = None

class OptimizationRequest(BaseModel):
    type: str = "hybrid"
    vehicles: List[str] = []
    orders: List[str] = []

class RouteStop(BaseModel):
    order_id: str
    location: str
    estimated_time: str

class Route(BaseModel):
    vehicle_id: str
    driver: str
    stops: List[RouteStop]
    total_distance: float
    estimated_time: str

class OptimizationResult(BaseModel):
    run_id: str
    status: str
    type: str
    routes: List[Route]
    savings: Dict[str, Any]
    created_at: datetime
