from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class DepotBase(BaseModel):
    name: str
    address: str
    latitude: float
    longitude: float

class DepotCreate(DepotBase):
    pass

class DepotResponse(DepotBase):
    id: str

class VehicleBase(BaseModel):
    name: str
    driver: str
    status: str

class VehicleCreate(VehicleBase):
    license_plate: str
    capacity: float
    fuel_type: str

class VehicleUpdate(BaseModel):
    name: Optional[str] = None
    driver: Optional[str] = None
    status: Optional[str] = None

class VehicleResponse(VehicleBase):
    id: str
    location: dict
    speed: int
    fuel: int
    
    class Config:
        from_attributes = True

class DriverBase(BaseModel):
    name: str
    license_number: str
    phone: str

class DriverCreate(DriverBase):
    pass

class DriverResponse(DriverBase):
    id: str

class Driver(DriverBase):
    id: str
    status: str
    current_vehicle: Optional[str] = None
    
    class Config:
        from_attributes = True

class Vehicle(VehicleBase):
    id: str
    location: dict
    speed: int
    fuel: int
    
    class Config:
        from_attributes = True
