from sqlalchemy import Column, String, DateTime, Text, ForeignKey, Integer, Numeric, JSON, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from ..database import Base
import uuid

class ConstraintsProfile(Base):
    __tablename__ = "constraints_profiles"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    name = Column(String(255), nullable=False)
    max_route_duration = Column(Integer)  # minutes
    max_route_distance = Column(Integer)  # kilometers
    max_stops_per_route = Column(Integer)
    vehicle_capacity_constraints = Column(JSON)
    time_window_constraints = Column(JSON)
    driver_constraints = Column(JSON)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    organization = relationship("Organization")
    optimization_runs = relationship("OptimizationRun", back_populates="constraints_profile")

class OptimizationRun(Base):
    __tablename__ = "optimization_runs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    name = Column(String(255))
    solver_type = Column(String(50), nullable=False)  # 'classical', 'hybrid'
    constraints_profile_id = Column(UUID(as_uuid=True), ForeignKey("constraints_profiles.id"))
    status = Column(String(50), default="pending")
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    total_distance = Column(Numeric(10, 2))
    total_time = Column(Integer)  # minutes
    total_cost = Column(Numeric(10, 2))
    vehicles_used = Column(Integer)
    orders_assigned = Column(Integer)
    improvement_percentage = Column(Numeric(5, 2))
    solver_parameters = Column(JSON)
    results = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    organization = relationship("Organization", back_populates="optimization_runs")
    constraints_profile = relationship("ConstraintsProfile", back_populates="optimization_runs")
    routes = relationship("Route", back_populates="optimization_run")

class Route(Base):
    __tablename__ = "routes"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    optimization_run_id = Column(UUID(as_uuid=True), ForeignKey("optimization_runs.id"))
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    vehicle_id = Column(UUID(as_uuid=True), ForeignKey("vehicles.id"))
    driver_id = Column(UUID(as_uuid=True), ForeignKey("drivers.id"))
    route_number = Column(Integer, nullable=False)
    start_time = Column(DateTime(timezone=True))
    end_time = Column(DateTime(timezone=True))
    total_distance = Column(Numeric(10, 2))
    total_time = Column(Integer)  # minutes
    total_cost = Column(Numeric(10, 2))
    status = Column(String(50), default="planned")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    organization = relationship("Organization", back_populates="routes")
    optimization_run = relationship("OptimizationRun", back_populates="routes")
    vehicle = relationship("Vehicle", back_populates="routes")
    driver = relationship("Driver", back_populates="routes")
    route_stops = relationship("RouteStop", back_populates="route", order_by="RouteStop.stop_sequence")

class RouteStop(Base):
    __tablename__ = "route_stops"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    route_id = Column(UUID(as_uuid=True), ForeignKey("routes.id"))
    order_id = Column(UUID(as_uuid=True), ForeignKey("orders.id"))
    stop_sequence = Column(Integer, nullable=False)
    stop_type = Column(String(50), nullable=False)  # 'pickup', 'delivery', 'depot_start', 'depot_end'
    address = Column(Text, nullable=False)
    latitude = Column(Numeric(10, 8))
    longitude = Column(Numeric(11, 8))
    estimated_arrival = Column(DateTime(timezone=True))
    estimated_departure = Column(DateTime(timezone=True))
    actual_arrival = Column(DateTime(timezone=True))
    actual_departure = Column(DateTime(timezone=True))
    service_time = Column(Integer)  # minutes
    status = Column(String(50), default="pending")
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    route = relationship("Route", back_populates="route_stops")
    order = relationship("Order", back_populates="route_stops")
