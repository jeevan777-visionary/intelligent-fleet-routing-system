from sqlalchemy import Column, String, DateTime, Text, ForeignKey, Integer, Numeric, JSON, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from ..database import Base
import uuid

class Order(Base):
    __tablename__ = "orders"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    order_number = Column(String(100), unique=True, nullable=False)
    customer_name = Column(String(255))
    customer_phone = Column(String(20))
    pickup_address = Column(Text, nullable=False)
    delivery_address = Column(Text, nullable=False)
    pickup_latitude = Column(Numeric(10, 8))
    pickup_longitude = Column(Numeric(11, 8))
    delivery_latitude = Column(Numeric(10, 8))
    delivery_longitude = Column(Numeric(11, 8))
    weight = Column(Numeric(10, 2))
    volume = Column(Numeric(10, 2))
    priority = Column(String(50), default="normal")
    time_window_start = Column(DateTime(timezone=True))
    time_window_end = Column(DateTime(timezone=True))
    special_instructions = Column(Text)
    status = Column(String(50), default="pending")
    assigned_vehicle_id = Column(UUID(as_uuid=True), ForeignKey("vehicles.id"))
    assigned_driver_id = Column(UUID(as_uuid=True), ForeignKey("drivers.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    organization = relationship("Organization", back_populates="orders")
    assigned_vehicle = relationship("Vehicle")
    assigned_driver = relationship("Driver")
    route_stops = relationship("RouteStop", back_populates="order")
