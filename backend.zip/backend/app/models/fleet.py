from sqlalchemy import Column, String, Boolean, DateTime, Text, ForeignKey, Integer, Numeric, Date, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from ..database import Base
import uuid

class Depot(Base):
    __tablename__ = "depots"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    name = Column(String(255), nullable=False)
    address = Column(Text, nullable=False)
    latitude = Column(Numeric(10, 8))
    longitude = Column(Numeric(11, 8))
    operating_hours = Column(JSON)
    contact_info = Column(JSON)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    organization = relationship("Organization", back_populates="depots")
    vehicles = relationship("Vehicle", back_populates="depot")
    shifts = relationship("Shift", back_populates="depot")

class Vehicle(Base):
    __tablename__ = "vehicles"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    depot_id = Column(UUID(as_uuid=True), ForeignKey("depots.id"))
    license_plate = Column(String(20), unique=True, nullable=False)
    make = Column(String(100))
    model = Column(String(100))
    year = Column(Integer)
    vehicle_type = Column(String(50))
    capacity_weight = Column(Numeric(10, 2))
    capacity_volume = Column(Numeric(10, 2))
    fuel_type = Column(String(50))
    fuel_efficiency = Column(Numeric(8, 4))
    current_fuel_level = Column(Numeric(5, 2))
    maintenance_status = Column(String(50), default="operational")
    insurance_expiry = Column(Date)
    registration_expiry = Column(Date)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    organization = relationship("Organization", back_populates="vehicles")
    depot = relationship("Depot", back_populates="vehicles")
    shifts = relationship("Shift", back_populates="vehicle")
    routes = relationship("Route", back_populates="vehicle")

class Driver(Base):
    __tablename__ = "drivers"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    license_number = Column(String(50), unique=True)
    license_expiry = Column(Date)
    phone = Column(String(20))
    address = Column(Text)
    hire_date = Column(Date)
    status = Column(String(50), default="available")
    max_driving_hours = Column(Integer, default=8)
    certifications = Column(JSON)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    organization = relationship("Organization", back_populates="drivers")
    user = relationship("User")
    shifts = relationship("Shift", back_populates="driver")
    routes = relationship("Route", back_populates="driver")

class Shift(Base):
    __tablename__ = "shifts"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    driver_id = Column(UUID(as_uuid=True), ForeignKey("drivers.id"))
    vehicle_id = Column(UUID(as_uuid=True), ForeignKey("vehicles.id"))
    depot_id = Column(UUID(as_uuid=True), ForeignKey("depots.id"))
    start_time = Column(DateTime(timezone=True), nullable=False)
    end_time = Column(DateTime(timezone=True))
    status = Column(String(50), default="scheduled")
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    organization = relationship("Organization")
    driver = relationship("Driver", back_populates="shifts")
    vehicle = relationship("Vehicle", back_populates="shifts")
    depot = relationship("Depot", back_populates="shifts")
