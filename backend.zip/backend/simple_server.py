from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any
import uuid
from datetime import datetime

app = FastAPI(title="Simple Orders API")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mock orders storage
orders_db = []

@app.get("/")
def root():
    return {"status": "running", "timestamp": datetime.now()}

@app.get("/api/health")
def health_check():
    return {"status": "healthy", "timestamp": datetime.now()}

@app.get("/api/orders")
def get_orders():
    return orders_db

@app.post("/api/orders")
def create_order(order: Dict[str, Any]):
    new_order = {
        "id": str(uuid.uuid4()),
        **order,
        "status": "pending",
        "createdAt": datetime.now().isoformat()
    }
    orders_db.append(new_order)
    return new_order

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
