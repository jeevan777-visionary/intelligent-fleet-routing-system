
# Architecture

Frontend → React Dashboard  
Backend → FastAPI APIs  
Database → MongoDB  

Optimization Layer:
- Classical solver (OR‑Tools)
- Hybrid quantum algorithm (QAOA)
