import { useState, useEffect } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  organization: string;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mock authentication - in real app, check token and fetch user
    const mockUser: User = {
      id: '1',
      name: 'John Doe',
      email: 'john@demo-fleet.com',
      role: 'dispatcher',
      organization: 'Demo Fleet Company'
    };
    
    setTimeout(() => {
      setUser(mockUser);
      setLoading(false);
    }, 1000);
  }, []);

  const login = async (email: string, password: string) => {
    // Mock login - in real app, call API
    setLoading(true);
    setTimeout(() => {
      const mockUser: User = {
        id: '1',
        name: 'John Doe',
        email: email,
        role: 'dispatcher',
        organization: 'Demo Fleet Company'
      };
      setUser(mockUser);
      setLoading(false);
    }, 1000);
  };

  const logout = () => {
    setUser(null);
  };

  return {
    user,
    loading,
    login,
    logout
  };
}
