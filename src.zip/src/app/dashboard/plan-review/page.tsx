'use client'

import { useState, useEffect } from 'react'
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet'
import { 
  CheckCircleIcon, 
  XCircleIcon,
  PencilIcon,
  ArrowPathIcon,
  PaperAirplaneIcon,
  MapPinIcon,
  TruckIcon,
  ClockIcon
} from '@heroicons/react/24/outline'
import { LatLngExpression } from 'leaflet'
import 'leaflet/dist/leaflet.css'

// Fix for default markers in react-leaflet
const createIcon = () => {
  if (typeof window !== 'undefined') {
    const L = require('leaflet')
    delete L.Icon.Default.prototype._getIconUrl
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: '/images/marker-icon-2x.png',
      iconUrl: '/images/marker-icon.png',
      shadowUrl: '/images/marker-shadow.png',
    })
  }
}

interface RouteStop {
  id: string
  type: 'depot' | 'delivery' | 'break'
  name: string
  address: string
  latitude: number
  longitude: number
  estimatedArrival: string
  estimatedDeparture: string
  priority: 'low' | 'medium' | 'high'
  orderIds: string[]
}

interface VehicleRoute {
  id: string
  vehicleId: string
  driver: string
  vehicleType: 'bike' | 'van' | 'truck'
  color: string
  stops: RouteStop[]
  totalDistance: number
  estimatedDuration: number
  fuelConsumption: number
  capacity: {
    weight: number
    volume: number
  }
  utilization: {
    weight: number
    volume: number
  }
}

function MapController({ center, zoom }: { center: LatLngExpression, zoom: number }) {
  const map = useMap()
  useEffect(() => {
    map.setView(center, zoom)
  }, [center, zoom, map])
  return null
}

export default function PlanReviewPage() {
  const [routes, setRoutes] = useState<VehicleRoute[]>([])
  const [selectedRoute, setSelectedRoute] = useState<VehicleRoute | null>(null)
  const [mapCenter] = useState<[number, number]>([18.5204, 73.8567]) // Pune coordinates
  const [mapZoom] = useState(12)
  const [loading, setLoading] = useState(true)
  const [dispatchStatus, setDispatchStatus] = useState<{ [key: string]: 'pending' | 'dispatched' }>({})

  useEffect(() => {
    createIcon()
    fetchRoutes()
  }, [])

  const fetchRoutes = async () => {
    try {
      // Mock data for demonstration
      const mockRoutes: VehicleRoute[] = [
        {
          id: 'route_1',
          vehicleId: 'VH001',
          driver: 'Raj Kumar',
          vehicleType: 'van',
          color: '#3B82F6',
          stops: [
            {
              id: 'depot_1',
              type: 'depot',
              name: 'Pune Central Depot',
              address: 'MG Road, Pune',
              latitude: 18.5204,
              longitude: 73.8567,
              estimatedArrival: '09:00',
              estimatedDeparture: '09:15',
              priority: 'medium',
              orderIds: []
            },
            {
              id: 'stop_1',
              type: 'delivery',
              name: 'Customer A',
              address: '123 FC Road, Pune',
              latitude: 18.5314,
              longitude: 73.8446,
              estimatedArrival: '09:30',
              estimatedDeparture: '09:40',
              priority: 'high',
              orderIds: ['order_1', 'order_2']
            },
            {
              id: 'stop_2',
              type: 'delivery',
              name: 'Customer B',
              address: '456 JM Road, Pune',
              latitude: 18.5167,
              longitude: 73.8511,
              estimatedArrival: '10:00',
              estimatedDeparture: '10:10',
              priority: 'medium',
              orderIds: ['order_3']
            },
            {
              id: 'depot_1_return',
              type: 'depot',
              name: 'Pune Central Depot',
              address: 'MG Road, Pune',
              latitude: 18.5204,
              longitude: 73.8567,
              estimatedArrival: '10:30',
              estimatedDeparture: '10:30',
              priority: 'medium',
              orderIds: []
            }
          ],
          totalDistance: 12.5,
          estimatedDuration: 90,
          fuelConsumption: 2.8,
          capacity: { weight: 500, volume: 2.5 },
          utilization: { weight: 65, volume: 40 }
        },
        {
          id: 'route_2',
          vehicleId: 'VH002',
          driver: 'Sarah Johnson',
          vehicleType: 'bike',
          color: '#10B981',
          stops: [
            {
              id: 'depot_2',
              type: 'depot',
              name: 'Pune East Depot',
              address: 'Koregaon Park, Pune',
              latitude: 18.5333,
              longitude: 73.8933,
              estimatedArrival: '09:00',
              estimatedDeparture: '09:10',
              priority: 'medium',
              orderIds: []
            },
            {
              id: 'stop_3',
              type: 'delivery',
              name: 'Customer C',
              address: '789 Kalyani Nagar, Pune',
              latitude: 18.5417,
              longitude: 73.9056,
              estimatedArrival: '09:25',
              estimatedDeparture: '09:30',
              priority: 'high',
              orderIds: ['order_4']
            },
            {
              id: 'stop_4',
              type: 'delivery',
              name: 'Customer D',
              address: '321 Mundhwa, Pune',
              latitude: 18.5594,
              longitude: 73.9233,
              estimatedArrival: '09:45',
              estimatedDeparture: '09:50',
              priority: 'low',
              orderIds: ['order_5', 'order_6']
            },
            {
              id: 'depot_2_return',
              type: 'depot',
              name: 'Pune East Depot',
              address: 'Koregaon Park, Pune',
              latitude: 18.5333,
              longitude: 73.8933,
              estimatedArrival: '10:10',
              estimatedDeparture: '10:10',
              priority: 'medium',
              orderIds: []
            }
          ],
          totalDistance: 8.3,
          estimatedDuration: 70,
          fuelConsumption: 1.2,
          capacity: { weight: 20, volume: 0.1 },
          utilization: { weight: 85, volume: 70 }
        }
      ]
      
      setRoutes(mockRoutes)
      setSelectedRoute(mockRoutes[0])
    } catch (error) {
      console.error('Failed to fetch routes:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleDispatchRoute = async (routeId: string) => {
    try {
      setDispatchStatus({ ...dispatchStatus, [routeId]: 'dispatched' })
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      console.log(`Route ${routeId} dispatched successfully`)
    } catch (error) {
      console.error('Failed to dispatch route:', error)
      setDispatchStatus({ ...dispatchStatus, [routeId]: 'pending' })
    }
  }

  const handleReoptimize = async (routeId: string) => {
    try {
      console.log(`Reoptimizing route ${routeId}...`)
      // Simulate reoptimization
      await new Promise(resolve => setTimeout(resolve, 2000))
      console.log('Route reoptimized successfully')
    } catch (error) {
      console.error('Failed to reoptimize route:', error)
    }
  }

  const getStopIcon = (type: string) => {
    switch (type) {
      case 'depot': return '🏢'
      case 'delivery': return '📦'
      case 'break': return '☕'
      default: return '📍'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-100'
      case 'medium': return 'text-orange-600 bg-orange-100'
      case 'low': return 'text-green-600 bg-green-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  const getVehicleIcon = (type: string) => {
    switch (type) {
      case 'bike': return '🏍️'
      case 'van': return '🚐'
      case 'truck': return '🚚'
      default: return '🚗'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="p-6 h-full">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Plan Review</h1>
          <p className="text-gray-600">Review and approve optimized delivery routes</p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={() => handleReoptimize('all')}
            className="flex items-center px-4 py-2 bg-orange-600 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-orange-700"
          >
            <ArrowPathIcon className="h-4 w-4 mr-2" />
            Reoptimize All
          </button>
          <button
            onClick={() => routes.forEach(route => handleDispatchRoute(route.id))}
            className="flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-green-700"
          >
            <PaperAirplaneIcon className="h-4 w-4 mr-2" />
            Dispatch All
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
        {/* Routes List */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white rounded-lg shadow p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Vehicle Routes</h2>
            <div className="space-y-3">
              {routes.map((route) => (
                <div
                  key={route.id}
                  className={`border rounded-lg p-4 cursor-pointer transition-all ${
                    selectedRoute?.id === route.id 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedRoute(route)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <span className="text-xl mr-2">{getVehicleIcon(route.vehicleType)}</span>
                      <div>
                        <div className="font-medium text-gray-900">{route.vehicleId}</div>
                        <div className="text-sm text-gray-600">{route.driver}</div>
                      </div>
                    </div>
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: route.color }}
                    ></div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm text-gray-600 mb-3">
                    <div>
                      <span className="font-medium">Distance:</span> {route.totalDistance} km
                    </div>
                    <div>
                      <span className="font-medium">Duration:</span> {route.estimatedDuration} min
                    </div>
                    <div>
                      <span className="font-medium">Stops:</span> {route.stops.length}
                    </div>
                    <div>
                      <span className="font-medium">Fuel:</span> {route.fuelConsumption} L
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        handleReoptimize(route.id)
                      }}
                      className="flex items-center px-2 py-1 text-xs bg-orange-100 text-orange-700 rounded hover:bg-orange-200"
                    >
                      <ArrowPathIcon className="h-3 w-3 mr-1" />
                      Reoptimize
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        handleDispatchRoute(route.id)
                      }}
                      disabled={dispatchStatus[route.id] === 'dispatched'}
                      className={`flex items-center px-2 py-1 text-xs rounded ${
                        dispatchStatus[route.id] === 'dispatched'
                          ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                          : 'bg-green-100 text-green-700 hover:bg-green-200'
                      }`}
                    >
                      {dispatchStatus[route.id] === 'dispatched' ? (
                        <>
                          <CheckCircleIcon className="h-3 w-3 mr-1" />
                          Dispatched
                        </>
                      ) : (
                        <>
                          <PaperAirplaneIcon className="h-3 w-3 mr-1" />
                          Dispatch
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Route Details */}
          {selectedRoute && (
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-md font-semibold text-gray-900 mb-3">Route Details</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Vehicle:</span>
                  <span className="font-medium">{selectedRoute.vehicleId}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Driver:</span>
                  <span className="font-medium">{selectedRoute.driver}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Capacity Utilization:</span>
                  <span className="font-medium">
                    Weight: {selectedRoute.utilization.weight}%, 
                    Volume: {selectedRoute.utilization.volume}%
                  </span>
                </div>
                <div className="border-t pt-3">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Stops</h4>
                  <div className="space-y-2">
                    {selectedRoute.stops.map((stop, index) => (
                      <div key={stop.id} className="flex items-start space-x-2 text-sm">
                        <span className="text-lg">{getStopIcon(stop.type)}</span>
                        <div className="flex-1">
                          <div className="font-medium text-gray-900">{stop.name}</div>
                          <div className="text-gray-600">{stop.address}</div>
                          <div className="flex items-center space-x-2 mt-1">
                            <span className="text-gray-500">
                              {stop.estimatedArrival} - {stop.estimatedDeparture}
                            </span>
                            {stop.priority !== 'medium' && (
                              <span className={`px-1 py-0.5 text-xs rounded ${getPriorityColor(stop.priority)}`}>
                                {stop.priority}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Map */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow h-full">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold text-gray-900">Route Map</h2>
            </div>
            <div className="h-96 lg:h-full min-h-96">
              <MapContainer
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                <MapController center={mapCenter} zoom={mapZoom} />
                
                {routes.map((route) => (
                  <div key={route.id}>
                    {/* Route polyline */}
                    <Polyline
                      pathOptions={{ 
                        color: route.color,
                        weight: selectedRoute?.id === route.id ? 4 : 2,
                        opacity: selectedRoute?.id === route.id ? 1 : 0.6
                      }}
                      positions={route.stops.map(stop => [stop.latitude, stop.longitude])}
                    />
                    
                    {/* Stop markers */}
                    {route.stops.map((stop) => (
                      <Marker
                        key={stop.id}
                        position={[stop.latitude, stop.longitude]}
                      >
                        <Popup>
                          <div className="text-sm">
                            <div className="font-semibold">{stop.name}</div>
                            <div className="text-gray-600">{stop.address}</div>
                            <div className="text-gray-500">
                              {stop.estimatedArrival} - {stop.estimatedDeparture}
                            </div>
                            {stop.orderIds.length > 0 && (
                              <div className="text-gray-500">
                                Orders: {stop.orderIds.join(', ')}
                              </div>
                            )}
                          </div>
                        </Popup>
                      </Marker>
                    ))}
                  </div>
                ))}
              </MapContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
