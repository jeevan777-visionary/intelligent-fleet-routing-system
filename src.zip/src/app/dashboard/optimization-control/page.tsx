'use client'

import { useState, useEffect } from 'react'
import { 
  PlayIcon,
  PauseIcon,
  ChartBarIcon,
  CogIcon,
  BeakerIcon,
  BoltIcon,
  ArrowPathIcon,
  DocumentTextIcon,
  CheckCircleIcon,
  ClockIcon
} from '@heroicons/react/24/outline'

export default function OptimizationControlPage() {
  const [isRunning, setIsRunning] = useState(false)
  const [optimizationMode, setOptimizationMode] = useState('hybrid')
  const [progress, setProgress] = useState(0)
  const [currentPhase, setCurrentPhase] = useState('')
  const [results, setResults] = useState<OptimizationResult | null>(null)
  const [history, setHistory] = useState<any[]>([])

  interface OptimizationResult {
    id: string
    timestamp: string
    mode: string
    orders: number
    vehicles: number
    classicalDistance: number
    quantumDistance: number
    improvement: number
    duration: string
    routes?: any[]
    quantumMetrics?: any
  }

  const optimizationPhases = [
    { id: 1, name: 'Data Preparation', duration: 2000, description: 'Processing orders and fleet data' },
    { id: 2, name: 'Classical Optimization', duration: 3000, description: 'Running Google OR-Tools VRP' },
    { id: 3, name: 'Quantum Analysis', duration: 4000, description: 'Identifying optimization clusters' },
    { id: 4, name: 'QAOA Processing', duration: 5000, description: 'Quantum Approximate Optimization' },
    { id: 5, name: 'Result Integration', duration: 2000, description: 'Merging classical and quantum results' },
    { id: 6, name: 'Route Generation', duration: 3000, description: 'Creating final optimized routes' }
  ]

  useEffect(() => {
    // Load optimization history
    const mockHistory = [
      {
        id: 'OPT001',
        timestamp: '2024-03-10 08:30',
        mode: 'Hybrid',
        orders: 45,
        vehicles: 8,
        classicalDistance: 156.8,
        quantumDistance: 134.2,
        improvement: 14.4,
        duration: '2m 45s',
        status: 'completed'
      },
      {
        id: 'OPT002',
        timestamp: '2024-03-10 07:15',
        mode: 'Classical',
        orders: 38,
        vehicles: 6,
        classicalDistance: 142.3,
        quantumDistance: 0,
        improvement: 0,
        duration: '1m 12s',
        status: 'completed'
      },
      {
        id: 'OPT003',
        timestamp: '2024-03-09 16:45',
        mode: 'Hybrid',
        orders: 52,
        vehicles: 10,
        classicalDistance: 189.4,
        quantumDistance: 161.7,
        improvement: 14.6,
        duration: '3m 18s',
        status: 'completed'
      }
    ]
    setHistory(mockHistory)
  }, [])

  const runOptimization = async () => {
    setIsRunning(true)
    setProgress(0)
    setResults(null)

    for (let i = 0; i < optimizationPhases.length; i++) {
      const phase = optimizationPhases[i]
      setCurrentPhase(phase.name)
      
      // Simulate phase execution
      const phaseProgress = (i / optimizationPhases.length) * 100
      const stepProgress = 100 / optimizationPhases.length
      
      const interval = setInterval(() => {
        setProgress(prev => {
          const newProgress = prev + stepProgress / 20
          if (newProgress >= phaseProgress + stepProgress) {
            clearInterval(interval)
            return phaseProgress + stepProgress
          }
          return newProgress
        })
      }, phase.duration / 20)
      
      await new Promise(resolve => setTimeout(resolve, phase.duration))
    }

    // Generate results
    const mockResults = {
      id: `OPT${Date.now()}`,
      timestamp: new Date().toLocaleString(),
      mode: optimizationMode,
      orders: 47,
      vehicles: 8,
      classicalDistance: 168.5,
      quantumDistance: 143.2,
      improvement: 15.1,
      duration: '2m 54s',
      routes: [
        {
          vehicleId: 'VH001',
          driver: 'Raj Kumar',
          classicalRoute: ['Depot', 'Order A', 'Order C', 'Order B', 'Depot'],
          quantumRoute: ['Depot', 'Order A', 'Order B', 'Order C', 'Depot'],
          classicalDistance: 42.3,
          quantumDistance: 38.7,
          improvement: 8.5
        },
        {
          vehicleId: 'VH002',
          driver: 'Sarah Johnson',
          classicalRoute: ['Depot', 'Order D', 'Order E', 'Depot'],
          quantumRoute: ['Depot', 'Order E', 'Order D', 'Depot'],
          classicalDistance: 35.8,
          quantumDistance: 31.2,
          improvement: 12.8
        }
      ],
      quantumMetrics: {
        qubitsUsed: 8,
        quantumDepth: 12,
        classicalTime: 45,
        quantumTime: 28,
        convergenceRate: 0.92
      }
    }

    setResults(mockResults)
    setIsRunning(false)
    setCurrentPhase('')

    // Add to history
    setHistory(prev => [mockResults, ...prev.slice(0, 9)])
  }

  const stopOptimization = () => {
    setIsRunning(false)
    setCurrentPhase('')
    setProgress(0)
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-green-600'
      case 'running': return 'text-blue-600'
      case 'failed': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Optimization Control Panel</h1>
          <p className="text-gray-600">Hybrid quantum-classical route optimization engine</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center bg-white rounded-lg border p-2">
            <label className="text-sm font-medium text-gray-700 mr-2">Mode:</label>
            <select
              value={optimizationMode}
              onChange={(e) => setOptimizationMode(e.target.value)}
              disabled={isRunning}
              className="text-sm border-0 focus:ring-0"
            >
              <option value="classical">Classical Only</option>
              <option value="hybrid">Hybrid Quantum</option>
              <option value="quantum">Quantum Only</option>
            </select>
          </div>
        </div>
      </div>

      {/* Control Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Main Controls */}
        <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Optimization Engine</h2>
            <div className="flex items-center space-x-2">
              {isRunning ? (
                <button
                  onClick={stopOptimization}
                  className="flex items-center px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                >
                  <PauseIcon className="h-4 w-4 mr-2" />
                  Stop
                </button>
              ) : (
                <button
                  onClick={runOptimization}
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                >
                  <PlayIcon className="h-4 w-4 mr-2" />
                  Run Optimization
                </button>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          {(isRunning || progress > 0) && (
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">
                  {currentPhase || 'Ready'}
                </span>
                <span className="text-sm text-gray-500">{Math.round(progress)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Optimization Phases */}
          <div className="space-y-3">
            {optimizationPhases.map((phase, index) => (
              <div key={phase.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    progress / 100 > (index / optimizationPhases.length) 
                      ? 'bg-green-100 text-green-600' 
                      : currentPhase === phase.name 
                      ? 'bg-blue-100 text-blue-600' 
                      : 'bg-gray-100 text-gray-400'
                  }`}>
                    {progress / 100 > (index / optimizationPhases.length) ? (
                      <CheckCircleIcon className="h-4 w-4" />
                    ) : currentPhase === phase.name ? (
                      <ArrowPathIcon className="h-4 w-4 animate-spin" />
                    ) : (
                      <ClockIcon className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{phase.name}</p>
                    <p className="text-sm text-gray-500">{phase.description}</p>
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  {(phase.duration / 1000).toFixed(1)}s
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Engine Status */}
        <div className="space-y-4">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Engine Status</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Classical Engine</span>
                <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Active</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Quantum Simulator</span>
                <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Ready</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Qiskit Backend</span>
                <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Connected</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">OR-Tools</span>
                <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">v9.8</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Configuration</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Max Qubits</span>
                <span className="text-sm font-medium">32</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Quantum Depth</span>
                <span className="text-sm font-medium">16</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Iterations</span>
                <span className="text-sm font-medium">1000</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Convergence</span>
                <span className="text-sm font-medium">0.95</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      {results && (
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Optimization Results</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{results.orders}</p>
              <p className="text-sm text-gray-600">Orders Processed</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{results.vehicles}</p>
              <p className="text-sm text-gray-600">Vehicles Used</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">{results.improvement}%</p>
              <p className="text-sm text-gray-600">Quantum Gain</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{results.duration}</p>
              <p className="text-sm text-gray-600">Processing Time</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Distance Comparison</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Classical Route:</span>
                  <span className="text-sm font-medium">{results.classicalDistance} km</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Quantum Route:</span>
                  <span className="text-sm font-medium text-green-600">{results.quantumDistance} km</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Distance Saved:</span>
                  <span className="text-sm font-bold text-green-600">
                    {(results.classicalDistance - results.quantumDistance).toFixed(1)} km
                  </span>
                </div>
              </div>
            </div>

            {results.quantumMetrics && (
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Quantum Metrics</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Qubits Used:</span>
                    <span className="text-sm font-medium">{results.quantumMetrics.qubitsUsed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Quantum Depth:</span>
                    <span className="text-sm font-medium">{results.quantumMetrics.quantumDepth}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Convergence Rate:</span>
                    <span className="text-sm font-medium">{results.quantumMetrics.convergenceRate}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Optimization History */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b">
          <h2 className="text-lg font-semibold text-gray-900">Optimization History</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Timestamp
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Mode
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Orders
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Improvement
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Duration
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {history.map((run) => (
                <tr key={run.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {run.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {run.timestamp}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span className={`px-2 py-1 text-xs rounded ${
                      run.mode === 'Hybrid' ? 'bg-purple-100 text-purple-700' :
                      run.mode === 'Quantum' ? 'bg-blue-100 text-blue-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {run.mode}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {run.orders}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {run.improvement > 0 ? (
                      <span className="text-green-600 font-medium">{run.improvement}%</span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {run.duration}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={getStatusColor(run.status)}>
                      {run.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
