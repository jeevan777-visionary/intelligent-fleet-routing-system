'use client'

import { useState, useEffect } from 'react'
import { 
  TruckIcon, 
  MapPinIcon, 
  ClockIcon, 
  CheckCircleIcon,
  PlayIcon,
  DocumentArrowDownIcon,
  ExclamationTriangleIcon
} from '@heroicons/react/24/outline'

export default function DispatchPage() {
  const [activeStep, setActiveStep] = useState(1)
  const [orders, setOrders] = useState([])
  const [vehicles, setVehicles] = useState([])
  const [routes, setRoutes] = useState([])
  const [loading, setLoading] = useState(false)
  const [optimizationProgress, setOptimizationProgress] = useState(0)

  const dispatchSteps = [
    { id: 1, name: 'Import Orders', icon: DocumentArrowDownIcon, status: 'current' },
    { id: 2, name: 'Prepare Fleet', icon: TruckIcon, status: 'upcoming' },
    { id: 3, name: 'Run Optimization', icon: ClockIcon, status: 'upcoming' },
    { id: 4, name: 'Dispatch Drivers', icon: CheckCircleIcon, status: 'upcoming' }
  ]

  useEffect(() => {
    // Load mock data
    setOrders([
      { id: 'ORD001', customer: 'Tech Park A', address: 'HITEC City, Hyderabad', priority: 'High', status: 'pending' },
      { id: 'ORD002', customer: 'Residential B', address: 'Kukatpally, Hyderabad', priority: 'Medium', status: 'pending' },
      { id: 'ORD003', customer: 'Office C', address: 'Banjara Hills, Hyderabad', priority: 'Low', status: 'pending' },
    ])
    
    setVehicles([
      { id: 'VH001', type: 'Van', capacity: 50, driver: 'Raj Kumar', status: 'available' },
      { id: 'VH002', type: 'Bike', capacity: 10, driver: 'Sarah Johnson', status: 'available' },
      { id: 'VH003', type: 'Truck', capacity: 100, driver: 'Mike Chen', status: 'available' },
    ])
  }, [])

  const handleImportOrders = () => {
    setLoading(true)
    setTimeout(() => {
      setActiveStep(2)
      setLoading(false)
    }, 2000)
  }

  const handlePrepareFleet = () => {
    setLoading(true)
    setTimeout(() => {
      setActiveStep(3)
      setLoading(false)
    }, 1500)
  }

  const handleRunOptimization = () => {
    setLoading(true)
    setOptimizationProgress(0)
    
    const interval = setInterval(() => {
      setOptimizationProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          setLoading(false)
          setActiveStep(4)
          setRoutes([
            { id: 'R001', vehicle: 'VH001', stops: ['Depot', 'ORD001', 'ORD003'], distance: 25.4, time: 45 },
            { id: 'R002', vehicle: 'VH002', stops: ['Depot', 'ORD002'], distance: 18.2, time: 30 },
          ])
          return 100
        }
        return prev + 10
      })
    }, 300)
  }

  const handleDispatchDrivers = () => {
    setLoading(true)
    setTimeout(() => {
      alert('Drivers dispatched successfully!')
      setLoading(false)
    }, 1000)
  }

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Dispatch Workflow</h1>
        <p className="text-gray-600">Plan and execute daily delivery operations</p>
      </div>

      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {dispatchSteps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <div className={`flex items-center justify-center w-12 h-12 rounded-full border-2 ${
                step.status === 'current' ? 'border-blue-600 bg-blue-600' :
                step.status === 'completed' ? 'border-green-600 bg-green-600' :
                'border-gray-300 bg-white'
              }`}>
                <step.icon className={`h-6 w-6 ${
                  step.status === 'current' || step.status === 'completed' ? 'text-white' : 'text-gray-400'
                }`} />
              </div>
              <div className="ml-3">
                <p className={`text-sm font-medium ${
                  step.status === 'current' ? 'text-blue-600' :
                  step.status === 'completed' ? 'text-green-600' :
                  'text-gray-500'
                }`}>
                  {step.name}
                </p>
              </div>
              {index < dispatchSteps.length - 1 && (
                <div className={`w-16 h-0.5 mx-4 ${
                  step.status === 'completed' ? 'bg-green-600' : 'bg-gray-300'
                }`} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Step Content */}
      <div className="bg-white rounded-lg shadow p-6">
        {activeStep === 1 && (
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Step 1: Import Orders</h2>
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <DocumentArrowDownIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">Upload CSV file with orders or sync from API</p>
                <button
                  onClick={handleImportOrders}
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {loading ? 'Importing...' : 'Import Orders'}
                </button>
              </div>
              
              <div className="mt-6">
                <h3 className="text-md font-medium text-gray-900 mb-3">Today's Orders ({orders.length})</h3>
                <div className="space-y-2">
                  {orders.map(order => (
                    <div key={order.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <span className="font-medium">{order.id}</span>
                        <span className="ml-2 text-gray-600">{order.customer}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 text-xs rounded ${
                          order.priority === 'High' ? 'bg-red-100 text-red-700' :
                          order.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {order.priority}
                        </span>
                        <span className="text-sm text-gray-500">{order.address}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeStep === 2 && (
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Step 2: Prepare Fleet</h2>
            <div className="space-y-4">
              <div>
                <h3 className="text-md font-medium text-gray-900 mb-3">Available Vehicles ({vehicles.length})</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {vehicles.map(vehicle => (
                    <div key={vehicle.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{vehicle.id}</span>
                        <span className={`px-2 py-1 text-xs rounded ${
                          vehicle.status === 'available' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                          {vehicle.status}
                        </span>
                      </div>
                      <div className="text-sm text-gray-600">
                        <p>Type: {vehicle.type}</p>
                        <p>Capacity: {vehicle.capacity} kg</p>
                        <p>Driver: {vehicle.driver}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  onClick={handlePrepareFleet}
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {loading ? 'Preparing...' : 'Confirm Fleet & Continue'}
                </button>
              </div>
            </div>
          </div>
        )}

        {activeStep === 3 && (
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Step 3: Run Optimization</h2>
            <div className="space-y-4">
              <div className="text-center">
                <div className="mb-4">
                  <div className="w-full bg-gray-200 rounded-full h-4">
                    <div 
                      className="bg-blue-600 h-4 rounded-full transition-all duration-300"
                      style={{ width: `${optimizationProgress}%` }}
                    />
                  </div>
                  <p className="mt-2 text-sm text-gray-600">
                    {optimizationProgress}% - Running hybrid optimization...
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 mb-2">Classical Optimization</h4>
                    <div className="flex items-center text-sm text-gray-600">
                      <TruckIcon className="h-4 w-4 mr-2" />
                      Google OR-Tools VRP
                    </div>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 mb-2">AI Enhancement</h4>
                    <div className="flex items-center text-sm text-gray-600">
                      <ClockIcon className="h-4 w-4 mr-2" />
                      Machine Learning Algorithm
                    </div>
                  </div>
                </div>

                {!loading && optimizationProgress === 0 && (
                  <div className="flex justify-center mt-6">
                    <button
                      onClick={handleRunOptimization}
                      className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
                    >
                      <PlayIcon className="h-4 w-4 mr-2" />
                      Start Optimization
                    </button>
                  </div>
                )}

                {loading && optimizationProgress > 0 && (
                  <div className="text-center mt-6">
                    <div className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-lg">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-800 mr-2"></div>
                      Optimizing Routes... {optimizationProgress}%
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeStep === 4 && (
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Step 4: Dispatch Drivers</h2>
            <div className="space-y-4">
              <div>
                <h3 className="text-md font-medium text-gray-900 mb-3">Optimized Routes ({routes.length})</h3>
                <div className="space-y-3">
                  {routes.map(route => (
                    <div key={route.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{route.id} - {route.vehicle}</span>
                        <span className="text-sm text-gray-600">
                          {route.distance} km • {route.time} min
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPinIcon className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          {route.stops.join(' → ')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  onClick={handleDispatchDrivers}
                  disabled={loading}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 flex items-center"
                >
                  <PlayIcon className="h-4 w-4 mr-2" />
                  {loading ? 'Dispatching...' : 'Dispatch All Drivers'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
