'use client'

import { useState, useEffect } from 'react'
import { 
  ChartBarIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  CurrencyDollarIcon,
  TruckIcon,
  ClockIcon,
  ArrowPathIcon,
  FunnelIcon
} from '@heroicons/react/24/outline'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area } from 'recharts'

interface AnalyticsData {
  deliveryPerformance: Array<{
    date: string
    classical: number
    quantum: number
    improvement: number
  }>
  fuelConsumption: Array<{
    month: string
    baseline: number
    optimized: number
    savings: number
  }>
  costAnalysis: Array<{
    category: string
    amount: number
    percentage: number
  }>
  routeEfficiency: Array<{
    vehicle: string
    efficiency: number
    distance: number
    time: number
  }>
  kpis: {
    totalDeliveries: number
    onTimeRate: number
    costSavings: number
    fuelReduction: number
    averageDeliveryTime: number
    fleetUtilization: number
  }
}

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d')
  const [comparison, setComparison] = useState<'classical' | 'quantum' | 'both'>('both')

  useEffect(() => {
    fetchAnalyticsData()
  }, [timeRange, comparison])

  const fetchAnalyticsData = async () => {
    try {
      setLoading(true)
      
      // Mock analytics data
      const mockData: AnalyticsData = {
        deliveryPerformance: [
          { date: 'Mon', classical: 45, quantum: 65, improvement: 44 },
          { date: 'Tue', classical: 52, quantum: 72, improvement: 38 },
          { date: 'Wed', classical: 38, quantum: 58, improvement: 53 },
          { date: 'Thu', classical: 65, quantum: 85, improvement: 31 },
          { date: 'Fri', classical: 48, quantum: 68, improvement: 42 },
          { date: 'Sat', classical: 58, quantum: 78, improvement: 34 },
          { date: 'Sun', classical: 42, quantum: 62, improvement: 48 }
        ],
        fuelConsumption: [
          { month: 'Jan', baseline: 1200, optimized: 890, savings: 26 },
          { month: 'Feb', baseline: 1150, optimized: 820, savings: 29 },
          { month: 'Mar', baseline: 1300, optimized: 910, savings: 30 },
          { month: 'Apr', baseline: 1250, optimized: 880, savings: 30 },
          { month: 'May', baseline: 1180, optimized: 840, savings: 29 },
          { month: 'Jun', baseline: 1220, optimized: 860, savings: 29 }
        ],
        costAnalysis: [
          { category: 'Fuel', amount: 45000, percentage: 35 },
          { category: 'Maintenance', amount: 25000, percentage: 20 },
          { category: 'Driver Salaries', amount: 38000, percentage: 30 },
          { category: 'Insurance', amount: 12000, percentage: 9 },
          { category: 'Other', amount: 8000, percentage: 6 }
        ],
        routeEfficiency: [
          { vehicle: 'VH001', efficiency: 92, distance: 145, time: 6.5 },
          { vehicle: 'VH002', efficiency: 88, distance: 132, time: 5.8 },
          { vehicle: 'VH003', efficiency: 85, distance: 168, time: 7.2 },
          { vehicle: 'VH004', efficiency: 90, distance: 125, time: 5.5 },
          { vehicle: 'VH005', efficiency: 87, distance: 156, time: 6.8 }
        ],
        kpis: {
          totalDeliveries: 2847,
          onTimeRate: 94.5,
          costSavings: 285000,
          fuelReduction: 29.3,
          averageDeliveryTime: 6.2,
          fleetUtilization: 87.8
        }
      }
      
      setData(mockData)
    } catch (error) {
      console.error('Failed to fetch analytics data:', error)
    } finally {
      setLoading(false)
    }
  }

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6']

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500">No analytics data available</p>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h1>
          <p className="text-gray-600">Performance metrics and insights</p>
        </div>
        <div className="flex space-x-3">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as any)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
            <option value="1y">Last Year</option>
          </select>
          <select
            value={comparison}
            onChange={(e) => setComparison(e.target.value as any)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="both">Both Algorithms</option>
            <option value="classical">Classical Only</option>
            <option value="quantum">Quantum Only</option>
          </select>
          <button
            onClick={fetchAnalyticsData}
            className="flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-blue-700"
          >
            <ArrowPathIcon className="h-4 w-4 mr-2" />
            Refresh
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <TruckIcon className="h-8 w-8 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Deliveries</p>
              <p className="text-2xl font-bold text-gray-900">{data.kpis.totalDeliveries.toLocaleString()}</p>
              <p className="text-xs text-green-600">+12% vs last period</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ClockIcon className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">On-Time Rate</p>
              <p className="text-2xl font-bold text-gray-900">{data.kpis.onTimeRate}%</p>
              <p className="text-xs text-green-600">+3.2% vs last period</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <CurrencyDollarIcon className="h-8 w-8 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Cost Savings</p>
              <p className="text-2xl font-bold text-gray-900">₹{(data.kpis.costSavings / 1000).toFixed(0)}K</p>
              <p className="text-xs text-green-600">+18% vs last period</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <FunnelIcon className="h-8 w-8 text-orange-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Fuel Reduction</p>
              <p className="text-2xl font-bold text-gray-900">{data.kpis.fuelReduction}%</p>
              <p className="text-xs text-green-600">+5.1% vs last period</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ArrowTrendingUpIcon className="h-8 w-8 text-cyan-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Avg Delivery Time</p>
              <p className="text-2xl font-bold text-gray-900">{data.kpis.averageDeliveryTime}h</p>
              <p className="text-xs text-green-600">-15% vs last period</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ChartBarIcon className="h-8 w-8 text-indigo-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Fleet Utilization</p>
              <p className="text-2xl font-bold text-gray-900">{data.kpis.fleetUtilization}%</p>
              <p className="text-xs text-green-600">+7.3% vs last period</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Delivery Performance Comparison */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Delivery Performance Comparison</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data.deliveryPerformance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              {(comparison === 'classical' || comparison === 'both') && (
                <Line 
                  type="monotone" 
                  dataKey="classical" 
                  stroke="#EF4444" 
                  strokeWidth={2}
                  name="Classical OR-Tools"
                />
              )}
              {(comparison === 'quantum' || comparison === 'both') && (
                <Line 
                  type="monotone" 
                  dataKey="quantum" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  name="Hybrid Quantum"
                />
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Fuel Consumption Analysis */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Fuel Consumption Analysis</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={data.fuelConsumption}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Area 
                type="monotone" 
                dataKey="baseline" 
                stackId="1"
                stroke="#EF4444" 
                fill="#FEE2E2"
                name="Baseline"
              />
              <Area 
                type="monotone" 
                dataKey="optimized" 
                stackId="2"
                stroke="#10B981" 
                fill="#D1FAE5"
                name="Optimized"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Cost Breakdown */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Cost Breakdown</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={data.costAnalysis}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ category, percentage }) => `${category}: ${percentage}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="amount"
              >
                {data.costAnalysis.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => `₹${value.toLocaleString()}`} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Route Efficiency */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Vehicle Route Efficiency</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data.routeEfficiency}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="vehicle" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="efficiency" fill="#3B82F6" name="Efficiency %" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Summary Table */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b">
          <h3 className="text-lg font-semibold text-gray-900">Algorithm Performance Summary</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Metric
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Classical OR-Tools
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Hybrid Quantum
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Improvement
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  Average Route Distance
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  45.2 km
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  32.8 km
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                  27.4% ↓
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    Improved
                  </span>
                </td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  Computation Time
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  5.2 min
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  3.1 min
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                  40.4% ↓
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    Faster
                  </span>
                </td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  Fuel Consumption
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  12.5 L
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  8.9 L
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                  28.8% ↓
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    Reduced
                  </span>
                </td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  Customer Satisfaction
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  87.3%
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  94.5%
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                  8.3% ↑
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    Enhanced
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
