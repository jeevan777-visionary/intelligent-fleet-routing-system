'use client'

import { useState, useEffect } from 'react'
import dynamic from 'next/dynamic'
import { 
  TruckIcon, 
  ExclaimationCircleIcon,
  ArrowPathIcon,
  FunnelIcon,
  MapPinIcon,
  ClockIcon
} from '@heroicons/react/24/outline'

// Dynamically import Leaflet components to avoid SSR issues
const MapContainer = dynamic(() => import('react-leaflet').then(mod => mod.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import('react-leaflet').then(mod => mod.TileLayer), { ssr: false })
const Marker = dynamic(() => import('react-leaflet').then(mod => mod.Marker), { ssr: false })
const Popup = dynamic(() => import('react-leaflet').then(mod => mod.Popup), { ssr: false })
const Polyline = dynamic(() => import('react-leaflet').then(mod => mod.Polyline), { ssr: false })

// Dynamically import Leaflet CSS
import 'leaflet/dist/leaflet.css'

// Fix for default markers in react-leaflet
const createIcon = () => {
  if (typeof window !== 'undefined') {
    const L = require('leaflet')
    delete L.Icon.Default.prototype._getIconUrl
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
      iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
      shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    })
  }
}

interface LiveVehicle {
  id: string
  vehicleId: string
  driver: string
  vehicleType: 'bike' | 'van' | 'truck'
  status: 'active' | 'idle' | 'break' | 'emergency'
  currentLocation: {
    latitude: number
    longitude: number
    address: string
  }
  speed: number
  heading: number
  fuelLevel: number
  nextDestination: string
  estimatedArrival: string
  deliveriesCompleted: number
  totalDeliveries: number
  lastUpdate: string
  alerts: Array<{
    id: string
    type: 'traffic' | 'fuel' | 'break' | 'delay'
    severity: 'low' | 'medium' | 'high'
    message: string
    timestamp: string
  }>
  routes: {
    classical: Array<{ lat: number; lng: number }>
    quantum: Array<{ lat: number; lng: number }>
  }
}

interface Alert {
  id: string
  type: 'traffic' | 'fuel' | 'break' | 'delay'
  severity: 'low' | 'medium' | 'high'
  message: string
  timestamp: string
  vehicleId: string
}

interface Depot {
  id: string
  name: string
  location: {
    latitude: number
    longitude: number
    address: string
  }
  capacity: number
  currentVehicles: number
}

interface DeliveryStop {
  id: string
  orderId: string
  customerName: string
  address: string
  location: {
    latitude: number
    longitude: number
  }
  status: 'pending' | 'in_progress' | 'completed'
  estimatedArrival: string
  priority: 'low' | 'medium' | 'high'
}

const MapController = ({ center, zoom }: { center: LatLngExpression; zoom: number }) => {
  // Import useMap inside component to avoid SSR issues
  const { useMap } = require('react-leaflet')
  const map = useMap()
  useEffect(() => {
    map.setView(center, zoom)
  }, [center, zoom, map])
  return null
}

export default function LiveMapPage() {
  const [vehicles, setVehicles] = useState<LiveVehicle[]>([])
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [selectedVehicle, setSelectedVehicle] = useState<LiveVehicle | null>(null)
  const [mapCenter] = useState<[number, number]>([17.3850, 78.4867]) // Hyderabad coordinates
  const [mapZoom] = useState(12)
  const [loading, setLoading] = useState(true)
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [showClassicalRoutes, setShowClassicalRoutes] = useState(true)
  const [showQuantumRoutes, setShowQuantumRoutes] = useState(true)
  const [depots, setDepots] = useState<Depot[]>([])
  const [deliveryStops, setDeliveryStops] = useState<DeliveryStop[]>([])

  useEffect(() => {
    createIcon()
    fetchLiveVehicles()
    fetchAlerts()
    fetchDepots()
    fetchDeliveryStops()
    
    if (autoRefresh) {
      const interval = setInterval(() => {
        fetchLiveVehicles()
        fetchAlerts()
        fetchDeliveryStops()
      }, 10000) // Refresh every 10 seconds
      
      return () => clearInterval(interval)
    }
  }, [autoRefresh])

  const fetchLiveVehicles = async () => {
    try {
      // Initialize vehicles if empty
      if (vehicles.length === 0) {
        const mockVehicles: LiveVehicle[] = [
          {
            id: 'VH001',
            vehicleId: 'VH001',
            driver: 'Raj Kumar',
            vehicleType: 'van',
            status: 'active',
            currentLocation: { latitude: 17.4380, longitude: 78.4560, address: 'HITEC City, Hyderabad' },
            speed: 45,
            heading: 90,
            fuelLevel: 75,
            nextDestination: 'Tech Park A - HITEC City',
            estimatedArrival: '09:45',
            deliveriesCompleted: 12,
            totalDeliveries: 20,
            lastUpdate: new Date().toISOString(),
            alerts: [],
            routes: {
              classical: [
                { lat: 17.4380, lng: 78.4560 },
                { lat: 17.4400, lng: 78.4580 },
                { lat: 17.4420, lng: 78.4600 }
              ],
              quantum: [
                { lat: 17.4380, lng: 78.4560 },
                { lat: 17.4390, lng: 78.4575 },
                { lat: 17.4410, lng: 78.4590 }
              ]
            }
          },
          {
            id: 'VH002',
            vehicleId: 'VH002',
            driver: 'Sarah Johnson',
            vehicleType: 'bike',
            status: 'active',
            currentLocation: { latitude: 17.4947, longitude: 78.3980, address: 'Kukatpally, Hyderabad' },
            speed: 35,
            heading: 45,
            fuelLevel: 60,
            nextDestination: 'Residential B - Kukatpally',
            estimatedArrival: '10:30',
            deliveriesCompleted: 8,
            totalDeliveries: 15,
            lastUpdate: new Date().toISOString(),
            alerts: [
              { id: 'ALT001', type: 'traffic', severity: 'medium', message: 'Heavy traffic on route', timestamp: new Date().toISOString() }
            ],
            routes: {
              classical: [
                { lat: 17.4947, lng: 78.3980 },
                { lat: 17.4960, lng: 78.4000 },
                { lat: 17.4980, lng: 78.4020 }
              ],
              quantum: [
                { lat: 17.4947, lng: 78.3980 },
                { lat: 17.4955, lng: 78.3990 },
                { lat: 17.4970, lng: 78.4010 }
              ]
            }
          },
          {
            id: 'VH003',
            vehicleId: 'VH003',
            driver: 'Mike Chen',
            vehicleType: 'truck',
            status: 'idle',
            currentLocation: { latitude: 17.2403, longitude: 78.4294, address: 'Hyderabad Airport' },
            speed: 0,
            heading: 0,
            fuelLevel: 90,
            nextDestination: 'None',
            estimatedArrival: 'N/A',
            deliveriesCompleted: 15,
            totalDeliveries: 18,
            lastUpdate: new Date().toISOString(),
            alerts: [],
            routes: {
              classical: [],
              quantum: []
            }
          }
        ]
        setVehicles(mockVehicles)
      } else {
        // Simulate real-time vehicle movement only for active vehicles with orders
        setVehicles(prevVehicles => 
          prevVehicles.map(vehicle => {
            // Only move vehicles that are active AND have a next destination
            if (vehicle.status === 'active' && vehicle.nextDestination !== 'None') {
              // Move vehicle towards next destination
              const newLat = vehicle.currentLocation.latitude + (Math.random() - 0.5) * 0.001
              const newLng = vehicle.currentLocation.longitude + (Math.random() - 0.5) * 0.001
              return {
                ...vehicle,
                currentLocation: {
                  ...vehicle.currentLocation,
                  latitude: newLat,
                  longitude: newLng,
                  address: `${newLat.toFixed(4)}, ${newLng.toFixed(4)}`
                },
                speed: 35 + Math.random() * 20, // Variable speed
                lastUpdate: new Date().toISOString()
              }
            }
            // Idle vehicles stay in place
            return vehicle
          })
        )
      }
    } catch (error) {
      console.error('Failed to fetch live vehicles:', error)
    }
  }

  const fetchAlerts = async () => {
    try {
      // Mock alerts
      const mockAlerts: Alert[] = [
        {
          id: 'alert_1',
          type: 'traffic',
          severity: 'medium',
          message: 'Heavy traffic on MG Road - expect 15 min delay',
          timestamp: new Date(Date.now() - 300000).toISOString(),
          vehicleId: 'VH001'
        },
        {
          id: 'alert_2',
          type: 'fuel',
          severity: 'high',
          message: 'Vehicle VH003 fuel level below 50%',
          timestamp: new Date(Date.now() - 600000).toISOString(),
          vehicleId: 'VH003'
        },
        {
          id: 'alert_3',
          type: 'delay',
          severity: 'medium',
          message: 'Customer A delivery delayed by 10 minutes',
          timestamp: new Date(Date.now() - 900000).toISOString(),
          vehicleId: 'VH001'
        }
      ]
      setAlerts(mockAlerts)
    } catch (error) {
      console.error('Failed to fetch alerts:', error)
    }
  }

  const fetchDepots = async () => {
    try {
      const mockDepots: Depot[] = [
        {
          id: 'DEP001',
          name: 'Hyderabad Central',
          location: {
            latitude: 17.4245,
            longitude: 78.4718,
            address: 'Tank Bund Road, Hyderabad'
          },
          capacity: 50,
          currentVehicles: 15
        },
        {
          id: 'DEP002',
          name: 'HITEC City Depot',
          location: {
            latitude: 17.4380,
            longitude: 78.4560,
            address: 'HITEC City, Hyderabad'
          },
          capacity: 30,
          currentVehicles: 8
        }
      ]
      setDepots(mockDepots)
    } catch (error) {
      console.error('Failed to fetch depots:', error)
    }
  }

  const fetchDeliveryStops = async () => {
    try {
      const response = await fetch('http://localhost:8001/api/orders')
      if (response.ok) {
        const orders = await response.json()
        
        // Convert orders to delivery stops format
        const deliveryStops: DeliveryStop[] = orders.map((order: any) => ({
          id: order.id,
          orderId: order.id,
          customerName: order.customerName,
          address: order.deliveryAddress,
          location: { 
            latitude: order.destinationLatitude || order.latitude || 17.4380, 
            longitude: order.destinationLongitude || order.longitude || 78.4560 
          },
          status: order.status === 'pending' ? 'pending' : 
                  order.status === 'assigned' ? 'in_progress' : 
                  order.status === 'in_transit' ? 'in_progress' : 
                  order.status === 'delivered' ? 'completed' : 'pending',
          estimatedArrival: order.deliveryTimeWindow || 'TBD',
          priority: order.priority.charAt(0).toUpperCase() + order.priority.slice(1)
        }))
        
        setDeliveryStops(deliveryStops)
      }
    } catch (error) {
      console.error('Failed to fetch delivery stops:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700'
      case 'idle': return 'bg-blue-100 text-blue-700'
      case 'break': return 'bg-yellow-100 text-yellow-700'
      case 'emergency': return 'bg-red-100 text-red-700'
      default: return 'bg-gray-100 text-gray-700'
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'traffic': return '🚗'
      case 'fuel': return '⛽'
      case 'break': return '☕'
      case 'delay': return '⏰'
      default: return '📢'
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-600'
      case 'medium': return 'text-yellow-600'
      case 'high': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  const filteredVehicles = vehicles.filter(vehicle => {
    if (filterStatus === 'all') return true
    return vehicle.status === filterStatus
  })

  return (
    <div className="p-6 h-full">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Live Operations</h1>
          <p className="text-gray-600">Real-time fleet monitoring and route optimization</p>
        </div>
        <div className="flex items-center space-x-4">
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="mr-2"
            />
            <span className="text-sm text-gray-600">Auto-refresh</span>
          </label>
          <button
            onClick={() => {
              fetchLiveVehicles()
              fetchAlerts()
              fetchDeliveryStops()
            }}
            className="flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-blue-700"
          >
            <ArrowPathIcon className="h-4 w-4 mr-2" />
            Refresh
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          {/* Filters */}
          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-md font-semibold text-gray-900">Filters</h3>
              <FunnelIcon className="h-4 w-4 text-gray-400" />
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Vehicle Status</label>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="all">All Status</option>
                  <option value="active">Active</option>
                  <option value="idle">Idle</option>
                  <option value="break">Break</option>
                  <option value="emergency">Emergency</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Route Display</label>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={showClassicalRoutes}
                      onChange={(e) => setShowClassicalRoutes(e.target.checked)}
                      className="mr-2"
                    />
                    <span className="text-sm">Classical Routes (Blue)</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={showQuantumRoutes}
                      onChange={(e) => setShowQuantumRoutes(e.target.checked)}
                      className="mr-2"
                    />
                    <span className="text-sm">Quantum Routes (Green)</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Vehicles List */}
          <div className="bg-white rounded-lg shadow p-4 max-h-96 overflow-y-auto">
            <h3 className="text-md font-semibold text-gray-900 mb-3">Vehicles</h3>
            <div className="space-y-3">
              {filteredVehicles.map((vehicle) => (
                <div
                  key={vehicle.id}
                  className={`border rounded-lg p-3 cursor-pointer transition-all ${
                    selectedVehicle?.id === vehicle.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedVehicle(vehicle)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-gray-900">{vehicle.vehicleId}</span>
                    <span className={`px-2 py-1 text-xs rounded ${getStatusColor(vehicle.status)}`}>
                      {vehicle.status}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600">
                    <div>{vehicle.driver}</div>
                    <div className="flex items-center">
                      <MapPinIcon className="h-3 w-3 mr-1" />
                      {vehicle.currentLocation.address}
                    </div>
                    <div>Speed: {vehicle.speed} km/h</div>
                    <div>Fuel: {vehicle.fuelLevel}%</div>
                  </div>
                  {vehicle.alerts.length > 0 && (
                    <div className="mt-2 text-xs text-red-600">
                      {vehicle.alerts.length} alert(s)
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Alerts */}
          <div className="bg-white rounded-lg shadow p-4 max-h-64 overflow-y-auto">
            <h3 className="text-md font-semibold text-gray-900 mb-3">Active Alerts</h3>
            <div className="space-y-2">
              {alerts.map((alert) => (
                <div key={alert.id} className="flex items-start p-2 bg-red-50 rounded-lg">
                  <span className="text-lg mr-2">{getAlertIcon(alert.type)}</span>
                  <div className="flex-1">
                    <p className="text-sm text-gray-800">{alert.message}</p>
                    <p className="text-xs text-gray-600">{alert.vehicleId}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Map */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-lg shadow h-full">
            <div className="p-4 border-b">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold text-gray-900">Live Operations Map</h2>
                <div className="flex items-center space-x-4 text-xs">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-1"></div>
                    <span>Classical Route</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div>
                    <span>Quantum Route</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="h-96 lg:h-full min-h-96">
              {vehicles.length === 0 ? (
                <div className="flex items-center justify-center h-full bg-gray-100 rounded-lg">
                  <div className="text-center">
                    <div className="text-gray-500 mb-2">No vehicles available</div>
                    <button
                      onClick={() => {
                        fetchLiveVehicles()
                        fetchAlerts()
                        fetchDeliveryStops()
                      }}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      Load Vehicles
                    </button>
                  </div>
                </div>
              ) : (
                <MapContainer
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <MapController center={mapCenter} zoom={mapZoom} />
                  
                  {/* Depot Markers */}
                  {depots.map((depot) => (
                    <Marker
                      key={depot.id}
                      position={[depot.location.latitude, depot.location.longitude]}
                    >
                      <Popup>
                        <div className="text-sm">
                          <div className="font-semibold">{depot.name}</div>
                          <div className="text-gray-600">{depot.location.address}</div>
                          <div>Capacity: {depot.capacity} vehicles</div>
                          <div>Current: {depot.currentVehicles} vehicles</div>
                        </div>
                      </Popup>
                    </Marker>
                  ))}

                  {/* Delivery Stop Markers */}
                  {deliveryStops.map((stop) => (
                    <Marker
                      key={stop.id}
                      position={[stop.location.latitude, stop.location.longitude]}
                    >
                      <Popup>
                        <div className="text-sm">
                          <div className="font-semibold">{stop.customerName}</div>
                          <div className="text-gray-600">{stop.address}</div>
                          <div>Order: {stop.orderId}</div>
                          <div>ETA: {stop.estimatedArrival}</div>
                          <div className={`px-1 py-0.5 text-xs rounded ${
                            stop.priority === 'High' ? 'bg-red-100 text-red-700' :
                            stop.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-green-100 text-green-700'
                          }`}>
                            {stop.priority}
                          </div>
                        </div>
                      </Popup>
                    </Marker>
                  ))}
                  
                  {/* Vehicle Markers and Routes */}
                  {filteredVehicles.map((vehicle) => (
                    <div key={vehicle.id}>
                      <Marker
                        position={[vehicle.currentLocation.latitude, vehicle.currentLocation.longitude]}
                      >
                        <Popup>
                          <div className="text-sm">
                            <div className="font-semibold">{vehicle.vehicleId}</div>
                            <div className="text-gray-600">{vehicle.driver}</div>
                            <div className="text-gray-600">{vehicle.currentLocation.address}</div>
                            <div className="mt-2 space-y-1">
                              <div>Status: <span className={`px-1 py-0.5 text-xs rounded ${getStatusColor(vehicle.status)}`}>{vehicle.status}</span></div>
                              <div>Speed: {vehicle.speed} km/h</div>
                              <div>Fuel: {vehicle.fuelLevel}%</div>
                              <div>Next: {vehicle.nextDestination}</div>
                              <div>ETA: {vehicle.estimatedArrival}</div>
                              <div>Progress: {vehicle.deliveriesCompleted}/{vehicle.totalDeliveries}</div>
                            </div>
                            {vehicle.alerts.length > 0 && (
                              <div className="mt-2 text-red-600">
                                <div className="font-medium">Alerts:</div>
                                {vehicle.alerts.map(alert => (
                                  <div key={alert.id} className="text-xs">• {alert.message}</div>
                                ))}
                              </div>
                            )}
                          </div>
                        </Popup>
                      </Marker>

                      {/* Classical Route (Blue) */}
                      {showClassicalRoutes && vehicle.routes.classical.length > 1 && (
                        <Polyline
                          positions={vehicle.routes.classical.map(point => [point.lat, point.lng])}
                          color="blue"
                          weight={3}
                          opacity={0.7}
                          dashArray="5, 5"
                        />
                      )}

                      {/* Quantum Route (Green) */}
                      {showQuantumRoutes && vehicle.routes.quantum.length > 1 && (
                        <Polyline
                          positions={vehicle.routes.quantum.map(point => [point.lat, point.lng])}
                          color="green"
                          weight={3}
                          opacity={0.7}
                        />
                      )}
                    </div>
                  ))}
                </MapContainer>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
