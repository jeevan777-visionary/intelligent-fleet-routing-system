'use client'

import { useState, useEffect } from 'react'
import { 
  DocumentTextIcon,
  ChartBarIcon,
  CalendarIcon,
  TruckIcon,
  CurrencyDollarIcon,
  ArrowDownTrayIcon,
  FunnelIcon
} from '@heroicons/react/24/outline'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

interface Report {
  id: string
  name: string
  type: 'delivery' | 'performance' | 'financial' | 'fleet'
  generatedAt: string
  data: any
  size: number
}

export default function ReportsPage() {
  const [reports, setReports] = useState<Report[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedReport, setSelectedReport] = useState<Report | null>(null)
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d')

  useEffect(() => {
    fetchReports()
  }, [dateRange])

  const fetchReports = async () => {
    try {
      setLoading(true)
      // Mock reports data
      const mockReports: Report[] = [
        {
          id: '1',
          name: 'Daily Delivery Report',
          type: 'delivery',
          generatedAt: new Date().toISOString(),
          data: {
            totalDeliveries: 145,
            successfulDeliveries: 138,
            failedDeliveries: 7,
            averageDeliveryTime: 45,
            onTimeRate: 95.2
          },
          size: 2456
        },
        {
          id: '2',
          name: 'Fleet Performance Report',
          type: 'performance',
          generatedAt: new Date().toISOString(),
          data: {
            totalVehicles: 12,
            activeVehicles: 10,
            averageUtilization: 85.3,
            fuelEfficiency: 8.2,
            maintenanceIssues: 3
          },
          size: 1892
        },
        {
          id: '3',
          name: 'Financial Summary',
          type: 'financial',
          generatedAt: new Date().toISOString(),
          data: {
            totalRevenue: 45678,
            operatingCosts: 12345,
            fuelCosts: 8901,
            maintenanceCosts: 2344,
            netProfit: 22088
          },
          size: 1567
        },
        {
          id: '4',
          name: 'Weekly Route Analysis',
          type: 'fleet',
          generatedAt: new Date().toISOString(),
          data: {
            totalRoutes: 68,
            optimizedRoutes: 65,
            averageDistance: 15.2,
            fuelSavings: 12.5,
            timeSavings: 18.3
          },
          size: 2891
        }
      ]
      
      setReports(mockReports)
    } catch (error) {
      console.error('Failed to fetch reports:', error)
    } finally {
      setLoading(false)
    }
  }

  const generateReport = async (type: string) => {
    try {
      console.log(`Generating ${type} report...`)
      // Simulate report generation
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      const newReport: Report = {
        id: Date.now().toString(),
        name: `${type.charAt(0).toUpperCase() + type.slice(1)} Report - ${new Date().toLocaleDateString()}`,
        type: type as any,
        generatedAt: new Date().toISOString(),
        data: {},
        size: 0
      }
      
      setReports(prev => [newReport, ...prev])
    } catch (error) {
      console.error('Failed to generate report:', error)
    }
  }

  const downloadReport = async (report: Report) => {
    try {
      console.log(`Downloading report: ${report.name}`)
      // Simulate download
      const data = JSON.stringify(report, null, 2)
      const blob = new Blob([data], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${report.name.replace(/\s+/g, '_')}.json`
      a.click()
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Failed to download report:', error)
    }
  }

  const getReportIcon = (type: string) => {
    switch (type) {
      case 'delivery': return <DocumentTextIcon className="h-5 w-5 text-blue-600" />
      case 'performance': return <ChartBarIcon className="h-5 w-5 text-green-600" />
      case 'financial': return <CurrencyDollarIcon className="h-5 w-5 text-purple-600" />
      case 'fleet': return <TruckIcon className="h-5 w-5 text-orange-600" />
      default: return <DocumentTextIcon className="h-5 w-5 text-gray-600" />
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'delivery': return 'bg-blue-100 text-blue-800'
      case 'performance': return 'bg-green-100 text-green-800'
      case 'financial': return 'bg-purple-100 text-purple-800'
      case 'fleet': return 'bg-orange-100 text-orange-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
          <p className="text-gray-600">Generate and download various operational reports</p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value as any)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
            <option value="1y">Last Year</option>
          </select>
          <button
            onClick={() => generateReport('delivery')}
            className="flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-blue-700"
          >
            <DocumentTextIcon className="h-4 w-4 mr-2" />
            Generate Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Reports */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b">
              <h2 className="text-lg font-semibold text-gray-900">Recent Reports</h2>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {reports.map((report) => (
                  <div
                    key={report.id}
                    className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setSelectedReport(report)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center">
                        {getReportIcon(report.type)}
                        <div className="ml-3">
                          <div className="font-medium text-gray-900">{report.name}</div>
                          <div className="text-sm text-gray-600">
                            {new Date(report.generatedAt).toLocaleDateString()} • {(report.size / 1024).toFixed(1)} KB
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${getTypeColor(report.type)}`}>
                          {report.type}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            downloadReport(report)
                          }}
                          className="p-2 text-gray-400 hover:text-gray-600"
                        >
                          <ArrowDownTrayIcon className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button
                onClick={() => generateReport('delivery')}
                className="w-full flex items-center justify-start px-4 py-3 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100"
              >
                <DocumentTextIcon className="h-5 w-5 mr-3" />
                <span>Delivery Report</span>
              </button>
              <button
                onClick={() => generateReport('performance')}
                className="w-full flex items-center justify-start px-4 py-3 bg-green-50 text-green-700 rounded-lg hover:bg-green-100"
              >
                <ChartBarIcon className="h-5 w-5 mr-3" />
                <span>Performance Report</span>
              </button>
              <button
                onClick={() => generateReport('financial')}
                className="w-full flex items-center justify-start px-4 py-3 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100"
              >
                <CurrencyDollarIcon className="h-5 w-5 mr-3" />
                <span>Financial Report</span>
              </button>
              <button
                onClick={() => generateReport('fleet')}
                className="w-full flex items-center justify-start px-4 py-3 bg-orange-50 text-orange-700 rounded-lg hover:bg-orange-100"
              >
                <TruckIcon className="h-5 w-5 mr-3" />
                <span>Fleet Report</span>
              </button>
            </div>
          </div>

          {/* Report Statistics */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Statistics</h3>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Total Reports</span>
                <span className="font-semibold">{reports.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">This Month</span>
                <span className="font-semibold">{Math.floor(reports.length * 0.6)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">This Week</span>
                <span className="font-semibold">{Math.floor(reports.length * 0.2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Total Size</span>
                <span className="font-semibold">{(reports.reduce((acc, r) => acc + r.size, 0) / 1024).toFixed(1)} KB</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Report Detail Modal */}
      {selectedReport && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
            <div className="px-6 py-4 border-b flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">{selectedReport.name}</h3>
              <button
                onClick={() => setSelectedReport(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>
            <div className="p-6">
              <div className="mb-4">
                <div className="flex items-center text-sm text-gray-600 mb-2">
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  Generated: {new Date(selectedReport.generatedAt).toLocaleString()}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <FunnelIcon className="h-4 w-4 mr-2" />
                  Type: <span className={`ml-1 px-2 py-1 text-xs font-medium rounded-full ${getTypeColor(selectedReport.type)}`}>
                    {selectedReport.type}
                  </span>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-3">Report Data</h4>
                <pre className="text-sm text-gray-700 overflow-x-auto">
                  {JSON.stringify(selectedReport.data, null, 2)}
                </pre>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={() => downloadReport(selectedReport)}
                  className="flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-blue-700"
                >
                  <ArrowDownTrayIcon className="h-4 w-4 mr-2" />
                  Download Report
                </button>
                <button
                  onClick={() => setSelectedReport(null)}
                  className="px-4 py-2 bg-gray-200 border border-transparent rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-300"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
