'use client'

import { useState, useEffect } from 'react'
import { 
  TruckIcon, 
  UserIcon, 
  MapPinIcon, 
  PlusIcon,
  PencilIcon,
  TrashIcon,
  ClockIcon
} from '@heroicons/react/24/outline'

export default function FleetManagementPage() {
  const [activeTab, setActiveTab] = useState('vehicles')
  const [vehicles, setVehicles] = useState([])
  const [drivers, setDrivers] = useState([])
  const [depots, setDepots] = useState([])
  const [showModal, setShowModal] = useState(false)
  const [editingItem, setEditingItem] = useState(null)
  const [newItem, setNewItem] = useState({})

  useEffect(() => {
    // Load mock data
    setVehicles([
      {
        id: 'VH001',
        type: 'Van',
        licensePlate: 'MH12 AB 1234',
        capacity: { weight: 500, volume: 20 },
        fuel: 'Diesel',
        costPerKm: 8.5,
        status: 'active',
        driver: 'DRV001',
        location: { lat: 17.3850, lng: 78.4867, address: 'MG Road, Hyderabad' }
      },
      {
        id: 'VH002',
        type: 'Bike',
        licensePlate: 'MH12 CD 5678',
        capacity: { weight: 50, volume: 5 },
        fuel: 'Petrol',
        costPerKm: 3.2,
        status: 'active',
        driver: 'DRV002',
        location: { lat: 17.4250, lng: 78.4750, address: 'HITEC City, Hyderabad' }
      },
      {
        id: 'VH003',
        type: 'Truck',
        licensePlate: 'MH12 EF 9012',
        capacity: { weight: 2000, volume: 100 },
        fuel: 'Diesel',
        costPerKm: 12.8,
        status: 'maintenance',
        driver: null,
        location: { lat: 17.3650, lng: 78.4550, address: 'Secunderabad, Hyderabad' }
      }
    ])

    setDrivers([
      {
        id: 'DRV001',
        name: 'Raj Kumar',
        phone: '+91 98765 43210',
        license: 'DL-123456789',
        assignedVehicle: 'VH001',
        shiftStart: '08:00',
        shiftEnd: '18:00',
        status: 'active',
        performance: { deliveries: 145, rating: 4.8, onTimeRate: 92 }
      },
      {
        id: 'DRV002',
        name: 'Sarah Johnson',
        phone: '+91 87654 32109',
        license: 'DL-987654321',
        assignedVehicle: 'VH002',
        shiftStart: '09:00',
        shiftEnd: '17:00',
        status: 'active',
        performance: { deliveries: 132, rating: 4.9, onTimeRate: 95 }
      },
      {
        id: 'DRV003',
        name: 'Mike Chen',
        phone: '+91 76543 21098',
        license: 'DL-456789123',
        assignedVehicle: null,
        shiftStart: '10:00',
        shiftEnd: '20:00',
        status: 'off',
        performance: { deliveries: 98, rating: 4.7, onTimeRate: 89 }
      }
    ])

    setDepots([
      {
        id: 'DEP001',
        name: 'Hyderabad Central',
        address: 'Tank Bund Road, Hyderabad',
        location: { lat: 17.4245, lng: 78.4718 },
        capacity: 50,
        manager: 'John Smith',
        phone: '+91 23456 78901',
        operatingHours: '06:00 - 22:00'
      },
      {
        id: 'DEP002',
        name: 'HITEC City Depot',
        address: 'HITEC City, Hyderabad',
        location: { lat: 17.4380, lng: 78.4560 },
        capacity: 30,
        manager: 'Alice Brown',
        phone: '+91 34567 89012',
        operatingHours: '07:00 - 21:00'
      },
      {
        id: 'DEP003',
        name: 'Kukatpally Depot',
        address: 'Kukatpally, Hyderabad',
        location: { lat: 17.4947, lng: 78.3980 },
        capacity: 25,
        manager: 'Bob Wilson',
        phone: '+91 45678 90123',
        operatingHours: '08:00 - 20:00'
      }
    ])
  }, [])

  const tabs = [
    { id: 'vehicles', name: 'Vehicles', icon: TruckIcon },
    { id: 'drivers', name: 'Drivers', icon: UserIcon },
    { id: 'depots', name: 'Depots', icon: MapPinIcon }
  ]

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700'
      case 'maintenance': return 'bg-yellow-100 text-yellow-700'
      case 'off': return 'bg-gray-100 text-gray-700'
      default: return 'bg-gray-100 text-gray-700'
    }
  }

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Fleet Management</h1>
        <p className="text-gray-600">Manage vehicles, drivers, and depot operations</p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="h-5 w-5 inline mr-2" />
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      {/* Vehicles Tab */}
      {activeTab === 'vehicles' && (
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Vehicle Fleet</h2>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              <PlusIcon className="h-4 w-4 mr-2" />
              Add Vehicle
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vehicles.map(vehicle => (
              <div key={vehicle.id} className="bg-white rounded-lg shadow p-6 border">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-gray-900">{vehicle.id}</h3>
                    <p className="text-sm text-gray-600">{vehicle.type}</p>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded ${getStatusColor(vehicle.status)}`}>
                    {vehicle.status}
                  </span>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">License:</span>
                    <span className="font-medium">{vehicle.licensePlate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Capacity:</span>
                    <span className="font-medium">{vehicle.capacity.weight}kg / {vehicle.capacity.volume}m³</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Fuel:</span>
                    <span className="font-medium">{vehicle.fuel}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Cost/km:</span>
                    <span className="font-medium">₹{vehicle.costPerKm}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Driver:</span>
                    <span className="font-medium">{vehicle.driver || 'Unassigned'}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <MapPinIcon className="h-4 w-4 mr-1" />
                    <span className="text-xs">{vehicle.location.address}</span>
                  </div>
                </div>

                <div className="mt-4 flex justify-end space-x-2">
                  <button className="p-2 text-gray-600 hover:text-blue-600">
                    <PencilIcon className="h-4 w-4" />
                  </button>
                  <button className="p-2 text-gray-600 hover:text-red-600">
                    <TrashIcon className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Drivers Tab */}
      {activeTab === 'drivers' && (
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Driver Management</h2>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              <PlusIcon className="h-4 w-4 mr-2" />
              Add Driver
            </button>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Driver
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Contact
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Vehicle
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Shift
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Performance
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {drivers.map(driver => (
                  <tr key={driver.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{driver.name}</div>
                        <div className="text-sm text-gray-500">{driver.id}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{driver.phone}</div>
                      <div className="text-sm text-gray-500">{driver.license}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {driver.assignedVehicle || 'Unassigned'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center text-sm text-gray-900">
                        <ClockIcon className="h-4 w-4 mr-1" />
                        {driver.shiftStart} - {driver.shiftEnd}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        <div>Deliveries: {driver.performance.deliveries}</div>
                        <div>Rating: ⭐ {driver.performance.rating}</div>
                        <div>On-time: {driver.performance.onTimeRate}%</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded ${getStatusColor(driver.status)}`}>
                        {driver.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Depots Tab */}
      {activeTab === 'depots' && (
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Depot Operations</h2>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              <PlusIcon className="h-4 w-4 mr-2" />
              Add Depot
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {depots.map(depot => (
              <div key={depot.id} className="bg-white rounded-lg shadow p-6 border">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-900">{depot.name}</h3>
                  <span className="text-sm text-gray-500">{depot.id}</span>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-center text-gray-600">
                    <MapPinIcon className="h-4 w-4 mr-2" />
                    <span>{depot.address}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Capacity:</span>
                    <span className="font-medium">{depot.capacity} vehicles</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Manager:</span>
                    <span className="font-medium">{depot.manager}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Phone:</span>
                    <span className="font-medium">{depot.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Hours:</span>
                    <span className="font-medium">{depot.operatingHours}</span>
                  </div>
                </div>

                <div className="mt-4 flex justify-end space-x-2">
                  <button className="p-2 text-gray-600 hover:text-blue-600">
                    <PencilIcon className="h-4 w-4" />
                  </button>
                  <button className="p-2 text-gray-600 hover:text-red-600">
                    <TrashIcon className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {editingItem ? 'Edit Item' : `Add ${activeTab.charAt(0).toUpperCase() + activeTab.slice(1, -1)}`}
              </h3>
              
              {activeTab === 'vehicles' && (
                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Vehicle ID"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.id || ''}
                    onChange={(e) => setNewItem({...newItem, id: e.target.value})}
                  />
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.type || ''}
                    onChange={(e) => setNewItem({...newItem, type: e.target.value})}
                  >
                    <option value="">Select Type</option>
                    <option value="Bike">Bike</option>
                    <option value="Van">Van</option>
                    <option value="Truck">Truck</option>
                  </select>
                  <input
                    type="text"
                    placeholder="License Plate"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.licensePlate || ''}
                    onChange={(e) => setNewItem({...newItem, licensePlate: e.target.value})}
                  />
                  <input
                    type="number"
                    placeholder="Capacity (kg)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.capacity || ''}
                    onChange={(e) => setNewItem({...newItem, capacity: {weight: parseInt(e.target.value), volume: 20}})}
                  />
                </div>
              )}

              {activeTab === 'drivers' && (
                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Driver ID"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.id || ''}
                    onChange={(e) => setNewItem({...newItem, id: e.target.value})}
                  />
                  <input
                    type="text"
                    placeholder="Name"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.name || ''}
                    onChange={(e) => setNewItem({...newItem, name: e.target.value})}
                  />
                  <input
                    type="text"
                    placeholder="Phone"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.phone || ''}
                    onChange={(e) => setNewItem({...newItem, phone: e.target.value})}
                  />
                  <input
                    type="text"
                    placeholder="License Number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.license || ''}
                    onChange={(e) => setNewItem({...newItem, license: e.target.value})}
                  />
                </div>
              )}

              {activeTab === 'depots' && (
                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Depot ID"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.id || ''}
                    onChange={(e) => setNewItem({...newItem, id: e.target.value})}
                  />
                  <input
                    type="text"
                    placeholder="Name"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.name || ''}
                    onChange={(e) => setNewItem({...newItem, name: e.target.value})}
                  />
                  <input
                    type="text"
                    placeholder="Address"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.address || ''}
                    onChange={(e) => setNewItem({...newItem, address: e.target.value})}
                  />
                  <input
                    type="text"
                    placeholder="Manager"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newItem.manager || ''}
                    onChange={(e) => setNewItem({...newItem, manager: e.target.value})}
                  />
                </div>
              )}

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  onClick={() => {
                    setShowModal(false)
                    setEditingItem(null)
                    setNewItem({})
                  }}
                  className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    // Add new item to appropriate list
                    if (activeTab === 'vehicles') {
                      const newVehicle = {
                        ...newItem,
                        status: 'active',
                        fuel: 'Diesel',
                        costPerKm: 8.5,
                        location: { lat: 17.3850, lng: 78.4867, address: 'Hyderabad' }
                      }
                      setVehicles([...vehicles, newVehicle])
                    } else if (activeTab === 'drivers') {
                      const newDriver = {
                        ...newItem,
                        shiftStart: '09:00',
                        shiftEnd: '18:00',
                        performance: 95
                      }
                      setDrivers([...drivers, newDriver])
                    } else if (activeTab === 'depots') {
                      const newDepot = {
                        ...newItem,
                        capacity: 50,
                        phone: '000-000-0000',
                        operatingHours: '24/7'
                      }
                      setDepots([...depots, newDepot])
                    }
                    setShowModal(false)
                    setEditingItem(null)
                    setNewItem({})
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  {editingItem ? 'Update' : 'Add'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
