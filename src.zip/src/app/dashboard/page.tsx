'use client'

import { useState, useEffect } from 'react'
import { 
  TruckIcon, 
  ClipboardDocumentListIcon, 
  CheckCircleIcon,
  ClockIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  BoltIcon,
  CurrencyDollarIcon
} from '@heroicons/react/24/outline'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

interface DashboardMetrics {
  totalOrders: number
  activeVehicles: number
  completedDeliveries: number
  averageDeliveryTime: string
  distanceReduction: string
  costSavings: string
}

interface ChartData {
  name: string
  deliveries: number
  fuel: number
}

export default function Dashboard() {
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalOrders: 0,
    activeVehicles: 0,
    completedDeliveries: 0,
    averageDeliveryTime: '0 days',
    distanceReduction: '0%',
    costSavings: '₹0/day'
  })

  const [chartData, setChartData] = useState<ChartData[]>([
    { name: 'Mon', deliveries: 45, fuel: 120 },
    { name: 'Tue', deliveries: 52, fuel: 132 },
    { name: 'Wed', deliveries: 38, fuel: 102 },
    { name: 'Thu', deliveries: 65, fuel: 148 },
    { name: 'Fri', deliveries: 48, fuel: 125 },
    { name: 'Sat', deliveries: 58, fuel: 138 },
    { name: 'Sun', deliveries: 42, fuel: 115 }
  ])

  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardMetrics()
  }, [])

  const fetchDashboardMetrics = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/dashboard/metrics')
      if (response.ok) {
        const data = await response.json()
        setMetrics(data)
      }
    } catch (error) {
      console.error('Failed to fetch dashboard metrics:', error)
    } finally {
      setLoading(false)
    }
  }

  const kpiCards = [
    {
      title: 'Total Orders Today',
      value: metrics.totalOrders,
      icon: ClipboardDocumentListIcon,
      color: 'bg-blue-500',
      trend: '+12%'
    },
    {
      title: 'Active Vehicles',
      value: metrics.activeVehicles,
      icon: TruckIcon,
      color: 'bg-green-500',
      trend: '+5%'
    },
    {
      title: 'Completed Deliveries',
      value: metrics.completedDeliveries,
      icon: CheckCircleIcon,
      color: 'bg-purple-500',
      trend: '+18%'
    },
    {
      title: 'Average Delivery Time',
      value: metrics.averageDeliveryTime,
      icon: ClockIcon,
      color: 'bg-orange-500',
      trend: '-25%'
    }
  ]

  const performanceCards = [
    {
      title: 'Distance Reduction',
      value: metrics.distanceReduction,
      icon: ArrowTrendingDownIcon,
      color: 'bg-emerald-500',
      description: 'vs traditional routing'
    },
    {
      title: 'Cost Savings',
      value: metrics.costSavings,
      icon: CurrencyDollarIcon,
      color: 'bg-indigo-500',
      description: 'daily operational savings'
    },
    {
      title: 'Fuel Efficiency',
      value: '28%',
      icon: BoltIcon,
      color: 'bg-cyan-500',
      description: 'reduction in fuel consumption'
    },
    {
      title: 'Optimization Rate',
      value: '92%',
      icon: ArrowTrendingUpIcon,
      color: 'bg-rose-500',
      description: 'route optimization success'
    }
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Overview of your fleet operations</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiCards.map((card, index) => (
          <div key={index} className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{card.title}</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">{card.value}</p>
                <p className="text-sm text-green-600 mt-1">{card.trend}</p>
              </div>
              <div className={`p-3 rounded-full ${card.color}`}>
                <card.icon className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {performanceCards.map((card, index) => (
          <div key={index} className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{card.title}</p>
                <p className="text-xl font-bold text-gray-900 mt-2">{card.value}</p>
                <p className="text-xs text-gray-500 mt-1">{card.description}</p>
              </div>
              <div className={`p-2 rounded-full ${card.color}`}>
                <card.icon className="h-5 w-5 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Delivery Performance Chart */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Delivery Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line 
                type="monotone" 
                dataKey="deliveries" 
                stroke="#3B82F6" 
                strokeWidth={2}
                name="Deliveries"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Fuel Usage Chart */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Fuel Usage (Liters)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="fuel" fill="#10B981" name="Fuel Usage" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <div className="flex-shrink-0">
              <CheckCircleIcon className="h-5 w-5 text-green-500" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-900">Route optimization completed for Vehicle MH12 AB 1234</p>
              <p className="text-xs text-gray-500">2 minutes ago</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex-shrink-0">
              <TruckIcon className="h-5 w-5 text-blue-500" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-900">New vehicle added to fleet: MH12 CD 5678</p>
              <p className="text-xs text-gray-500">15 minutes ago</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex-shrink-0">
              <ClipboardDocumentListIcon className="h-5 w-5 text-purple-500" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-900">12 new orders imported from CSV</p>
              <p className="text-xs text-gray-500">1 hour ago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
