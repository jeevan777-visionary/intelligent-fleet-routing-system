'use client'

import { useState, useEffect } from 'react'
import { 
  MapPinIcon,
  ClockIcon,
  CheckCircleIcon,
  PhoneIcon,
  MapIcon
} from '@heroicons/react/24/outline'

export default function DriverNavigationPage() {
  const [currentStop, setCurrentStop] = useState(null)
  const [routeProgress, setRouteProgress] = useState(0)

  useEffect(() => {
    setRouteProgress(33)
    setCurrentStop({
      id: 'STOP001',
      customerName: 'Tech Park A',
      address: 'HITEC City, Hyderabad',
      status: 'in_progress',
      estimatedArrival: '09:45',
      priority: 'High'
    })
  }, [])

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="bg-blue-600 text-white p-4 rounded-lg mb-4">
        <h1 className="text-xl font-bold">Driver Navigation</h1>
        <p className="text-blue-100">VH001 • Raj Kumar</p>
      </div>

      {currentStop && (
        <div className="bg-white rounded-lg shadow p-6 mb-4">
          <h2 className="text-lg font-bold text-gray-900 mb-2">Next Stop</h2>
          <p className="text-gray-600 mb-1">{currentStop.customerName}</p>
          <p className="text-gray-500 mb-4">{currentStop.address}</p>
          
          <div className="flex items-center space-x-3 mb-4">
            <div className="flex items-center text-gray-700">
              <MapPinIcon className="h-5 w-5 mr-2 text-gray-400" />
              <span>{currentStop.address}</span>
            </div>
            
            <div className="flex items-center text-gray-700">
              <ClockIcon className="h-5 w-5 mr-2 text-gray-400" />
              <span>ETA: {currentStop.estimatedArrival}</span>
            </div>
          </div>
          
          <div className="flex space-x-3">
            <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
              I've Arrived
            </button>
            <button className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700 flex items-center">
              <CheckCircleIcon className="h-5 w-5 mr-2" />
              Delivered
            </button>
            <button className="bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700">
              Report Issue
            </button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow p-4">
        <h3 className="font-medium text-gray-900 mb-2">Route Progress</h3>
        <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
          <div 
            className="bg-blue-500 h-3 rounded-full"
            style={{ width: `${routeProgress}%` }}
          />
        </div>
        <p className="text-sm text-gray-600">1 of 3 stops completed</p>
      </div>

      <div className="bg-white rounded-lg shadow p-4 mt-4">
        <h3 className="font-medium text-gray-900 mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3">
          <button className="flex items-center justify-center p-3 bg-gray-100 rounded-lg hover:bg-gray-200">
            <PhoneIcon className="h-5 w-5 mr-2" />
            <span className="text-sm">Call Customer</span>
          </button>
          <button className="flex items-center justify-center p-3 bg-gray-100 rounded-lg hover:bg-gray-200">
            <MapIcon className="h-5 w-5 mr-2" />
            <span className="text-sm">View Map</span>
          </button>
        </div>
      </div>
    </div>
  )
}
