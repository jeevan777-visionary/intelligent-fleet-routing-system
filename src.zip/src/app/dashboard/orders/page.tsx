'use client'

import { useState, useEffect } from 'react'
import { 
  PlusIcon, 
  DocumentArrowDownIcon, 
  PencilIcon,
  TrashIcon,
  EyeIcon,
  FunnelIcon,
  MagnifyingGlassIcon
} from '@heroicons/react/24/outline'

interface Order {
  id: string
  customerName: string
  deliveryAddress: string
  pickupAddress?: string
  latitude: number
  longitude: number
  pickupLatitude?: number
  pickupLongitude?: number
  destinationLatitude?: number
  destinationLongitude?: number
  priority: 'low' | 'medium' | 'high'
  deliveryTimeWindow: string
  packageWeight: number
  packageVolume: number
  status: 'pending' | 'assigned' | 'in_transit' | 'delivered' | 'failed'
  createdAt: string
  assignedVehicle?: string
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [showViewModal, setShowViewModal] = useState(false)

  const [newOrder, setNewOrder] = useState({
    customerName: '',
    deliveryAddress: '',
    latitude: 0,
    longitude: 0,
    priority: 'medium' as 'low' | 'medium' | 'high',
    deliveryTimeWindow: '',
    packageWeight: 0,
    packageVolume: 0
  })

  useEffect(() => {
    fetchOrders()
  }, [])

  const fetchOrders = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/orders')
      if (response.ok) {
        const data = await response.json()
        setOrders(data)
      } else {
        // Use mock data if API is not available
        setOrders([
          {
            id: '1',
            customerName: 'Rajesh Kumar',
            deliveryAddress: '123 MG Road, Pune, Maharashtra 411001',
            latitude: 18.5204,
            longitude: 73.8567,
            priority: 'high',
            deliveryTimeWindow: '09:00-12:00',
            packageWeight: 2.5,
            packageVolume: 0.003,
            status: 'pending',
            createdAt: '2024-01-15T08:30:00Z'
          },
          {
            id: '2',
            customerName: 'Priya Sharma',
            deliveryAddress: '456 FC Road, Pune, Maharashtra 411016',
            latitude: 18.5314,
            longitude: 73.8446,
            priority: 'medium',
            deliveryTimeWindow: '14:00-18:00',
            packageWeight: 1.2,
            packageVolume: 0.002,
            status: 'assigned',
            createdAt: '2024-01-15T09:15:00Z',
            assignedVehicle: 'MH12 AB 1234'
          },
          {
            id: '3',
            customerName: 'Amit Patel',
            deliveryAddress: '789 JM Road, Pune, Maharashtra 411030',
            latitude: 18.5167,
            longitude: 73.8511,
            priority: 'low',
            deliveryTimeWindow: '10:00-16:00',
            packageWeight: 3.8,
            packageVolume: 0.005,
            status: 'delivered',
            createdAt: '2024-01-15T07:45:00Z',
            assignedVehicle: 'MH12 CD 5678'
          }
        ])
      }
    } catch (error) {
      console.error('Failed to fetch orders:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddOrder = async () => {
    try {
      // Validate required fields
      if (!newOrder.customerName || !newOrder.deliveryAddress) {
        alert('Please fill in customer name and destination address.')
        return
      }

      // Detect current GPS location
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            const currentLat = position.coords.latitude
            const currentLng = position.coords.longitude
            
            console.log("Current GPS Location:", currentLat, currentLng)
            
            // Create order with actual GPS coordinates as pickup location
            const orderWithGPS = {
              ...newOrder,
              pickupLatitude: currentLat,
              pickupLongitude: currentLng,
              pickupAddress: `GPS Location: ${currentLat.toFixed(4)}, ${currentLng.toFixed(4)}`,
              // Convert destination address to coordinates (mock for now)
              destinationLatitude: 17.2403, // Hyderabad Airport (example)
              destinationLongitude: 78.4294,
              status: 'pending' as const
            }
            
            console.log("Order with GPS:", orderWithGPS)
            
            try {
              const response = await fetch('http://localhost:8001/api/orders', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify(orderWithGPS),
              })

              if (response.ok) {
                const createdOrder = await response.json()
                setOrders([...orders, createdOrder])
                setShowAddModal(false)
                setNewOrder({
                  customerName: '',
                  deliveryAddress: '',
                  latitude: 0,
                  longitude: 0,
                  priority: 'medium',
                  deliveryTimeWindow: '',
                  packageWeight: 0,
                  packageVolume: 0
                })
                
                // Redirect to delivery plan page for driver assignment
                window.location.href = '/delivery-plan'
                
                alert('Order created successfully with GPS location!')
                console.log("Triggering route optimization for new order...")
                // TODO: Call route optimization API
              } else {
                // If API fails, create order locally with mock data
                console.log("API not available, creating order locally...")
                const mockOrder = {
                  id: Date.now().toString(),
                  ...orderWithGPS,
                  createdAt: new Date().toISOString()
                }
                setOrders([...orders, mockOrder])
                setShowAddModal(false)
                setNewOrder({
                  customerName: '',
                  deliveryAddress: '',
                  latitude: 0,
                  longitude: 0,
                  priority: 'medium',
                  deliveryTimeWindow: '',
                  packageWeight: 0,
                  packageVolume: 0
                })
                
                // Redirect to delivery plan page even in fallback mode
                window.location.href = '/delivery-plan'
                
                alert('Order created successfully with GPS location! (Demo Mode)')
              }
            } catch (apiError) {
              console.error("API Error:", apiError)
              // Fallback: create order locally
              const mockOrder = {
                id: Date.now().toString(),
                ...orderWithGPS,
                createdAt: new Date().toISOString()
              }
              setOrders([...orders, mockOrder])
              setShowAddModal(false)
              setNewOrder({
                customerName: '',
                deliveryAddress: '',
                latitude: 0,
                longitude: 0,
                priority: 'medium',
                deliveryTimeWindow: '',
                packageWeight: 0,
                packageVolume: 0
              })
              
              // Redirect to delivery plan page even in error case
              window.location.href = '/delivery-plan'
              
              alert('Order created successfully with GPS location! (Demo Mode - Backend not available)')
            }
          },
          (error) => {
            console.error("GPS Error:", error)
            // Fallback to default Hyderabad location if GPS fails
            const fallbackOrder = {
              ...newOrder,
              pickupLatitude: 17.3850, // Default Hyderabad location
              pickupLongitude: 78.4867,
              pickupAddress: 'Hyderabad, India (Default Location)',
              destinationLatitude: 17.2403,
              destinationLongitude: 78.4294,
              status: 'pending' as const
            }
            
            console.log("Using fallback location:", fallbackOrder)
            
            // Create order with fallback location
            const mockOrder = {
              id: Date.now().toString(),
              ...fallbackOrder,
              createdAt: new Date().toISOString()
            }
            setOrders([...orders, mockOrder])
            setShowAddModal(false)
            setNewOrder({
              customerName: '',
              deliveryAddress: '',
              latitude: 0,
              longitude: 0,
              priority: 'medium',
              deliveryTimeWindow: '',
              packageWeight: 0,
              packageVolume: 0
            })
            
            // Redirect to delivery plan page even in GPS error case
            window.location.href = '/delivery-plan'
            
            alert('Order created with default Hyderabad location! (GPS not available)')
          }
        )
      } else {
        alert("Geolocation is not supported by this browser.")
      }
    } catch (error) {
      console.error('Failed to create order:', error)
      alert('Failed to create order. Please try again.')
    }
  }

  const handleCSVImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      // Handle CSV import logic here
      console.log('Importing CSV:', file.name)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800'
      case 'assigned': return 'bg-blue-100 text-blue-800'
      case 'in_transit': return 'bg-purple-100 text-purple-800'
      case 'delivered': return 'bg-green-100 text-green-800'
      case 'failed': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800'
      case 'medium': return 'bg-orange-100 text-orange-800'
      case 'low': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.deliveryAddress.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterStatus === 'all' || order.status === filterStatus
    return matchesSearch && matchesFilter
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Orders Management</h1>
          <p className="text-gray-600">Manage and track delivery orders</p>
        </div>
        <div className="flex space-x-3">
          <label className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 cursor-pointer">
            <DocumentArrowDownIcon className="h-4 w-4 mr-2" />
            Import CSV
            <input
              type="file"
              accept=".csv"
              onChange={handleCSVImport}
              className="hidden"
            />
          </label>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-blue-700"
          >
            <PlusIcon className="h-4 w-4 mr-2" />
            Add Order
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search orders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <FunnelIcon className="h-4 w-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="assigned">Assigned</option>
              <option value="in_transit">In Transit</option>
              <option value="delivered">Delivered</option>
              <option value="failed">Failed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Order ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Address
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Priority
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Time Window
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Vehicle
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredOrders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    #{order.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {order.customerName}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    <div className="max-w-xs truncate" title={order.deliveryAddress}>
                      {order.deliveryAddress}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(order.priority)}`}>
                      {order.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {order.deliveryTimeWindow}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(order.status)}`}>
                      {order.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {order.assignedVehicle || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          setSelectedOrder(order)
                          setShowViewModal(true)
                        }}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <EyeIcon className="h-4 w-4" />
                      </button>
                      <button className="text-green-600 hover:text-green-900">
                        <PencilIcon className="h-4 w-4" />
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Order Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Add New Order</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Customer Name</label>
                <input
                  type="text"
                  value={newOrder.customerName}
                  onChange={(e) => setNewOrder({...newOrder, customerName: e.target.value})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter customer name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700">Pickup Location (Auto GPS)</label>
                <div className="mt-1 flex items-center space-x-2">
                  <input
                    type="text"
                    value="Detecting GPS location..."
                    readOnly
                    className="flex-1 px-3 py-2 bg-gray-100 border border-gray-300 rounded-md text-gray-600"
                    placeholder="Will auto-detect when you click Add Order"
                  />
                  <div className="text-xs text-green-600">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l4.95-4.95a7 7 0 11-9.9-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                    </svg>
                    GPS Auto
                  </div>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700">Destination Location</label>
                <input
                  type="text"
                  value={newOrder.deliveryAddress}
                  onChange={(e) => setNewOrder({...newOrder, deliveryAddress: e.target.value})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter destination address (e.g., Hyderabad Airport)"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Priority</label>
                  <select
                    value={newOrder.priority}
                    onChange={(e) => setNewOrder({...newOrder, priority: e.target.value as 'low' | 'medium' | 'high'})}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Package Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newOrder.packageWeight}
                    onChange={(e) => setNewOrder({...newOrder, packageWeight: parseFloat(e.target.value)})}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    placeholder="0.0"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Package Volume (m³)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newOrder.packageVolume}
                    onChange={(e) => setNewOrder({...newOrder, packageVolume: parseFloat(e.target.value)})}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    placeholder="0.0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Delivery Time Window</label>
                  <input
                    type="text"
                    value={newOrder.deliveryTimeWindow}
                    onChange={(e) => setNewOrder({...newOrder, deliveryTimeWindow: e.target.value})}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., 09:00-12:00"
                  />
                </div>
              </div>
            </div>
            <div className="mt-6 flex justify-end space-x-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
              <button
                onClick={handleAddOrder}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
              >
                <PlusIcon className="h-4 w-4 mr-2" />
                Add Order with GPS
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Order Modal */}
      {showViewModal && selectedOrder && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Order Details</h3>
            <div className="space-y-3">
              <div><strong>Order ID:</strong> #{selectedOrder.id}</div>
              <div><strong>Customer:</strong> {selectedOrder.customerName}</div>
              <div><strong>Address:</strong> {selectedOrder.deliveryAddress}</div>
              <div><strong>Coordinates:</strong> {selectedOrder.latitude}, {selectedOrder.longitude}</div>
              <div><strong>Priority:</strong> <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(selectedOrder.priority)}`}>{selectedOrder.priority}</span></div>
              <div><strong>Time Window:</strong> {selectedOrder.deliveryTimeWindow}</div>
              <div><strong>Weight:</strong> {selectedOrder.packageWeight} kg</div>
              <div><strong>Volume:</strong> {selectedOrder.packageVolume} m³</div>
              <div><strong>Status:</strong> <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(selectedOrder.status)}`}>{selectedOrder.status.replace('_', ' ')}</span></div>
              <div><strong>Vehicle:</strong> {selectedOrder.assignedVehicle || 'Not assigned'}</div>
              <div><strong>Created:</strong> {new Date(selectedOrder.createdAt).toLocaleString()}</div>
            </div>
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowViewModal(false)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
