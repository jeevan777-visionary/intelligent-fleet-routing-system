'use client'

import { useState, useEffect } from 'react'
import { 
  PlayIcon, 
  StopIcon,
  ChartBarIcon,
  CpuChipIcon,
  BeakerIcon,
  ArrowPathIcon,
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon
} from '@heroicons/react/24/outline'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

interface OptimizationResult {
  optimization_id: string
  algorithm: string
  qubits_used: number
  classical_time: string
  quantum_time: string
  improvement: string
  routes: Route[]
  savings: {
    distance: string
    time: string
    fuel: string
    cost: string
  }
  status: 'running' | 'completed' | 'failed'
  created_at: string
}

interface Route {
  vehicle: string
  driver: string
  optimized_route: string[]
  distance: string
  time: string
  quantum_score: number
}

export default function OptimizationPage() {
  const [isRunning, setIsRunning] = useState(false)
  const [progress, setProgress] = useState(0)
  const [currentStage, setCurrentStage] = useState<'idle' | 'classical' | 'quantum' | 'completed'>('idle')
  const [results, setResults] = useState<OptimizationResult | null>(null)
  const [comparisonData, setComparisonData] = useState<any[]>([])
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<'classical' | 'hybrid'>('hybrid')
  const [optimizationHistory, setOptimizationHistory] = useState<OptimizationResult[]>([])

  useEffect(() => {
    fetchOptimizationHistory()
  }, [])

  const fetchOptimizationHistory = async () => {
    try {
      // Mock history data
      setOptimizationHistory([
        {
          optimization_id: 'opt_001',
          algorithm: 'Hybrid Quantum-Classical',
          qubits_used: 8,
          classical_time: '180 seconds',
          quantum_time: '45 seconds',
          improvement: '75% faster',
          routes: [],
          savings: {
            distance: '35%',
            time: '50%',
            fuel: '28%',
            cost: '₹1,250/day'
          },
          status: 'completed',
          created_at: '2024-01-15T10:30:00Z'
        },
        {
          optimization_id: 'opt_002',
          algorithm: 'Classical OR-Tools',
          qubits_used: 0,
          classical_time: '320 seconds',
          quantum_time: '0 seconds',
          improvement: '45% faster',
          routes: [],
          savings: {
            distance: '22%',
            time: '30%',
            fuel: '18%',
            cost: '₹750/day'
          },
          status: 'completed',
          created_at: '2024-01-14T14:15:00Z'
        }
      ])
    } catch (error) {
      console.error('Failed to fetch optimization history:', error)
    }
  }

  const runOptimization = async () => {
    setIsRunning(true)
    setProgress(0)
    setCurrentStage('classical')
    setResults(null)

    // Simulate Stage 1: Classical Optimization
    await simulateProgress(0, 40, 3000, 'classical')
    
    // Simulate Stage 2: Quantum Optimization (if hybrid selected)
    if (selectedAlgorithm === 'hybrid') {
      setCurrentStage('quantum')
      await simulateProgress(40, 90, 2000, 'quantum')
    } else {
      await simulateProgress(40, 90, 1000, 'classical')
    }

    // Final stage
    await simulateProgress(90, 100, 1000, 'completed')
    setCurrentStage('completed')

    // Fetch results
    try {
      const response = await fetch('http://localhost:8000/api/optimize/run', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          algorithm: selectedAlgorithm,
          orders_count: 25,
          vehicles_count: 8
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setResults(data)
        
        // Generate comparison data
        setComparisonData([
          {
            name: 'Distance',
            classical: 45.2,
            optimized: 29.4,
            unit: 'km'
          },
          {
            name: 'Time',
            classical: 320,
            optimized: 180,
            unit: 'min'
          },
          {
            name: 'Fuel',
            classical: 12.5,
            optimized: 9.0,
            unit: 'L'
          },
          {
            name: 'Cost',
            classical: 2500,
            optimized: 1750,
            unit: '₹'
          }
        ])

        // Add to history
        setOptimizationHistory([data, ...optimizationHistory])
      }
    } catch (error) {
      console.error('Failed to run optimization:', error)
    } finally {
      setIsRunning(false)
      setProgress(100)
    }
  }

  const simulateProgress = (start: number, end: number, duration: number, stage: 'classical' | 'quantum' | 'completed') => {
    return new Promise<void>((resolve) => {
      const steps = 20
      const stepDuration = duration / steps
      const stepSize = (end - start) / steps
      let currentStep = 0

      const interval = setInterval(() => {
        currentStep++
        setProgress(start + (stepSize * currentStep))
        
        if (currentStep >= steps) {
          clearInterval(interval)
          resolve()
        }
      }, stepDuration)
    })
  }

  const getStageIcon = (stage: string) => {
    switch (stage) {
      case 'classical': return <CpuChipIcon className="h-5 w-5" />
      case 'quantum': return <BeakerIcon className="h-5 w-5" />
      case 'completed': return <CheckCircleIcon className="h-5 w-5" />
      default: return <ClockIcon className="h-5 w-5" />
    }
  }

  const getStageColor = (stage: string) => {
    switch (stage) {
      case 'classical': return 'text-blue-600'
      case 'quantum': return 'text-purple-600'
      case 'completed': return 'text-green-600'
      default: return 'text-gray-600'
    }
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Route Optimization</h1>
        <p className="text-gray-600">Hybrid Quantum-Classical optimization for delivery routes</p>
      </div>

      {/* Control Panel */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Optimization Control</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Algorithm Type</label>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="radio"
                  value="hybrid"
                  checked={selectedAlgorithm === 'hybrid'}
                  onChange={(e) => setSelectedAlgorithm(e.target.value as 'hybrid')}
                  className="mr-2"
                />
                <span className="text-sm">Hybrid Quantum-Classical</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="classical"
                  checked={selectedAlgorithm === 'classical'}
                  onChange={(e) => setSelectedAlgorithm(e.target.value as 'classical')}
                  className="mr-2"
                />
                <span className="text-sm">Classical OR-Tools Only</span>
              </label>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Optimization Parameters</h3>
            <div className="space-y-1 text-sm text-gray-600">
              <div>Orders: 25 deliveries</div>
              <div>Vehicles: 8 available</div>
              <div>Depots: 2 locations</div>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Expected Performance</h3>
            <div className="space-y-1 text-sm text-gray-600">
              <div>Classical: ~5 minutes</div>
              <div>Hybrid: ~3 minutes</div>
              <div>Improvement: 30-40%</div>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <button
            onClick={runOptimization}
            disabled={isRunning}
            className={`flex items-center px-6 py-3 rounded-md text-white font-medium ${
              isRunning 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            {isRunning ? (
              <>
                <ArrowPathIcon className="h-5 w-5 mr-2 animate-spin" />
                Running Optimization...
              </>
            ) : (
              <>
                <PlayIcon className="h-5 w-5 mr-2" />
                Start Optimization
              </>
            )}
          </button>
          
          {isRunning && (
            <button
              onClick={() => setIsRunning(false)}
              className="flex items-center px-4 py-3 bg-red-600 text-white rounded-md hover:bg-red-700 font-medium"
            >
              <StopIcon className="h-5 w-5 mr-2" />
              Stop
            </button>
          )}
        </div>

        {/* Progress Bar */}
        {isRunning && (
          <div className="mt-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Progress</span>
              <span className="text-sm text-gray-600">{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            
            {/* Stage Indicators */}
            <div className="flex justify-between mt-4">
              <div className={`flex items-center ${currentStage === 'classical' ? getStageColor('classical') : 'text-gray-400'}`}>
                {getStageIcon('classical')}
                <span className="ml-2 text-sm">Classical Optimization</span>
              </div>
              {selectedAlgorithm === 'hybrid' && (
                <div className={`flex items-center ${currentStage === 'quantum' ? getStageColor('quantum') : 'text-gray-400'}`}>
                  {getStageIcon('quantum')}
                  <span className="ml-2 text-sm">Quantum Enhancement</span>
                </div>
              )}
              <div className={`flex items-center ${currentStage === 'completed' ? getStageColor('completed') : 'text-gray-400'}`}>
                {getStageIcon('completed')}
                <span className="ml-2 text-sm">Completed</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Results */}
      {results && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Optimization Results</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">{results.savings.distance}</div>
              <div className="text-sm text-gray-600">Distance Reduction</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">{results.savings.time}</div>
              <div className="text-sm text-gray-600">Time Savings</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">{results.savings.fuel}</div>
              <div className="text-sm text-gray-600">Fuel Reduction</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600">{results.savings.cost}</div>
              <div className="text-sm text-gray-600">Cost Savings</div>
            </div>
          </div>

          {/* Comparison Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-md font-semibold text-gray-900 mb-4">Performance Comparison</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={comparisonData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="classical" fill="#EF4444" name="Classical" />
                  <Bar dataKey="optimized" fill="#10B981" name="Optimized" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            
            <div>
              <h3 className="text-md font-semibold text-gray-900 mb-4">Algorithm Performance</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                  <span className="text-sm font-medium">Classical Time</span>
                  <span className="text-sm text-gray-600">{results.classical_time}</span>
                </div>
                {results.quantum_time !== '0 seconds' && (
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                    <span className="text-sm font-medium">Quantum Time</span>
                    <span className="text-sm text-gray-600">{results.quantum_time}</span>
                  </div>
                )}
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                  <span className="text-sm font-medium">Total Improvement</span>
                  <span className="text-sm font-semibold text-green-600">{results.improvement}</span>
                </div>
                {results.qubits_used > 0 && (
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                    <span className="text-sm font-medium">Qubits Used</span>
                    <span className="text-sm text-gray-600">{results.qubits_used}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Optimized Routes */}
          <div className="mt-6">
            <h3 className="text-md font-semibold text-gray-900 mb-4">Optimized Routes</h3>
            <div className="space-y-3">
              {results.routes.map((route, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-medium text-gray-900">{route.vehicle}</div>
                      <div className="text-sm text-gray-600">Driver: {route.driver}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-900">{route.distance}</div>
                      <div className="text-sm text-gray-600">{route.time}</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">
                      Route: {route.optimized_route.join(' → ')}
                    </div>
                    <div className="flex items-center text-sm">
                      <span className="text-purple-600 font-medium">Quantum Score:</span>
                      <span className="ml-1 text-purple-600">{(route.quantum_score * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Optimization History */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Optimization History</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Algorithm
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Improvement
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cost Savings
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Run Time
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {optimizationHistory.map((run) => (
                <tr key={run.optimization_id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {run.optimization_id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {run.algorithm}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      run.status === 'completed' ? 'bg-green-100 text-green-800' : 
                      run.status === 'running' ? 'bg-blue-100 text-blue-800' : 
                      'bg-red-100 text-red-800'
                    }`}>
                      {run.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {run.improvement}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {run.savings.cost}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {run.classical_time}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {new Date(run.created_at).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
