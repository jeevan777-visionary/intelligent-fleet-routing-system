'use client'

import { useState, useEffect } from 'react'
import { 
  PlusIcon, 
  PencilIcon,
  TrashIcon,
  EyeIcon,
  MagnifyingGlassIcon,
  UserIcon,
  WrenchScrewdriverIcon,
  MapPinIcon,
  ClockIcon,
  TruckIcon
} from '@heroicons/react/24/outline'

interface Vehicle {
  id: string
  vehicleId: string
  type: 'bike' | 'van' | 'truck'
  licensePlate: string
  driver: string
  driverPhone: string
  capacity: {
    weight: number
    volume: number
  }
  status: 'active' | 'inactive' | 'maintenance' | 'on_duty'
  currentLocation: {
    latitude: number
    longitude: number
    address: string
  }
  depot: string
  shiftStart: string
  shiftEnd: string
  fuelLevel: number
  lastMaintenance: string
  nextMaintenance: string
}

export default function FleetPage() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null)
  const [showViewModal, setShowViewModal] = useState(false)

  const [newVehicle, setNewVehicle] = useState({
    vehicleId: '',
    type: 'van' as 'bike' | 'van' | 'truck',
    licensePlate: '',
    driver: '',
    driverPhone: '',
    capacity: {
      weight: 0,
      volume: 0
    },
    depot: '',
    shiftStart: '09:00',
    shiftEnd: '18:00'
  })

  useEffect(() => {
    fetchVehicles()
  }, [])

  const fetchVehicles = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/fleet/vehicles')
      if (response.ok) {
        const data = await response.json()
        setVehicles(data)
      } else {
        // Use mock data if API is not available
        setVehicles([
          {
            id: '1',
            vehicleId: 'VH001',
            type: 'van',
            licensePlate: 'MH12 AB 1234',
            driver: 'Raj Kumar',
            driverPhone: '+91 98765 43210',
            capacity: {
              weight: 500,
              volume: 2.5
            },
            status: 'active',
            currentLocation: {
              latitude: 18.5204,
              longitude: 73.8567,
              address: 'MG Road, Pune'
            },
            depot: 'Pune Central',
            shiftStart: '09:00',
            shiftEnd: '18:00',
            fuelLevel: 75,
            lastMaintenance: '2024-01-01',
            nextMaintenance: '2024-04-01'
          },
          {
            id: '2',
            vehicleId: 'VH002',
            type: 'bike',
            licensePlate: 'MH12 CD 5678',
            driver: 'Sarah Johnson',
            driverPhone: '+91 87654 32109',
            capacity: {
              weight: 20,
              volume: 0.1
            },
            status: 'on_duty',
            currentLocation: {
              latitude: 18.5314,
              longitude: 73.8446,
              address: 'FC Road, Pune'
            },
            depot: 'Pune Central',
            shiftStart: '08:00',
            shiftEnd: '17:00',
            fuelLevel: 90,
            lastMaintenance: '2024-01-05',
            nextMaintenance: '2024-04-05'
          },
          {
            id: '3',
            vehicleId: 'VH003',
            type: 'truck',
            licensePlate: 'MH12 EF 9012',
            driver: 'Mike Chen',
            driverPhone: '+91 76543 21098',
            capacity: {
              weight: 2000,
              volume: 15
            },
            status: 'maintenance',
            currentLocation: {
              latitude: 18.5167,
              longitude: 73.8511,
              address: 'JM Road, Pune'
            },
            depot: 'Pune East',
            shiftStart: '06:00',
            shiftEnd: '15:00',
            fuelLevel: 45,
            lastMaintenance: '2024-01-10',
            nextMaintenance: '2024-02-10'
          }
        ])
      }
    } catch (error) {
      console.error('Failed to fetch vehicles:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddVehicle = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/fleet/vehicles', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newVehicle),
      })

      if (response.ok) {
        const createdVehicle = await response.json()
        setVehicles([...vehicles, createdVehicle])
        setShowAddModal(false)
        setNewVehicle({
          vehicleId: '',
          type: 'van',
          licensePlate: '',
          driver: '',
          driverPhone: '',
          capacity: {
            weight: 0,
            volume: 0
          },
          depot: '',
          shiftStart: '09:00',
          shiftEnd: '18:00'
        })
      }
    } catch (error) {
      console.error('Failed to create vehicle:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800'
      case 'inactive': return 'bg-gray-100 text-gray-800'
      case 'maintenance': return 'bg-red-100 text-red-800'
      case 'on_duty': return 'bg-blue-100 text-blue-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'bike': return '🏍️'
      case 'van': return '🚐'
      case 'truck': return '🚚'
      default: return '🚗'
    }
  }

  const getFuelColor = (level: number) => {
    if (level > 50) return 'text-green-600'
    if (level > 25) return 'text-yellow-600'
    return 'text-red-600'
  }

  const filteredVehicles = vehicles.filter(vehicle => {
    const matchesSearch = vehicle.vehicleId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         vehicle.driver.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         vehicle.licensePlate.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterStatus === 'all' || vehicle.status === filterStatus
    return matchesSearch && matchesFilter
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Fleet Management</h1>
          <p className="text-gray-600">Manage vehicles and drivers</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-blue-700"
        >
          <PlusIcon className="h-4 w-4 mr-2" />
          Add Vehicle
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <TruckIcon className="h-8 w-8 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Vehicles</p>
              <p className="text-2xl font-bold text-gray-900">{vehicles.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <UserIcon className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Active Drivers</p>
              <p className="text-2xl font-bold text-gray-900">
                {vehicles.filter(v => v.status === 'active' || v.status === 'on_duty').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <WrenchScrewdriverIcon className="h-8 w-8 text-red-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">In Maintenance</p>
              <p className="text-2xl font-bold text-gray-900">
                {vehicles.filter(v => v.status === 'maintenance').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ClockIcon className="h-8 w-8 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">On Duty</p>
              <p className="text-2xl font-bold text-gray-900">
                {vehicles.filter(v => v.status === 'on_duty').length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search vehicles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="maintenance">Maintenance</option>
            <option value="on_duty">On Duty</option>
          </select>
        </div>
      </div>

      {/* Vehicles Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Vehicle
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Driver
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Capacity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Location
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Fuel
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Shift
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredVehicles.map((vehicle) => (
                <tr key={vehicle.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="text-2xl mr-3">{getTypeIcon(vehicle.type)}</div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{vehicle.vehicleId}</div>
                        <div className="text-sm text-gray-500">{vehicle.licensePlate}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{vehicle.driver}</div>
                      <div className="text-sm text-gray-500">{vehicle.driverPhone}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      <div>{vehicle.capacity.weight} kg</div>
                      <div className="text-xs text-gray-500">{vehicle.capacity.volume} m³</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(vehicle.status)}`}>
                      {vehicle.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      <div className="flex items-center">
                        <MapPinIcon className="h-4 w-4 mr-1 text-gray-400" />
                        {vehicle.currentLocation.address}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`text-sm font-medium ${getFuelColor(vehicle.fuelLevel)}`}>
                        {vehicle.fuelLevel}%
                      </div>
                      <div className="ml-2 w-12 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            vehicle.fuelLevel > 50 ? 'bg-green-500' : 
                            vehicle.fuelLevel > 25 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${vehicle.fuelLevel}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {vehicle.shiftStart} - {vehicle.shiftEnd}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          setSelectedVehicle(vehicle)
                          setShowViewModal(true)
                        }}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <EyeIcon className="h-4 w-4" />
                      </button>
                      <button className="text-green-600 hover:text-green-900">
                        <PencilIcon className="h-4 w-4" />
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Vehicle Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Add New Vehicle</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Vehicle ID</label>
                <input
                  type="text"
                  value={newVehicle.vehicleId}
                  onChange={(e) => setNewVehicle({...newVehicle, vehicleId: e.target.value})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">License Plate</label>
                <input
                  type="text"
                  value={newVehicle.licensePlate}
                  onChange={(e) => setNewVehicle({...newVehicle, licensePlate: e.target.value})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Vehicle Type</label>
                <select
                  value={newVehicle.type}
                  onChange={(e) => setNewVehicle({...newVehicle, type: e.target.value as 'bike' | 'van' | 'truck'})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="bike">Bike</option>
                  <option value="van">Van</option>
                  <option value="truck">Truck</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Driver Name</label>
                <input
                  type="text"
                  value={newVehicle.driver}
                  onChange={(e) => setNewVehicle({...newVehicle, driver: e.target.value})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Driver Phone</label>
                <input
                  type="text"
                  value={newVehicle.driverPhone}
                  onChange={(e) => setNewVehicle({...newVehicle, driverPhone: e.target.value})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Weight Capacity (kg)</label>
                  <input
                    type="number"
                    value={newVehicle.capacity.weight}
                    onChange={(e) => setNewVehicle({...newVehicle, capacity: {...newVehicle.capacity, weight: parseInt(e.target.value)}})}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Volume Capacity (m³)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newVehicle.capacity.volume}
                    onChange={(e) => setNewVehicle({...newVehicle, capacity: {...newVehicle.capacity, volume: parseFloat(e.target.value)}})}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Depot</label>
                <input
                  type="text"
                  value={newVehicle.depot}
                  onChange={(e) => setNewVehicle({...newVehicle, depot: e.target.value})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Shift Start</label>
                  <input
                    type="time"
                    value={newVehicle.shiftStart}
                    onChange={(e) => setNewVehicle({...newVehicle, shiftStart: e.target.value})}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Shift End</label>
                  <input
                    type="time"
                    value={newVehicle.shiftEnd}
                    onChange={(e) => setNewVehicle({...newVehicle, shiftEnd: e.target.value})}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
            <div className="mt-6 flex justify-end space-x-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
              <button
                onClick={handleAddVehicle}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Add Vehicle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Vehicle Modal */}
      {showViewModal && selectedVehicle && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Vehicle Details</h3>
            <div className="space-y-3">
              <div className="flex items-center">
                <span className="text-2xl mr-3">{getTypeIcon(selectedVehicle.type)}</span>
                <div>
                  <div><strong>Vehicle ID:</strong> {selectedVehicle.vehicleId}</div>
                  <div><strong>License Plate:</strong> {selectedVehicle.licensePlate}</div>
                </div>
              </div>
              <div><strong>Type:</strong> {selectedVehicle.type.charAt(0).toUpperCase() + selectedVehicle.type.slice(1)}</div>
              <div><strong>Driver:</strong> {selectedVehicle.driver}</div>
              <div><strong>Phone:</strong> {selectedVehicle.driverPhone}</div>
              <div><strong>Capacity:</strong> {selectedVehicle.capacity.weight} kg / {selectedVehicle.capacity.volume} m³</div>
              <div><strong>Status:</strong> <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(selectedVehicle.status)}`}>{selectedVehicle.status.replace('_', ' ')}</span></div>
              <div><strong>Location:</strong> {selectedVehicle.currentLocation.address}</div>
              <div><strong>Depot:</strong> {selectedVehicle.depot}</div>
              <div><strong>Shift:</strong> {selectedVehicle.shiftStart} - {selectedVehicle.shiftEnd}</div>
              <div><strong>Fuel Level:</strong> <span className={`font-medium ${getFuelColor(selectedVehicle.fuelLevel)}`}>{selectedVehicle.fuelLevel}%</span></div>
              <div><strong>Last Maintenance:</strong> {selectedVehicle.lastMaintenance}</div>
              <div><strong>Next Maintenance:</strong> {selectedVehicle.nextMaintenance}</div>
            </div>
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowViewModal(false)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
