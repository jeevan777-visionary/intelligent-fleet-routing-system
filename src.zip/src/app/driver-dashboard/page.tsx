'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import dynamic from 'next/dynamic'
import { 
  MapPinIcon, 
  PhoneIcon, 
  ClockIcon, 
  CheckCircleIcon,
  BellIcon,
  UserIcon,
  TruckIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline'

// Dynamically import map to avoid SSR issues
const MapComponent = dynamic(() => import('../../components/DriverMap'), {
  ssr: false,
  loading: () => <div className="h-96 bg-gray-200 rounded-lg flex items-center justify-center">Loading map...</div>
})

export default function DriverDashboard() {
  const [driver, setDriver] = useState<any>(null)
  const [orders, setOrders] = useState<any[]>([])
  const [currentOrder, setCurrentOrder] = useState<any>(null)
  const [currentLocation, setCurrentLocation] = useState({ lat: 17.3850, lng: 78.4867 })
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const driverData = localStorage.getItem('driver')
    if (!driverData) {
      router.push('/driver-login')
      return
    }
    
    setDriver(JSON.parse(driverData))
    
    // Fetch orders from backend
    const fetchOrders = async () => {
      try {
        console.log('Fetching orders from backend...')
        const response = await fetch('http://localhost:8001/api/orders')
        console.log('Response status:', response.status)
        
        if (response.ok) {
          const backendOrders = await response.json()
          console.log('Backend orders:', backendOrders)
          
          // Simple conversion - just show the order regardless of status
          const driverOrders = backendOrders.map((order: any) => ({
            id: order.id,
            customerName: order.customerName,
            customerPhone: '+91 98765 43210',
            deliveryAddress: order.deliveryAddress,
            pickupAddress: `GPS Location: ${order.latitude || 17.3850}, ${order.longitude || 78.4867}`,
            coordinates: { 
              pickup: { 
                lat: order.latitude || 17.3850, 
                lng: order.longitude || 78.4867 
              }, 
              delivery: { 
                lat: order.destinationLatitude || 17.4380, 
                lng: order.destinationLongitude || 78.4560 
              } 
            },
            priority: order.priority?.charAt(0)?.toUpperCase() + order.priority?.slice(1) || 'Medium',
            estimatedTime: '25-35 mins',
            distance: '8-12 km',
            payment: 150 + Math.floor(Math.random() * 100),
            status: 'pending', // Force to pending for testing
            specialInstructions: 'Handle with care - Electronic items'
          }))
          
          console.log('Driver orders:', driverOrders)
          setOrders(driverOrders)
          
          // Set current order to first available order
          if (driverOrders.length > 0) {
            console.log('Setting current order:', driverOrders[0])
            setCurrentOrder(driverOrders[0])
          }
        } else {
          console.error('Failed to fetch orders:', response.status, response.statusText)
        }
      } catch (error) {
        console.error('Failed to fetch orders:', error)
        // Fallback to mock orders
        console.log('Using fallback mock orders')
        const mockOrders = [
          {
            id: 'ORD001',
            customerName: 'Tech Park A',
            customerPhone: '+91 98765 43210',
            deliveryAddress: 'HITEC City, Hyderabad',
            pickupAddress: 'Depot, Hyderabad',
            coordinates: { pickup: { lat: 17.3850, lng: 78.4867 }, delivery: { lat: 17.4380, lng: 78.4560 } },
            priority: 'High',
            estimatedTime: '25 mins',
            distance: '8.5 km',
            payment: 150,
            status: 'pending',
            specialInstructions: 'Handle with care - Electronic items'
          }
        ]
        setOrders(mockOrders)
        setCurrentOrder(mockOrders[0])
      }
    }
    
    fetchOrders()
    setLoading(false)

    // Simulate real-time location updates
    const interval = setInterval(() => {
      setCurrentLocation(prev => ({
        lat: prev.lat + (Math.random() - 0.5) * 0.001,
        lng: prev.lng + (Math.random() - 0.5) * 0.001
      }))
    }, 5000)

    return () => clearInterval(interval)
  }, [router])

  const handleAcceptOrder = (order: any) => {
    setCurrentOrder(order)
    setOrders(orders.map(o => 
      o.id === order.id ? { ...o, status: 'in_progress' } : o
    ))
  }

  const handleCompleteDelivery = () => {
    if (currentOrder) {
      setOrders(orders.map(o => 
        o.id === currentOrder.id ? { ...o, status: 'completed' } : o
      ))
      
      // Find next pending order
      const nextOrder = orders.find(o => o.status === 'pending')
      if (nextOrder) {
        setCurrentOrder(nextOrder)
      } else {
        setCurrentOrder(null)
      }
    }
  }

  const handleReportIssue = () => {
    alert('Issue reported to dispatch center')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <TruckIcon className="h-12 w-12 text-blue-600 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">Loading driver dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="bg-blue-600 p-2 rounded-lg mr-3">
                <TruckIcon className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">Driver Dashboard</h1>
                <p className="text-sm text-gray-600">{driver?.name} • {driver?.vehicle}</p>
              </div>
            </div>
            <button
              onClick={() => {
                localStorage.removeItem('driver')
                router.push('/driver-login')
              }}
              className="text-sm text-gray-600 hover:text-gray-900"
            >
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Current Order Card */}
        {currentOrder && (
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Current Delivery</h2>
              <span className={`px-2 py-1 text-xs rounded ${
                currentOrder.status === 'in_progress' ? 'bg-blue-100 text-blue-700' :
                currentOrder.status === 'assigned' ? 'bg-yellow-100 text-yellow-700' :
                'bg-green-100 text-green-700'
              }`}>
                {currentOrder.status === 'in_progress' ? 'In Progress' :
                 currentOrder.status === 'assigned' ? 'Assigned' : 'Completed'}
              </span>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-900">Order ID:</span>
                <span className="text-sm text-gray-600">{currentOrder.id}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-900">Customer:</span>
                <div className="text-right">
                  <span className="text-sm text-gray-900">{currentOrder.customerName}</span>
                  <div className="flex items-center text-blue-600">
                    <PhoneIcon className="h-3 w-3 mr-1" />
                    <span className="text-xs">{currentOrder.customerPhone}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-start justify-between">
                <span className="text-sm font-medium text-gray-900">Address:</span>
                <span className="text-sm text-gray-600 text-right max-w-xs">{currentOrder.deliveryAddress}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-900">ETA:</span>
                <div className="flex items-center text-gray-600">
                  <ClockIcon className="h-3 w-3 mr-1" />
                  <span className="text-sm">{currentOrder.estimatedTime}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-900">Distance:</span>
                <span className="text-sm text-gray-600">{currentOrder.distance}</span>
              </div>

              {currentOrder.specialInstructions && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                  <div className="flex items-start">
                    <BellIcon className="h-4 w-4 text-yellow-600 mt-0.5 mr-2" />
                    <span className="text-sm text-yellow-800">{currentOrder.specialInstructions}</span>
                  </div>
                </div>
              )}

              <div className="flex space-x-3 pt-4">
                <button
                  onClick={handleCompleteDelivery}
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 flex items-center justify-center"
                >
                  <CheckCircleIcon className="h-4 w-4 mr-2" />
                  Mark Delivered
                </button>
                <button
                  onClick={handleReportIssue}
                  className="flex-1 bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 flex items-center justify-center"
                >
                  <BellIcon className="h-4 w-4 mr-2" />
                  Report Issue
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Map */}
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Live Navigation</h2>
          <div className="h-[600px] rounded-lg overflow-hidden">
            <MapComponent 
              currentLocation={currentLocation} 
              currentOrder={currentOrder} 
            />
          </div>
        </div>

        {/* Available Orders */}
        {orders.filter(o => o.status === 'pending').length > 0 && (
          <div className="bg-white rounded-lg shadow-sm p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Available Orders</h2>
            <div className="space-y-3">
              {orders.filter(o => o.status === 'pending').map(order => (
                <div key={order.id} className="border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <span className="font-medium text-gray-900">{order.id}</span>
                      <span className="ml-2 text-sm text-gray-600">{order.customerName}</span>
                    </div>
                    <span className={`px-2 py-1 text-xs rounded ${
                      order.priority === 'High' ? 'bg-red-100 text-red-700' :
                      order.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {order.priority}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                    <span>{order.deliveryAddress}</span>
                    <span>{order.distance} • {order.estimatedTime}</span>
                  </div>
                  <button
                    onClick={() => handleAcceptOrder(order)}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 flex items-center justify-center"
                  >
                    Accept Order
                    <ArrowRightIcon className="h-4 w-4 ml-2" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center">
              <CheckCircleIcon className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <p className="text-2xl font-bold text-gray-900">
                  {orders.filter(o => o.status === 'completed').length}
                </p>
                <p className="text-sm text-gray-600">Completed Today</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center">
              <ClockIcon className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <p className="text-2xl font-bold text-gray-900">
                  {orders.filter(o => o.status === 'pending').length}
                </p>
                <p className="text-sm text-gray-600">Pending Orders</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
