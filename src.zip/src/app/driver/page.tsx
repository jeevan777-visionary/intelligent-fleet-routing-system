'use client'

import { useState, useEffect } from 'react'
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet'
import { 
  MapPinIcon, 
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon,
  NavigationIcon,
  PhoneIcon,
  ExclamationTriangleIcon,
  ArrowPathIcon,
  Bars3Icon,
  XMarkIcon
} from '@heroicons/react/24/outline'
import { LatLngExpression } from 'leaflet'
import 'leaflet/dist/leaflet.css'

// Fix for default markers in react-leaflet
const createIcon = () => {
  if (typeof window !== 'undefined') {
    const L = require('leaflet')
    delete L.Icon.Default.prototype._getIconUrl
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: '/images/marker-icon-2x.png',
      iconUrl: '/images/marker-icon.png',
      shadowUrl: '/images/marker-shadow.png',
    })
  }
}

interface DeliveryStop {
  id: string
  customerName: string
  address: string
  latitude: number
  longitude: number
  estimatedArrival: string
  actualArrival?: string
  status: 'pending' | 'arrived' | 'delivered' | 'failed'
  notes: string
  orderIds: string[]
  customerPhone: string
}

interface DriverRoute {
  id: string
  vehicleId: string
  driverName: string
  currentLocation: {
    latitude: number
    longitude: number
    address: string
  }
  stops: DeliveryStop[]
  totalDistance: number
  estimatedDuration: number
  startTime: string
  progress: {
    completed: number
    total: number
  }
  nextStop: DeliveryStop | null
}

function MapController({ center, zoom }: { center: LatLngExpression, zoom: number }) {
  const map = useMap()
  useEffect(() => {
    map.setView(center, zoom)
  }, [center, zoom, map])
  return null
}

export default function DriverPage() {
  const [route, setRoute] = useState<DriverRoute | null>(null)
  const [selectedStop, setSelectedStop] = useState<DeliveryStop | null>(null)
  const [mapCenter] = useState<[number, number]>([18.5204, 73.8567]) // Pune coordinates
  const [mapZoom] = useState(14)
  const [loading, setLoading] = useState(true)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [navigationMode, setNavigationMode] = useState<'overview' | 'navigation'>('overview')

  useEffect(() => {
    createIcon()
    fetchDriverRoute()
    
    // Simulate real-time location updates
    const interval = setInterval(() => {
      updateDriverLocation()
    }, 10000) // Update every 10 seconds
    
    return () => clearInterval(interval)
  }, [])

  const fetchDriverRoute = async () => {
    try {
      // Mock driver route data
      const mockRoute: DriverRoute = {
        id: 'route_001',
        vehicleId: 'VH001',
        driverName: 'Raj Kumar',
        currentLocation: {
          latitude: 18.5204,
          longitude: 73.8567,
          address: 'MG Road, Pune'
        },
        stops: [
          {
            id: 'stop_1',
            customerName: 'Customer A',
            address: '123 FC Road, Pune',
            latitude: 18.5314,
            longitude: 73.8446,
            estimatedArrival: '09:30',
            status: 'delivered',
            actualArrival: '09:28',
            notes: 'Customer satisfied with delivery',
            orderIds: ['order_1', 'order_2'],
            customerPhone: '+91 98765 43210'
          },
          {
            id: 'stop_2',
            customerName: 'Customer B',
            address: '456 JM Road, Pune',
            latitude: 18.5167,
            longitude: 73.8511,
            estimatedArrival: '10:00',
            status: 'arrived',
            notes: 'Customer not available, will retry',
            orderIds: ['order_3'],
            customerPhone: '+91 87654 32109'
          },
          {
            id: 'stop_3',
            customerName: 'Customer C',
            address: '789 Koregaon Park, Pune',
            latitude: 18.5333,
            longitude: 73.8933,
            estimatedArrival: '10:30',
            status: 'pending',
            notes: 'Priority delivery - fragile items',
            orderIds: ['order_4', 'order_5'],
            customerPhone: '+91 76543 21098'
          },
          {
            id: 'stop_4',
            customerName: 'Customer D',
            address: '321 Kalyani Nagar, Pune',
            latitude: 18.5417,
            longitude: 73.9056,
            estimatedArrival: '11:00',
            status: 'pending',
            notes: 'Call before arrival',
            orderIds: ['order_6'],
            customerPhone: '+91 65432 10987'
          }
        ],
        totalDistance: 15.2,
        estimatedDuration: 120,
        startTime: '09:00',
        progress: {
          completed: 1,
          total: 4
        },
        nextStop: null
      }
      
      // Set next stop
      const nextStopIndex = mockRoute.stops.findIndex(stop => stop.status === 'pending')
      mockRoute.nextStop = nextStopIndex !== -1 ? mockRoute.stops[nextStopIndex] : null
      
      setRoute(mockRoute)
    } catch (error) {
      console.error('Failed to fetch driver route:', error)
    } finally {
      setLoading(false)
    }
  }

  const updateDriverLocation = () => {
    if (!route) return
    
    // Simulate location update
    const newRoute = { ...route }
    const currentLat = newRoute.currentLocation.latitude
    const currentLng = newRoute.currentLocation.longitude
    
    // Small random movement to simulate driving
    newRoute.currentLocation.latitude = currentLat + (Math.random() - 0.5) * 0.001
    newRoute.currentLocation.longitude = currentLng + (Math.random() - 0.5) * 0.001
    
    setRoute(newRoute)
  }

  const handleArriveAtStop = async (stopId: string) => {
    if (!route) return
    
    try {
      const updatedRoute = { ...route }
      const stop = updatedRoute.stops.find(s => s.id === stopId)
      
      if (stop) {
        stop.status = 'arrived'
        stop.actualArrival = new Date().toLocaleTimeString()
        
        // Update next stop
        const nextStopIndex = updatedRoute.stops.findIndex(s => s.status === 'pending')
        updatedRoute.nextStop = nextStopIndex !== -1 ? updatedRoute.stops[nextStopIndex] : null
        
        setRoute(updatedRoute)
      }
    } catch (error) {
      console.error('Failed to update stop status:', error)
    }
  }

  const handleCompleteDelivery = async (stopId: string) => {
    if (!route) return
    
    try {
      const updatedRoute = { ...route }
      const stop = updatedRoute.stops.find(s => s.id === stopId)
      
      if (stop) {
        stop.status = 'delivered'
        updatedRoute.progress.completed += 1
        
        // Update next stop
        const nextStopIndex = updatedRoute.stops.findIndex(s => s.status === 'pending')
        updatedRoute.nextStop = nextStopIndex !== -1 ? updatedRoute.stops[nextStopIndex] : null
        
        setRoute(updatedRoute)
      }
    } catch (error) {
      console.error('Failed to complete delivery:', error)
    }
  }

  const handleFailedDelivery = async (stopId: string) => {
    if (!route) return
    
    try {
      const updatedRoute = { ...route }
      const stop = updatedRoute.stops.find(s => s.id === stopId)
      
      if (stop) {
        stop.status = 'failed'
        stop.actualArrival = new Date().toLocaleTimeString()
        
        // Update next stop
        const nextStopIndex = updatedRoute.stops.findIndex(s => s.status === 'pending')
        updatedRoute.nextStop = nextStopIndex !== -1 ? updatedRoute.stops[nextStopIndex] : null
        
        setRoute(updatedRoute)
      }
    } catch (error) {
      console.error('Failed to mark delivery as failed:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-green-100 text-green-800'
      case 'arrived': return 'bg-blue-100 text-blue-800'
      case 'pending': return 'bg-gray-100 text-gray-800'
      case 'failed': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered': return <CheckCircleIcon className="h-5 w-5 text-green-600" />
      case 'arrived': return <NavigationIcon className="h-5 w-5 text-blue-600" />
      case 'pending': return <ClockIcon className="h-5 w-5 text-gray-600" />
      case 'failed': return <XCircleIcon className="h-5 w-5 text-red-600" />
      default: return <ClockIcon className="h-5 w-5 text-gray-600" />
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!route) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <p className="text-gray-500">No route assigned</p>
      </div>
    )
  }

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* Mobile Header */}
      <div className="bg-blue-600 text-white p-4 flex items-center justify-between lg:hidden">
        <div className="flex items-center">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="mr-3"
          >
            {sidebarOpen ? <XMarkIcon className="h-6 w-6" /> : <Bars3Icon className="h-6 w-6" />}
          </button>
          <div>
            <h1 className="text-lg font-semibold">Driver Navigation</h1>
            <p className="text-sm text-blue-100">{route.vehicleId} • {route.driverName}</p>
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm">{route.progress.completed}/{route.progress.total}</div>
          <div className="text-xs text-blue-100">Deliveries</div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className={`${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 fixed lg:relative z-30 w-80 h-full bg-white shadow-lg transition-transform duration-300 ease-in-out overflow-y-auto`}>
          <div className="p-4 bg-blue-600 text-white">
            <h2 className="text-lg font-semibold">Today's Route</h2>
            <p className="text-sm text-blue-100">Started: {route.startTime}</p>
            <div className="mt-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{Math.round((route.progress.completed / route.progress.total) * 100)}%</span>
              </div>
              <div className="w-full bg-blue-200 rounded-full h-2 mt-1">
                <div 
                  className="bg-white h-2 rounded-full"
                  style={{ width: `${(route.progress.completed / route.progress.total) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Next Stop */}
          {route.nextStop && (
            <div className="p-4 bg-yellow-50 border-b">
              <div className="flex items-start">
                <NavigationIcon className="h-5 w-5 text-yellow-600 mt-1 mr-3" />
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">Next Stop</h3>
                  <p className="text-sm text-gray-600">{route.nextStop.customerName}</p>
                  <p className="text-sm text-gray-600">{route.nextStop.address}</p>
                  <p className="text-sm font-medium text-yellow-600">ETA: {route.nextStop.estimatedArrival}</p>
                  <div className="mt-2 flex space-x-2">
                    <button
                      onClick={() => handleArriveAtStop(route.nextStop!.id)}
                      className="flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded text-sm hover:bg-blue-200"
                    >
                      <NavigationIcon className="h-3 w-3 mr-1" />
                      Arrived
                    </button>
                    <button
                      onClick={() => window.open(`tel:${route.nextStop!.customerPhone}`)}
                      className="flex items-center px-3 py-1 bg-green-100 text-green-700 rounded text-sm hover:bg-green-200"
                    >
                      <PhoneIcon className="h-3 w-3 mr-1" />
                      Call
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Delivery Stops */}
          <div className="p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Delivery Stops</h3>
            <div className="space-y-3">
              {route.stops.map((stop, index) => (
                <div
                  key={stop.id}
                  className={`border rounded-lg p-3 cursor-pointer transition-all ${
                    selectedStop?.id === stop.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedStop(stop)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start">
                      <div className="mr-3">
                        {getStatusIcon(stop.status)}
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-gray-900">{stop.customerName}</div>
                        <div className="text-sm text-gray-600">{stop.address}</div>
                        <div className="text-xs text-gray-500 mt-1">
                          ETA: {stop.estimatedArrival}
                          {stop.actualArrival && ` • Arrived: ${stop.actualArrival}`}
                        </div>
                        {stop.notes && (
                          <div className="text-xs text-gray-500 mt-1 italic">Note: {stop.notes}</div>
                        )}
                      </div>
                    </div>
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(stop.status)}`}>
                      {stop.status}
                    </span>
                  </div>
                  
                  {stop.status === 'arrived' && (
                    <div className="mt-3 flex space-x-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          handleCompleteDelivery(stop.id)
                        }}
                        className="flex items-center px-3 py-1 bg-green-100 text-green-700 rounded text-sm hover:bg-green-200"
                      >
                        <CheckCircleIcon className="h-3 w-3 mr-1" />
                        Delivered
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          handleFailedDelivery(stop.id)
                        }}
                        className="flex items-center px-3 py-1 bg-red-100 text-red-700 rounded text-sm hover:bg-red-200"
                      >
                        <XCircleIcon className="h-3 w-3 mr-1" />
                        Failed
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Map */}
        <div className="flex-1 relative">
          <div className="absolute top-4 left-4 z-20 bg-white rounded-lg shadow-lg p-3 lg:hidden">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2"
            >
              {sidebarOpen ? <XMarkIcon className="h-5 w-5" /> : <Bars3Icon className="h-5 w-5" />}
            </button>
          </div>

          <div className="h-full">
            <MapContainer
              center={mapCenter}
              zoom={mapZoom}
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <MapController center={mapCenter} zoom={mapZoom} />
              
              {/* Route polyline */}
              <Polyline
                pathOptions={{ 
                  color: '#3B82F6',
                  weight: 4,
                  opacity: 0.8
                }}
                positions={route.stops.map(stop => [stop.latitude, stop.longitude])}
              />
              
              {/* Current location marker */}
              <Marker
                position={[route.currentLocation.latitude, route.currentLocation.longitude]}
              >
                <Popup>
                  <div className="text-sm">
                    <div className="font-semibold">Current Location</div>
                    <div>{route.currentLocation.address}</div>
                    <div className="text-xs text-gray-500">
                      Last updated: {new Date().toLocaleTimeString()}
                    </div>
                  </div>
                </Popup>
              </Marker>
              
              {/* Stop markers */}
              {route.stops.map((stop) => (
                <Marker
                  key={stop.id}
                  position={[stop.latitude, stop.longitude]}
                >
                  <Popup>
                    <div className="text-sm">
                      <div className="font-semibold">{stop.customerName}</div>
                      <div>{stop.address}</div>
                      <div>Status: <span className={`px-1 py-0.5 text-xs rounded ${getStatusColor(stop.status)}`}>{stop.status}</span></div>
                      <div>ETA: {stop.estimatedArrival}</div>
                      {stop.actualArrival && <div>Arrived: {stop.actualArrival}</div>}
                      {stop.notes && <div className="text-xs text-gray-500 mt-1">Note: {stop.notes}</div>}
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>

          {/* Route Info Overlay */}
          <div className="absolute bottom-4 left-4 right-4 lg:right-auto lg:w-80 bg-white rounded-lg shadow-lg p-4">
            <div className="flex justify-between items-center">
              <div>
                <div className="text-sm text-gray-600">Total Distance</div>
                <div className="text-lg font-semibold">{route.totalDistance} km</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600">Est. Duration</div>
                <div className="text-lg font-semibold">{route.estimatedDuration} min</div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-600">Progress</div>
                <div className="text-lg font-semibold">{route.progress.completed}/{route.progress.total}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
