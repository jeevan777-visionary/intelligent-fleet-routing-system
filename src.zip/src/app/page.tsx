'use client'

import { useState } from 'react'
import { 
  TruckIcon,
  MapPinIcon,
  ChartBarIcon,
  CogIcon,
  ArrowRightIcon,
  PlayIcon,
  CheckCircleIcon,
  SparklesIcon,
  BoltIcon,
  ShieldCheckIcon,
  ClockIcon,
  ArrowTrendingDownIcon
} from '@heroicons/react/24/outline'
import Link from 'next/link'

export default function LandingPage() {
  const [activeTab, setActiveTab] = useState('features')

  const features = [
    {
      icon: TruckIcon,
      title: 'Smart Fleet Management',
      description: 'Complete vehicle tracking, driver management, and depot operations with real-time monitoring.'
    },
    {
      icon: MapPinIcon,
      title: 'GPS-Based Order System',
      description: 'Automatic location detection, intelligent routing, and precise delivery tracking.'
    },
    {
      icon: CogIcon,
      title: 'Hybrid Optimization',
      description: 'Advanced classical optimization combined with AI algorithms for maximum efficiency.'
    },
    {
      icon: ChartBarIcon,
      title: 'Business Intelligence',
      description: 'Advanced analytics, performance metrics, and carbon footprint tracking.'
    }
  ]

  const metrics = [
    { label: 'Distance Reduction', value: '15.8%', icon: ArrowTrendingDownIcon },
    { label: 'Fuel Savings', value: '324L', icon: BoltIcon },
    { label: 'On-Time Rate', value: '94.2%', icon: ClockIcon },
    { label: 'CO₂ Reduction', value: '892kg', icon: ShieldCheckIcon }
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <TruckIcon className="h-8 w-8 text-blue-600 mr-3" />
              <span className="text-xl font-bold text-gray-900">Intelligent Fleet Routing</span>
            </div>
            <div className="flex items-center space-x-8">
              <button
                onClick={() => setActiveTab('features')}
                className={`px-3 py-2 text-sm font-medium ${
                  activeTab === 'features' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Features
              </button>
              <button
                onClick={() => setActiveTab('technology')}
                className={`px-3 py-2 text-sm font-medium ${
                  activeTab === 'technology' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Technology
              </button>
              <button
                onClick={() => setActiveTab('pricing')}
                className={`px-3 py-2 text-sm font-medium ${
                  activeTab === 'pricing' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Pricing
              </button>
              <Link
                href="/login"
                className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700"
              >
                Login
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
          <div className="absolute top-40 right-10 w-72 h-72 bg-yellow-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
          <div className="absolute -bottom-8 left-20 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-4000"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="mb-6">
              <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-transparent bg-clip-text text-sm font-semibold uppercase tracking-wider">
                🚀 Next-Generation Logistics Platform
              </span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white via-blue-200 to-purple-200 text-transparent bg-clip-text">
              Transform Your Fleet
              <span className="block bg-gradient-to-r from-yellow-400 via-pink-400 to-purple-400 text-transparent bg-clip-text mt-2">
                with Intelligent Routing
              </span>
            </h1>
            <p className="text-xl mb-8 text-blue-100 max-w-3xl mx-auto leading-relaxed">
              Revolutionize your logistics operations with cutting-edge route optimization, 
              real-time fleet intelligence, and AI-powered delivery management.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/login"
                className="bg-gradient-to-r from-yellow-400 to-orange-500 text-gray-900 px-8 py-4 rounded-lg font-bold hover:from-yellow-500 hover:to-orange-600 transform hover:scale-105 transition-all duration-300 flex items-center justify-center shadow-lg"
              >
                Get Started Now
                <ArrowRightIcon className="ml-2 h-5 w-5" />
              </Link>
              <button className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-purple-900 transform hover:scale-105 transition-all duration-300">
                <PlayIcon className="mr-2 h-5 w-5" />
                Watch Demo
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Tab */}
      {activeTab === 'features' && (
        <div className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 text-transparent bg-clip-text mb-4">
                Complete Fleet Management Solution
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Everything you need to optimize delivery operations in one powerful platform
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {features.map((feature, index) => (
                <div key={index} className="p-6 hover:transform hover:-translate-y-2 transition-all duration-300">
                  <div className="bg-gradient-to-br from-blue-500 to-purple-600 w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              ))}
            </div>

            {/* Metrics */}
            <div className="mb-16">
              <h3 className="text-3xl font-bold text-center bg-gradient-to-r from-blue-600 to-purple-600 text-transparent bg-clip-text mb-8">Proven Results</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {metrics.map((metric, index) => (
                  <div key={index} className="text-center p-6">
                    <div className="bg-gradient-to-br from-blue-500 to-purple-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                      <metric.icon className="h-8 w-8 text-white" />
                    </div>
                    <div className="text-3xl font-bold text-gray-900 mb-2">{metric.value}</div>
                    <div className="text-sm text-gray-600">{metric.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Technology Tab */}
      {activeTab === 'technology' && (
        <div className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-transparent bg-clip-text mb-4">
                Advanced Technology Stack
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Cutting-edge quantum and classical optimization technologies
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div className="p-8 hover:transform hover:-translate-y-2 transition-all duration-300">
                <div className="flex items-center mb-6">
                  <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-4 rounded-2xl mr-4">
                    <CogIcon className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-semibold text-gray-900">Classical Optimization</h3>
                </div>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircleIcon className="h-6 w-6 text-blue-500 mr-3 mt-0.5" />
                    <span className="text-gray-700 text-lg">Google OR-Tools VRP integration</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="h-6 w-6 text-blue-500 mr-3 mt-0.5" />
                    <span className="text-gray-700 text-lg">Advanced constraint solving</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="h-6 w-6 text-blue-500 mr-3 mt-0.5" />
                    <span className="text-gray-700 text-lg">Real-time route adjustment</span>
                  </li>
                </ul>
              </div>

              <div className="p-8 hover:transform hover:-translate-y-2 transition-all duration-300">
                <div className="flex items-center mb-6">
                  <div className="bg-gradient-to-br from-purple-500 to-pink-600 p-4 rounded-2xl mr-4">
                    <SparklesIcon className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-semibold text-gray-900">AI Enhancement</h3>
                </div>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircleIcon className="h-6 w-6 text-purple-500 mr-3 mt-0.5" />
                    <span className="text-gray-700 text-lg">Advanced AI algorithms</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="h-6 w-6 text-purple-500 mr-3 mt-0.5" />
                    <span className="text-gray-700 text-lg">Machine learning optimization</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="h-6 w-6 text-purple-500 mr-3 mt-0.5" />
                    <span className="text-gray-700 text-lg">Hybrid optimization engine</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pricing Tab */}
      {activeTab === 'pricing' && (
        <div className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-transparent bg-clip-text mb-4">
                Flexible Pricing Plans
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Choose the perfect plan for your fleet size and requirements
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="p-8 hover:transform hover:-translate-y-2 transition-all duration-300">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Starter</h3>
                <div className="text-3xl font-bold text-gray-900 mb-4">$299<span className="text-lg text-gray-500">/month</span></div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-blue-500 mr-3" />
                    <span className="text-gray-700">Up to 10 vehicles</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-blue-500 mr-3" />
                    <span className="text-gray-700">Basic optimization</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-blue-500 mr-3" />
                    <span className="text-gray-700">Email support</span>
                  </li>
                </ul>
                <Link
                  href="/login"
                  className="w-full bg-gradient-to-r from-gray-100 to-gray-200 text-gray-900 py-3 rounded-lg font-semibold hover:from-gray-200 hover:to-gray-300 text-center"
                >
                  Start Free Trial
                </Link>
              </div>

              <div className="p-8 transform scale-105 hover:transform hover:-translate-y-2 transition-all duration-300">
                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-indigo-900 text-sm font-bold px-3 py-1 rounded-full inline-block mb-2">
                  🌟 MOST POPULAR
                </div>
                <h3 className="text-xl font-semibold mb-2">Professional</h3>
                <div className="text-3xl font-bold mb-4">$699<span className="text-lg text-gray-500">/month</span></div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-indigo-600 mr-3" />
                    <span className="text-gray-700">Up to 50 vehicles</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-indigo-600 mr-3" />
                    <span className="text-gray-700">Hybrid intelligent optimization</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-indigo-600 mr-3" />
                    <span className="text-gray-700">Advanced analytics</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-indigo-600 mr-3" />
                    <span className="text-gray-700">Priority support</span>
                  </li>
                </ul>
                <Link
                  href="/login"
                  className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-indigo-900 py-3 rounded-lg font-bold hover:from-yellow-500 hover:to-orange-600 text-center"
                >
                  Start Free Trial
                </Link>
              </div>

              <div className="p-8 hover:transform hover:-translate-y-2 transition-all duration-300">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Enterprise</h3>
                <div className="text-3xl font-bold text-gray-900 mb-4">$1299<span className="text-lg text-gray-500">/month</span></div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-purple-600 mr-3" />
                    <span className="text-gray-700">Unlimited vehicles</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-purple-600 mr-3" />
                    <span className="text-gray-700">Custom AI algorithms</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-purple-600 mr-3" />
                    <span className="text-gray-700">White-label deployment</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircleIcon className="h-5 w-5 text-purple-600 mr-3" />
                    <span className="text-gray-700">Dedicated support team</span>
                  </li>
                </ul>
                <Link
                  href="/login"
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 rounded-lg font-bold hover:from-purple-600 hover:to-pink-600 text-center"
                >
                  Contact Sales
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <div className="relative bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-10 left-20 w-64 h-64 bg-yellow-500 rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-pulse"></div>
          <div className="absolute bottom-10 right-20 w-64 h-64 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-pulse animation-delay-2000"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-yellow-400 via-pink-400 to-purple-400 text-transparent bg-clip-text">
              Ready to Transform Your Fleet Operations?
            </h2>
            <p className="text-xl mb-8 text-blue-100">
              Join thousands of logistics companies using intelligent-optimized routing
            </p>
            <Link
              href="/login"
              className="bg-gradient-to-r from-yellow-400 to-orange-500 text-gray-900 px-8 py-4 rounded-lg text-lg font-bold hover:from-yellow-500 hover:to-orange-600 transform hover:scale-105 transition-all duration-300 inline-flex items-center shadow-xl"
            >
              Get Started Now
              <ArrowRightIcon className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 via-indigo-900 to-purple-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-2 rounded-lg mr-3">
                  <TruckIcon className="h-6 w-6 text-white" />
                </div>
                <span className="text-lg font-semibold bg-gradient-to-r from-blue-400 to-purple-400 text-transparent bg-clip-text">Intelligent Fleet Routing</span>
              </div>
              <p className="text-gray-400">
                Next-generation fleet management with intelligent optimization technology.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-blue-300">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="#" className="hover:text-white transition-colors">Features</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Technology</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Pricing</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Demo</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-purple-300">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="#" className="hover:text-white transition-colors">About Us</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Careers</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Contact</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Blog</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-pink-300">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="#" className="hover:text-white transition-colors">Documentation</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">API</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Status</Link></li>
                <li><Link href="/login" className="hover:text-white transition-colors">Login</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Intelligent Fleet Routing. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
