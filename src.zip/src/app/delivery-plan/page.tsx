'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { 
  MapPinIcon, 
  PhoneIcon, 
  ClockIcon, 
  CheckCircleIcon,
  BellIcon,
  UserIcon,
  TruckIcon,
  ArrowRightIcon,
  CurrencyDollarIcon
} from '@heroicons/react/24/outline'

export default function DeliveryPlanPage() {
  const [driver, setDriver] = useState<any>(null)
  const [orders, setOrders] = useState<any[]>([])
  const [currentOrder, setCurrentOrder] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [earnings, setEarnings] = useState({
    today: 2450,
    week: 12200,
    month: 48500
  })
  const router = useRouter()

  useEffect(() => {
    const driverData = localStorage.getItem('driver')
    if (!driverData) {
      router.push('/driver-login')
      return
    }
    
    setDriver(JSON.parse(driverData))
    
    // Fetch orders from backend
    const fetchOrders = async () => {
      try {
        const response = await fetch('http://localhost:8001/api/orders')
        if (response.ok) {
          const backendOrders = await response.json()
          
          // Convert backend orders to driver format
          const driverOrders = backendOrders.map((order: any) => ({
            id: order.id,
            customerName: order.customerName,
            customerPhone: '+91 98765 43210', // Mock phone for demo
            deliveryAddress: order.deliveryAddress,
            pickupAddress: order.pickupAddress || `GPS Location: ${order.pickupLatitude?.toFixed(4)}, ${order.pickupLongitude?.toFixed(4)}`,
            coordinates: { 
              pickup: { 
                lat: order.pickupLatitude || 17.3850, 
                lng: order.pickupLongitude || 78.4867 
              }, 
              delivery: { 
                lat: order.destinationLatitude || 17.4380, 
                lng: order.destinationLongitude || 78.4560 
              } 
            },
            priority: order.priority.charAt(0).toUpperCase() + order.priority.slice(1),
            estimatedTime: '25-35 mins',
            distance: '8-12 km',
            payment: 150 + Math.floor(Math.random() * 100), // Random payment
            status: order.status === 'pending' ? 'pending' : 
                    order.status === 'assigned' ? 'in_progress' : 
                    order.status === 'in_transit' ? 'in_progress' : 
                    order.status === 'delivered' ? 'completed' : 'pending',
            specialInstructions: 'Handle with care - Electronic items'
          }))
          
          setOrders(driverOrders)
          
          // Set current order to first pending order
          const pendingOrder = driverOrders.find(o => o.status === 'pending')
          if (pendingOrder) {
            setCurrentOrder(pendingOrder)
          }
        }
      } catch (error) {
        console.error('Failed to fetch orders:', error)
        // Fallback to mock orders
        const mockOrders = [
          {
            id: 'ORD001',
            customerName: 'Tech Park A',
            customerPhone: '+91 98765 43210',
            deliveryAddress: 'HITEC City, Hyderabad',
            pickupAddress: 'Depot, Hyderabad',
            coordinates: { pickup: { lat: 17.3850, lng: 78.4867 }, delivery: { lat: 17.4380, lng: 78.4560 } },
            priority: 'High',
            estimatedTime: '25 mins',
            distance: '8.5 km',
            payment: 150,
            status: 'pending',
            specialInstructions: 'Handle with care - Electronic items'
          }
        ]
        setOrders(mockOrders)
        setCurrentOrder(mockOrders[0])
      }
    }
    
    fetchOrders()
    setLoading(false)
  }, [router])

  const handleAcceptOrder = (order: any) => {
    setCurrentOrder(order)
    setOrders(orders.map(o => 
      o.id === order.id ? { ...o, status: 'in_progress' } : o
    ))
  }

  const handleStartDelivery = () => {
    if (currentOrder) {
      router.push('/driver-dashboard')
    }
  }

  const handleCompleteDelivery = () => {
    if (currentOrder) {
      setEarnings(prev => ({
        ...prev,
        today: prev.today + currentOrder.payment
      }))
      
      setOrders(orders.map(o => 
        o.id === currentOrder.id ? { ...o, status: 'completed' } : o
      ))
      
      // Find next pending order
      const nextOrder = orders.find(o => o.status === 'pending')
      if (nextOrder) {
        setCurrentOrder(nextOrder)
      } else {
        setCurrentOrder(null)
      }
    }
  }

  const handleReportIssue = () => {
    alert('Issue reported to dispatch center')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <TruckIcon className="h-12 w-12 text-blue-600 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">Loading delivery plan...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="bg-blue-600 p-2 rounded-lg mr-3">
                <TruckIcon className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">Delivery Plan</h1>
                <p className="text-sm text-gray-600">{driver?.name} • {driver?.vehicle}</p>
              </div>
            </div>
            <button
              onClick={() => {
                localStorage.removeItem('driver')
                router.push('/driver-login')
              }}
              className="text-sm text-gray-600 hover:text-gray-900"
            >
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Earnings Summary */}
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Earnings Summary</h2>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">₹{earnings.today}</p>
              <p className="text-sm text-gray-600">Today</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">₹{earnings.week}</p>
              <p className="text-sm text-gray-600">This Week</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">₹{earnings.month}</p>
              <p className="text-sm text-gray-600">This Month</p>
            </div>
          </div>
        </div>

        {/* Current Order */}
        {currentOrder && (
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Current Delivery</h2>
              <span className={`px-2 py-1 text-xs rounded ${
                currentOrder.status === 'in_progress' ? 'bg-blue-100 text-blue-700' :
                currentOrder.status === 'assigned' ? 'bg-yellow-100 text-yellow-700' :
                'bg-green-100 text-green-700'
              }`}>
                {currentOrder.status === 'in_progress' ? 'In Progress' :
                 currentOrder.status === 'assigned' ? 'Assigned' : 'Completed'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900">Order ID:</span>
                  <span className="text-sm text-gray-600">{currentOrder.id}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900">Customer:</span>
                  <div className="text-right">
                    <span className="text-sm text-gray-900">{currentOrder.customerName}</span>
                    <div className="flex items-center text-blue-600">
                      <PhoneIcon className="h-3 w-3 mr-1" />
                      <span className="text-xs">{currentOrder.customerPhone}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start justify-between">
                  <span className="text-sm font-medium text-gray-900">Address:</span>
                  <span className="text-sm text-gray-600 text-right max-w-xs">{currentOrder.deliveryAddress}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900">Payment:</span>
                  <div className="flex items-center text-green-600">
                    <CurrencyDollarIcon className="h-3 w-3 mr-1" />
                    <span className="text-sm font-medium">₹{currentOrder.payment}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900">ETA:</span>
                  <div className="flex items-center text-gray-600">
                    <ClockIcon className="h-3 w-3 mr-1" />
                    <span className="text-sm">{currentOrder.estimatedTime}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900">Distance:</span>
                  <span className="text-sm text-gray-600">{currentOrder.distance}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900">Priority:</span>
                  <span className={`px-2 py-1 text-xs rounded ${
                    currentOrder.priority === 'High' ? 'bg-red-100 text-red-700' :
                    currentOrder.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-green-100 text-green-700'
                  }`}>
                    {currentOrder.priority}
                  </span>
                </div>
              </div>
            </div>

            {currentOrder.specialInstructions && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mt-4">
                <div className="flex items-start">
                  <BellIcon className="h-4 w-4 text-yellow-600 mt-0.5 mr-2" />
                  <span className="text-sm text-yellow-800">{currentOrder.specialInstructions}</span>
                </div>
              </div>
            )}

            <div className="flex space-x-3 pt-4">
              <button
                onClick={handleStartDelivery}
                className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 flex items-center justify-center"
              >
                <TruckIcon className="h-4 w-4 mr-2" />
                Start Delivery
              </button>
              <button
                onClick={handleCompleteDelivery}
                className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 flex items-center justify-center"
              >
                <CheckCircleIcon className="h-4 w-4 mr-2" />
                Mark Delivered
              </button>
              <button
                onClick={handleReportIssue}
                className="flex-1 bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 flex items-center justify-center"
              >
                <BellIcon className="h-4 w-4 mr-2" />
                Report Issue
              </button>
            </div>
          </div>
        )}

        {/* Available Orders */}
        {orders.filter(o => o.status === 'pending').length > 0 && (
          <div className="bg-white rounded-lg shadow-sm p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Available Orders</h2>
            <div className="space-y-3">
              {orders.filter(o => o.status === 'pending').map(order => (
                <div key={order.id} className="border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <span className="font-medium text-gray-900">{order.id}</span>
                      <span className="ml-2 text-sm text-gray-600">{order.customerName}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 text-xs rounded ${
                        order.priority === 'High' ? 'bg-red-100 text-red-700' :
                        order.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {order.priority}
                      </span>
                      <span className="text-sm text-gray-600">₹{order.payment}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                    <span>{order.deliveryAddress}</span>
                    <span>{order.distance} • {order.estimatedTime}</span>
                  </div>
                  <button
                    onClick={() => handleAcceptOrder(order)}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 flex items-center justify-center"
                  >
                    Accept Order
                    <ArrowRightIcon className="h-4 w-4 ml-2" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Privacy Settings */}
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Privacy Settings</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-900">Location Sharing</span>
              <select className="px-3 py-2 border border-gray-300 rounded-md text-sm">
                <option>With Dispatch Only</option>
                <option>With Customer</option>
                <option>Private</option>
              </select>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-900">Phone Visibility</span>
              <select className="px-3 py-2 border border-gray-300 rounded-md text-sm">
                <option>Show Last 4 Digits</option>
                <option>Show Full Number</option>
                <option>Hide Number</option>
              </select>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-900">Data Retention</span>
              <select className="px-3 py-2 border border-gray-300 rounded-md text-sm">
                <option>24 Hours</option>
                <option>7 Days</option>
                <option>30 Days</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
