import Head from 'next/head';
import { useState, useEffect, useRef } from 'react';

declare global {
  interface Window {
    L: any;
    currentRoute?: any;
  }
}

export default function SimpleDashboard() {
  const mapRef = useRef(null);
  const [isTracking, setIsTracking] = useState(false);
  const [deliveryStops, setDeliveryStops] = useState([]);
  const [routeStats, setRouteStats] = useState({ distance: 0, time: 0, completed: 0, remaining: 0 });
  const [mapLoaded, setMapLoaded] = useState(false);
  const [vehiclePosition, setVehiclePosition] = useState({ lat: 17.3850, lng: 78.4867 });
  const [mapInstance, setMapInstance] = useState(null);

  // Form states
  const [driverName, setDriverName] = useState('Raj Kumar');
  const [vehicleId, setVehicleId] = useState('MH12 AB 1234');
  const [startLocation, setStartLocation] = useState('Nalla Narasimha Reddy Education Society\'s Group of Institutions, CM23+774, Korremula Rd, Via Narapally, Peerzadiguda, Hyderabad, Majarguda, Telangana 500088');
  const [destination, setDestination] = useState('B 85 ,Phase-1, Sachivalaya Colony, Vanasthalipuram, Hyderabad, Telangana 500070');
  const [newStop, setNewStop] = useState('');

  // Load Leaflet scripts and initialize map
  useEffect(() => {
    const loadLeaflet = async () => {
      try {
        if (typeof window !== 'undefined' && !window.L) {
          // Load Leaflet CSS
          const leafletCSS = document.createElement('link');
          leafletCSS.rel = 'stylesheet';
          leafletCSS.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
          leafletCSS.crossOrigin = 'anonymous';
          document.head.appendChild(leafletCSS);

          // Load Leaflet JS
          const leafletScript = document.createElement('script');
          leafletScript.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
          leafletScript.crossOrigin = 'anonymous';
          leafletScript.async = true;
          leafletScript.defer = true;
          
          leafletScript.onload = () => {
            setTimeout(() => {
              initializeMap();
            }, 100); // Small delay to ensure Leaflet is fully loaded
          };
          
          leafletScript.onerror = () => {
            console.error('Failed to load Leaflet');
            setMapLoaded(false);
          };
          
          document.head.appendChild(leafletScript);
        } else if (window.L && mapRef.current && !mapLoaded) {
          setTimeout(() => {
            initializeMap();
          }, 100);
        }
      } catch (error) {
        console.error('Error loading Leaflet:', error);
        setMapLoaded(false);
      }
    };

    const initializeMap = () => {
      try {
        if (mapRef.current && window.L) {
          const map = window.L.map(mapRef.current).setView([17.3850, 78.4867], 14);
          
          window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
          }).addTo(map);

          // Add vehicle marker
          const vehicleIcon = window.L.divIcon({
            html: '<div style="background: #FF6B35; color: white; border: 3px solid white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-size: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.4);">🚚</div>',
            iconSize: [40, 40]
          });

          window.L.marker([vehiclePosition.lat, vehiclePosition.lng], { icon: vehicleIcon })
            .addTo(map)
            .bindPopup('<b>Current Vehicle Position</b><br>Driver: Raj Kumar<br>Vehicle: MH12 AB 1234');

          setMapInstance(map);
          setMapLoaded(true);
        }
      } catch (error) {
        console.error('Error initializing map:', error);
        setMapLoaded(false);
      }
    };

    loadLeaflet();
  }, [vehiclePosition, mapLoaded]);

  const startLiveTracking = () => {
    setIsTracking(true);
    
    // Open detailed GPS map with proper parameters
    const params = new URLSearchParams({
      driver: driverName,
      vehicle: vehicleId,
      start: startLocation,
      destination: destination,
      stops: deliveryStops.join(',')
    });
    
    const gpsMapUrl = `file:///C:/Users/Abhi/Desktop/JEEVAN%20JAVA/intelligent_fleet_routing_platform_structure/DETAILED_GPS_MAP.html?${params.toString()}`;
    console.log('Opening GPS map with URL:', gpsMapUrl);
    window.open(gpsMapUrl, '_blank', 'width=1400,height=900');
  };

  const addDeliveryStop = () => {
    if (newStop.trim()) {
      setDeliveryStops([...deliveryStops, newStop.trim()]);
      setNewStop('');
    }
  };

  const removeDeliveryStop = (index) => {
    setDeliveryStops(deliveryStops.filter((_, i) => i !== index));
  };

  const runQAOAOptimization = () => {
    if (!startLocation || !destination) {
      alert('Please enter start location and destination');
      return;
    }

    // Simulate QAOA optimization
    const allStops = [startLocation, ...deliveryStops, destination];
    setRouteStats({
      distance: Math.random() * 20 + 10, // Random distance 10-30 km
      time: Math.random() * 60 + 30, // Random time 30-90 mins
      completed: 0,
      remaining: allStops.length
    });

    // Draw route on map if map is loaded
    if (mapInstance && window.L) {
      try {
        // Clear existing route
        if (window.currentRoute) {
          mapInstance.removeLayer(window.currentRoute);
        }

        // Create sample route coordinates (Hyderabad area)
        const routeCoordinates = [
          [17.3850, 78.4867], // Hyderabad center
          [17.3750, 78.4767], // Nalla Narasimha Reddy area
          [17.4050, 78.5067], // Vanasthalipuram area
          [17.4177, 78.4533], // Banjara Hills area
          [17.3850, 78.4867]  // Back to center
        ];

        // Draw route line
        window.currentRoute = window.L.polyline(routeCoordinates, {
          color: '#3b82f6',
          weight: 4,
          opacity: 0.7,
          dashArray: '10, 10'
        }).addTo(mapInstance);

        // Add pickup marker
        const pickupIcon = window.L.divIcon({
          html: '<div style="background: #1A73E8; color: white; border: 3px solid white; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 12px rgba(0,0,0,0.4);">📍</div>',
          iconSize: [35, 35]
        });

        window.L.marker(routeCoordinates[1], { icon: pickupIcon })
          .addTo(mapInstance)
          .bindPopup('<b>PICKUP LOCATION</b><br>' + startLocation);

        // Add destination marker
        const destinationIcon = window.L.divIcon({
          html: '<div style="background: #34A853; color: white; border: 3px solid white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-size: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.4);">🏁</div>',
          iconSize: [40, 40]
        });

        window.L.marker(routeCoordinates[2], { icon: destinationIcon })
          .addTo(mapInstance)
          .bindPopup('<b>DELIVERY DESTINATION</b><br>' + destination);

        // Fit map to show all markers
        const bounds = window.L.latLngBounds(routeCoordinates);
        mapInstance.fitBounds(bounds, { padding: [50, 50] });
      } catch (error) {
        console.error('Error drawing route:', error);
      }
    }

    alert(`✅ Route Optimized!\n\n${allStops.length} stops optimized using QAOA\nDistance: ${(Math.random() * 20 + 10).toFixed(1)} km\nTime: ${Math.round(Math.random() * 60 + 30)} mins`);
  };

  return (
    <>
      <Head>
        <title>FleetRoute AI - Simple Dashboard</title>
        <style>{`
          @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
          }
          .tracking-active {
            animation: pulse 2s infinite;
            background: #10b981;
          }
        `}</style>
      </Head>

      <div style={{ minHeight: '100vh', background: '#f3f4f6', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
        {/* Navigation Header */}
        <div style={{ background: 'white', padding: '1rem 2rem', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1f2937', margin: 0 }}>🚛 FleetRoute AI</h1>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <a href="/app/dashboard-simple" style={{ textDecoration: 'none', color: '#6b7280', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#f3f4f6' }}>Dashboard</a>
            <a href="/app/fleet" style={{ textDecoration: 'none', color: '#6b7280', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#f3f4f6' }}>Fleet</a>
            <a href="/app/optimize" style={{ textDecoration: 'none', color: '#6b7280', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#f3f4f6' }}>Optimize</a>
            <a href="/app/analytics" style={{ textDecoration: 'none', color: '#6b7280', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#f3f4f6' }}>Analytics</a>
            <span style={{ color: '#6b7280', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#e5e7eb' }}>dispatcher</span>
            <a href="#" style={{ textDecoration: 'none', color: '#dc2626', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#fef2f2' }}>Sign out</a>
          </div>
        </div>

        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem' }}>
          <div style={{ marginBottom: '2rem' }}>
            <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1f2937', marginBottom: '0.5rem' }}>🚀 FleetRoute AI - Simple Dashboard</h1>
            <p style={{ color: '#6b7280', fontSize: '1.1rem' }}>Advanced Fleet Routing with QAOA Quantum Optimization</p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 3fr', gap: '2rem' }}>
            {/* Left Panel - Delivery Inputs */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* Driver & Vehicle Info */}
              <div style={{ background: 'white', borderRadius: '0.75rem', padding: '1.5rem', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}>
                <h2 style={{ fontSize: '1.125rem', fontWeight: '600', color: '#1f2937', marginBottom: '1rem' }}>👤 Driver & Vehicle</h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '500', color: '#374151', marginBottom: '0.5rem' }}>Driver Name</label>
                    <input
                      type="text"
                      value={driverName}
                      onChange={(e) => setDriverName(e.target.value)}
                      style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '0.5rem', fontSize: '0.875rem' }}
                      placeholder="Enter driver name"
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '500', color: '#374151', marginBottom: '0.5rem' }}>Vehicle ID</label>
                    <input
                      type="text"
                      value={vehicleId}
                      onChange={(e) => setVehicleId(e.target.value)}
                      style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '0.5rem', fontSize: '0.875rem' }}
                      placeholder="Enter vehicle ID"
                    />
                  </div>
                </div>
              </div>

              {/* Delivery Details */}
              <div style={{ background: 'white', borderRadius: '0.75rem', padding: '1.5rem', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}>
                <h2 style={{ fontSize: '1.125rem', fontWeight: '600', color: '#1f2937', marginBottom: '1rem' }}>📍 Delivery Details</h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '500', color: '#374151', marginBottom: '0.5rem' }}>Start Location</label>
                    <textarea
                      value={startLocation}
                      onChange={(e) => setStartLocation(e.target.value)}
                      style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '0.5rem', fontSize: '0.875rem', minHeight: '80px' }}
                      placeholder="Enter start location"
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '500', color: '#374151', marginBottom: '0.5rem' }}>Destination</label>
                    <textarea
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '0.5rem', fontSize: '0.875rem', minHeight: '80px' }}
                      placeholder="Enter destination"
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '500', color: '#374151', marginBottom: '0.5rem' }}>Delivery Stops</label>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                      <input
                        type="text"
                        value={newStop}
                        onChange={(e) => setNewStop(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && addDeliveryStop()}
                        style={{ flex: 1, padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '0.5rem', fontSize: '0.875rem' }}
                        placeholder="Add delivery stop"
                      />
                      <button
                        onClick={addDeliveryStop}
                        style={{ padding: '0.75rem 1rem', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}
                      >
                        Add
                      </button>
                    </div>
                    {deliveryStops.length > 0 && (
                      <div style={{ marginTop: '0.5rem', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                        {deliveryStops.map((stop, index) => (
                          <div key={index} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#f9fafb', padding: '0.5rem 0.75rem', borderRadius: '0.375rem' }}>
                            <span style={{ fontSize: '0.875rem', color: '#374151' }}>{stop}</span>
                            <button
                              onClick={() => removeDeliveryStop(index)}
                              style={{ color: '#ef4444', background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.875rem' }}
                            >
                              Remove
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Start Tracking Button */}
              <button
                onClick={startLiveTracking}
                style={{ 
                  width: '100%', 
                  padding: '1rem', 
                  borderRadius: '0.75rem', 
                  fontWeight: '600', 
                  color: 'white',
                  background: isTracking ? '#10b981' : '#059669',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '1rem'
                }}
              >
                {isTracking ? '🛰️ Live Tracking Active' : '🚀 Start Live Routing'}
              </button>

              {/* Route Optimization */}
              <div style={{ background: 'white', borderRadius: '0.75rem', padding: '1.5rem', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}>
                <h2 style={{ fontSize: '1.125rem', fontWeight: '600', color: '#1f2937', marginBottom: '1rem' }}>⚛️ QAOA Optimization</h2>
                <button
                  onClick={runQAOAOptimization}
                  style={{ width: '100%', padding: '0.75rem', background: '#7c3aed', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}
                >
                  🧬 Run Quantum Optimization
                </button>
                {routeStats.distance > 0 && (
                  <div style={{ marginTop: '1rem', padding: '0.75rem', background: '#f3e8ff', borderRadius: '0.5rem' }}>
                    <div style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e40af' }}>✅ Route Optimized</div>
                    <div style={{ fontSize: '0.75rem', color: '#6366f1', marginTop: '0.25rem' }}>
                      {routeStats.remaining} stops optimized using QAOA
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Main Panel - Map and Route Information */}
            <div style={{ background: 'white', borderRadius: '0.75rem', padding: '2rem', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1f2937' }}>🗺️ Live GPS Navigation</h2>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  {isTracking && (
                    <span style={{ background: '#10b981', color: 'white', fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px' }}>LIVE</span>
                  )}
                  <span style={{ background: '#3b82f6', color: 'white', fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px' }}>GPS ACTIVE</span>
                  <span style={{ background: '#7c3aed', color: 'white', fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px' }}>QAOA ACTIVE</span>
                </div>
              </div>

              {/* Map Container */}
              <div style={{ marginBottom: '2rem' }}>
                <div 
                  ref={mapRef} 
                  style={{ 
                    height: '400px', 
                    borderRadius: '0.75rem', 
                    border: '2px solid #e5e7eb',
                    background: '#f3f4f6',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.125rem',
                    color: '#6b7280'
                  }}
                >
                  {!mapLoaded && '🗺️ Loading Interactive Map...'}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
                <div style={{ textAlign: 'center', padding: '1.5rem', background: '#f0f9ff', borderRadius: '0.75rem' }}>
                  <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#3b82f6' }}>{routeStats.distance.toFixed(1)}</div>
                  <div style={{ fontSize: '0.875rem', color: '#6b7280' }}>Total Distance (km)</div>
                </div>
                <div style={{ textAlign: 'center', padding: '1.5rem', background: '#f0fdf4', borderRadius: '0.75rem' }}>
                  <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#10b981' }}>{routeStats.time.toFixed(0)}</div>
                  <div style={{ fontSize: '0.875rem', color: '#6b7280' }}>Est. Time (mins)</div>
                </div>
                <div style={{ textAlign: 'center', padding: '1.5rem', background: '#faf5ff', borderRadius: '0.75rem' }}>
                  <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#8b5cf6' }}>{routeStats.completed.toFixed(0)}</div>
                  <div style={{ fontSize: '0.875rem', color: '#6b7280' }}>Completed Stops</div>
                </div>
                <div style={{ textAlign: 'center', padding: '1.5rem', background: '#fef3c7', borderRadius: '0.75rem' }}>
                  <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#f59e0b' }}>{routeStats.remaining.toFixed(0)}</div>
                  <div style={{ fontSize: '0.875rem', color: '#6b7280' }}>Remaining Stops</div>
                </div>
              </div>

              <div style={{ padding: '1.5rem', background: '#f8fafc', borderRadius: '0.75rem', marginTop: '1rem' }}>
                <h3 style={{ fontSize: '1rem', fontWeight: '600', color: '#1f2937', marginBottom: '1rem' }}>🚚 Current Vehicle Position</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', fontSize: '0.875rem' }}>
                  <div>
                    <span style={{ color: '#6b7280' }}>Driver:</span>
                    <span style={{ fontWeight: '600', color: '#1f2937' }}> {driverName}</span>
                  </div>
                  <div>
                    <span style={{ color: '#6b7280' }}>Vehicle:</span>
                    <span style={{ fontWeight: '600', color: '#1f2937' }}> {vehicleId}</span>
                  </div>
                  <div>
                    <span style={{ color: '#6b7280' }}>Status:</span>
                    <span style={{ fontWeight: '600', color: '#10b981' }}> {isTracking ? 'Active' : 'Inactive'}</span>
                  </div>
                  <div>
                    <span style={{ color: '#6b7280' }}>Route:</span>
                    <span style={{ fontWeight: '600', color: '#3b82f6' }}> {routeStats.distance > 0 ? 'Optimized' : 'Not Set'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
