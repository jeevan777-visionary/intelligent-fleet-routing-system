import Head from 'next/head';
import { useState, useEffect } from 'react';
import { Layout } from '../../components/Layout';
import { WorkingMap } from '../../components/WorkingMap';

export default function SimpleDashboard() {
  const [showCreateOrder, setShowCreateOrder] = useState(false);
  const [showCreateVehicle, setShowCreateVehicle] = useState(false);
  const [quantumOptimization, setQuantumOptimization] = useState(null);
  const [isRunningQuantum, setIsRunningQuantum] = useState(false);
  const [orders, setOrders] = useState([
    { id: 'ORD-001', customer: 'Priya Sharma', pickup: 'Restaurant - Mumbai Central', delivery: 'Andheri West', status: 'active' },
    { id: 'ORD-002', customer: 'Amit Patel', pickup: 'Grocery Store - Bandra', delivery: 'Worli', status: 'pending' }
  ]);
  const [vehicles, setVehicles] = useState([
    { id: 'VH-001', type: 'Bike', plate: 'MH12 AB 1234', driver: 'Raj Kumar', status: 'active' },
    { id: 'VH-002', type: 'Van', plate: 'MH12 CD 5678', driver: 'Sarah Johnson', status: 'active' }
  ]);

  const runQuantumOptimization = async () => {
    setIsRunningQuantum(true);
    
    // Simulate QAOA quantum optimization
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const results = {
      algorithm: 'QAOA (Quantum Approximate Optimization Algorithm)',
      qubitsUsed: 8,
      classicalTime: '3 minutes',
      quantumTime: '45 seconds',
      improvement: '75% faster',
      routes: [
        {
          vehicle: 'Bike - MH12 AB 1234',
          driver: 'Raj Kumar',
          optimizedRoute: ['Depot', 'Customer A', 'Customer C', 'Customer B', 'Depot'],
          distance: '12.5 km',
          time: '45 mins',
          quantumScore: 0.92
        }
      ]
    };
    
    setQuantumOptimization(results);
    setIsRunningQuantum(false);
  };

  useEffect(() => {
    // Fetch real data from backend
    const fetchBackendData = async () => {
      try {
        const response = await fetch('http://localhost:8000/api/fleet/vehicles');
        const data = await response.json();
        setVehicles(data);
        console.log('Connected to backend:', data);
      } catch (error) {
        console.log('Using mock data - backend not available');
      }
    };

    fetchBackendData();
  }, []);

  const handleCreateOrder = (orderData: any) => {
    const newOrder = {
      id: `ORD-${Date.now()}`,
      ...orderData,
      status: 'pending'
    };
    setOrders([...orders, newOrder]);
    setShowCreateOrder(false);
  };

  const handleCreateVehicle = (vehicleData: any) => {
    const newVehicle = {
      id: `VH-${Date.now()}`,
      ...vehicleData,
      status: 'active'
    };
    setVehicles([...vehicles, newVehicle]);
    setShowCreateVehicle(false);
  };
  return (
    <>
      <Head>
        <title>Route Optimization Dashboard - FleetRoute AI</title>
      </Head>

      <Layout user={{ id: "1", name: "John Doe", email: "john@example.com", role: "dispatcher", organization: "Demo Fleet" }}>
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Route Optimization Dashboard</h1>
          <p className="text-gray-600 mt-2">Reduce delivery time from 3 days to 1-2 days through intelligent routing</p>
        </div>

        {/* Main Value Proposition */}
        <div className="bg-gradient-to-r from-green-500 to-blue-600 rounded-lg p-8 mb-8 text-white">
          <h2 className="text-2xl font-bold mb-4">🚀 Route Optimization Results</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-3xl font-bold">3 Days</div>
              <div className="text-sm opacity-90">Before Optimization</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold">→</div>
              <div className="text-sm opacity-90">50% Faster</div>
            </div>
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-3xl font-bold">1.5 Days</div>
              <div className="text-sm opacity-90">After Optimization</div>
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-green-600">35%</div>
            <div className="text-gray-600">Distance Reduction</div>
            <div className="text-sm text-gray-500">69km → 45km</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-blue-600">50%</div>
            <div className="text-gray-600">Time Savings</div>
            <div className="text-sm text-gray-500">3 days → 1.5 days</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-purple-600">₹2.4L</div>
            <div className="text-gray-600">Cost Savings</div>
            <div className="text-sm text-gray-500">Monthly</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-orange-600">94%</div>
            <div className="text-gray-600">On-Time Delivery</div>
            <div className="text-sm text-gray-500">Improved</div>
          </div>
        </div>

        {/* QAOA Quantum Optimization */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">⚛️ QAOA Quantum Optimization</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="border-2 border-gray-200 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-3">Classical Computing</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div>• 180 seconds processing time</div>
                <div>• Limited to local optimum</div>
                <div>• High computational cost</div>
              </div>
            </div>
            
            <div className="border-2 border-purple-200 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-3">Quantum Computing (QAOA)</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div>• 45 seconds processing time</div>
                <div>• Global optimum approximation</div>
                <div>• 75% faster processing</div>
              </div>
            </div>
          </div>

          <div className="flex justify-center mb-6">
            <button
              onClick={runQuantumOptimization}
              disabled={isRunningQuantum}
              className="bg-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-purple-700 disabled:opacity-50"
            >
              {isRunningQuantum ? 'Running QAOA...' : '🚀 Run QAOA Optimization'}
            </button>
          </div>

          {quantumOptimization && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-3">✅ Quantum Results</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-gray-600">Algorithm</div>
                  <div className="font-medium">{quantumOptimization.algorithm}</div>
                </div>
                <div>
                  <div className="text-gray-600">Qubits Used</div>
                  <div className="font-medium">{quantumOptimization.qubitsUsed}</div>
                </div>
                <div>
                  <div className="text-gray-600">Time Improvement</div>
                  <div className="font-medium text-green-600">{quantumOptimization.improvement}</div>
                </div>
                <div>
                  <div className="text-gray-600">Processing Time</div>
                  <div className="font-medium">{quantumOptimization.quantumTime}</div>
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">🗺️ Live GPS Tracking</h2>
          <WorkingMap vehicles={vehicles.map(v => ({
            id: v.id,
            name: `${v.type} - ${v.plate}`,
            driver: v.driver,
            status: v.status,
            location: { lat: 19.0760 + Math.random() * 0.1, lng: 72.8777 + Math.random() * 0.1 }
          }))} />
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="bg-blue-600 text-white rounded-lg p-4 hover:bg-blue-700">
              <div className="font-bold">📦 Create Order</div>
              <div className="text-sm opacity-90">Add new delivery order</div>
            </button>
            <button className="bg-green-600 text-white rounded-lg p-4 hover:bg-green-700">
              <div className="font-bold">🚀 Optimize Routes</div>
              <div className="text-sm opacity-90">Run optimization algorithm</div>
            </button>
            <button className="bg-purple-600 text-white rounded-lg p-4 hover:bg-purple-700">
              <div className="font-bold">📊 View Analytics</div>
              <div className="text-sm opacity-90">See performance metrics</div>
            </button>
          </div>
        </div>
      </Layout>
    </>
  );
}
