import Head from 'next/head';
import { useState, useEffect } from 'react';
import { Layout } from '../../components/Layout';

declare global {
  interface Window {
    L: any;
  }
}

export default function DeployableDashboard() {
  const [orders, setOrders] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [map, setMap] = useState(null);
  const [markers, setMarkers] = useState({});
  const [routeInfo, setRouteInfo] = useState(null);

  useEffect(() => {
    // Load Leaflet
    if (typeof window !== 'undefined') {
      const leafletScript = document.createElement('script');
      leafletScript.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      leafletScript.async = true;
      leafletScript.onload = () => {
        const leafletCSS = document.createElement('link');
        leafletCSS.rel = 'stylesheet';
        leafletCSS.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        document.head.appendChild(leafletCSS);
        
        setTimeout(() => initializeMap(), 100);
      };
      document.body.appendChild(leafletScript);
    }

    // Load routing machine
    const routingScript = document.createElement('script');
    routingScript.src = 'https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.js';
    routingScript.async = true;
    document.body.appendChild(routingScript);

    const routingCSS = document.createElement('link');
    routingCSS.rel = 'stylesheet';
    routingCSS.href = 'https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.css';
    document.head.appendChild(routingCSS);

    // Fetch initial data
    fetchInitialData();
  }, []);

  const initializeMap = () => {
    if (!window.L) return;

    const mapInstance = window.L.map('map').setView([17.3850, 78.4867], 14);
    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(mapInstance);

    setMap(mapInstance);
    
    // Add depot marker
    const depotIcon = window.L.divIcon({
      html: '<div style="background: #4285F4; color: white; border-radius: 50%; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; font-size: 16px; border: 3px solid white;">🏢</div>',
      iconSize: [32, 32]
    });
    
    window.L.marker([17.3850, 78.4867], { icon: depotIcon })
      .addTo(mapInstance)
      .bindPopup('<b>Main Depot</b><br>Hyderabad Central');
  };

  const fetchInitialData = async () => {
    try {
      // Fetch vehicles from backend
      const vehiclesResponse = await fetch('http://localhost:8000/api/fleet/vehicles');
      if (vehiclesResponse.ok) {
        const vehiclesData = await vehiclesResponse.json();
        setVehicles(vehiclesData);
        addVehicleMarkers(vehiclesData);
      }

      // Fetch orders from backend
      const ordersResponse = await fetch('http://localhost:8000/api/orders');
      if (ordersResponse.ok) {
        const ordersData = await ordersResponse.json();
        setOrders(ordersData);
      }
    } catch (error) {
      console.log('Using mock data - backend not available');
      // Use mock data if backend is not available
      const mockVehicles = [
        { id: 1, name: 'MH12 AB 1234', driver: 'Raj Kumar', lat: 17.3850, lng: 78.4867, status: 'active' },
        { id: 2, name: 'MH12 CD 5678', driver: 'Sarah Johnson', lat: 17.3950, lng: 78.4967, status: 'active' },
        { id: 3, name: 'MH12 EF 9012', driver: 'Mike Chen', lat: 17.4050, lng: 78.5067, status: 'active' }
      ];
      setVehicles(mockVehicles);
      addVehicleMarkers(mockVehicles);
    }
  };

  const addVehicleMarkers = (vehicleData) => {
    if (!window.L || !map) return;

    const vehicleMarkers = {};
    
    vehicleData.forEach(vehicle => {
      const vehicleIcon = window.L.divIcon({
        html: '<div style="background: #34A853; color: white; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; font-size: 18px; border: 3px solid white; animation: pulse 2s infinite;">🚚</div>',
        iconSize: [35, 35]
      });

      const marker = window.L.marker([vehicle.lat, vehicle.lng], { icon: vehicleIcon })
        .addTo(map)
        .bindPopup(`<b>${vehicle.name}</b><br>${vehicle.driver}<br>Status: ${vehicle.status}`);
      
      vehicleMarkers[vehicle.id] = marker;
    });

    setMarkers(vehicleMarkers);
  };

  const createOrder = async (e) => {
    e.preventDefault();
    setLoading(true);

    const orderData = {
      customer: e.target.customerName.value,
      pickup: e.target.pickupAddress.value,
      delivery: e.target.deliveryAddress.value,
      priority: e.target.priority?.value || 'normal',
      status: 'pending',
      timestamp: new Date().toISOString()
    };

    try {
      // Send to backend
      const response = await fetch('http://localhost:8000/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });

      if (response.ok) {
        const newOrder = await response.json();
        setOrders([...orders, newOrder]);
        createGPSRoute(newOrder);
      } else {
        // Use frontend-only logic if backend fails
        const newOrder = { ...orderData, id: Date.now() };
        setOrders([...orders, newOrder]);
        createGPSRoute(newOrder);
      }
    } catch (error) {
      console.log('Creating order in frontend mode');
      const newOrder = { ...orderData, id: Date.now() };
      setOrders([...orders, newOrder]);
      createGPSRoute(newOrder);
    }

    setLoading(false);
    e.target.reset();
  };

  const createGPSRoute = (order) => {
    if (!window.L || !map) return;

    // Get coordinates for addresses
    const pickupCoords = getHyderabadCoords(order.pickup);
    const deliveryCoords = getHyderabadCoords(order.delivery);

    // Add pickup marker
    const pickupIcon = window.L.divIcon({
      html: '<div style="background: #FBBC04; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-size: 16px; border: 3px solid white;">📍</div>',
      iconSize: [30, 30]
    });

    const deliveryIcon = window.L.divIcon({
      html: '<div style="background: #EA4335; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-size: 16px; border: 3px solid white;">🏠</div>',
      iconSize: [30, 30]
    });

    window.L.marker(pickupCoords, { icon: pickupIcon })
      .addTo(map)
      .bindPopup(`<b>Pickup</b><br>${order.pickup}<br>${order.customer}`);

    window.L.marker(deliveryCoords, { icon: deliveryIcon })
      .addTo(map)
      .bindPopup(`<b>Delivery</b><br>${order.delivery}<br>${order.customer}`);

    // Create route if routing machine is available
    if (window.L.Routing && vehicles.length > 0) {
      const vehicle = vehicles[0];
      const routeControl = window.L.Routing.control({
        waypoints: [
          window.L.latLng(vehicle.lat, vehicle.lng),
          window.L.latLng(pickupCoords[0], pickupCoords[1]),
          window.L.latLng(deliveryCoords[0], deliveryCoords[1])
        ],
        routeWhileDragging: false,
        addWaypoints: false,
        createMarker: () => null,
        lineOptions: { styles: [{ color: '#4285F4', weight: 8, opacity: 0.8 }] }
      }).on('routesfound', (e) => {
        const summary = e.routes[0].summary;
        setRouteInfo({
          distance: (summary.totalDistance / 1000).toFixed(1) + ' km',
          time: Math.round(summary.totalTime / 60) + ' mins',
          vehicle: vehicle.name,
          status: 'Active'
        });
      }).addTo(map);

      // Start vehicle movement
      startVehicleMovement(vehicle, pickupCoords, deliveryCoords, order);
    }

    // Center map on route
    const bounds = window.L.latLngBounds([
      pickupCoords,
      deliveryCoords
    ]);
    map.fitBounds(bounds, { padding: [50, 50] });
  };

  const getHyderabadCoords = (address) => {
    const coords = {
      'nalla narasimha reddy': [17.3850, 78.4867],
      'korremula': [17.3950, 78.4967],
      'peerzadiguda': [17.3750, 78.4767],
      'vanasthalipuram': [17.4050, 78.5067],
      'hyderabad': [17.3850, 78.4867]
    };
    
    for (let place in coords) {
      if (address.toLowerCase().includes(place)) {
        return coords[place];
      }
    }
    
    return [17.3850 + (Math.random() - 0.5) * 0.05, 78.4867 + (Math.random() - 0.5) * 0.05];
  };

  const startVehicleMovement = (vehicle, pickup, delivery, order) => {
    const route = [pickup, delivery];
    let waypointIndex = 0;
    
    const moveInterval = setInterval(() => {
      if (waypointIndex >= route.length) {
        clearInterval(moveInterval);
        order.status = 'delivered';
        setOrders([...orders]);
        return;
      }
      
      const target = route[waypointIndex];
      const current = [vehicle.lat, vehicle.lng];
      
      const step = 0.05;
      const newLat = current[0] + (target[0] - current[0]) * step;
      const newLng = current[1] + (target[1] - current[1]) * step;
      
      vehicle.lat = newLat;
      vehicle.lng = newLng;
      
      if (markers[vehicle.id]) {
        markers[vehicle.id].setLatLng([newLat, newLng]);
      }
      
      const distance = Math.sqrt(
        Math.pow(target[0] - newLat, 2) + 
        Math.pow(target[1] - newLng, 2)
      );
      
      if (distance < 0.001) {
        waypointIndex++;
      }
    }, 1000);
  };

  return (
    <>
      <Head>
        <title>FleetRoute AI - Deployable Platform</title>
        <style>{`
          @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
          }
        `}</style>
      </Head>

      <Layout user={{ id: "1", name: "Fleet Manager", email: "manager@fleetai.com", role: "dispatcher", organization: "FleetRoute AI" }}>
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">🚀 FleetRoute AI - Deployable Platform</h1>
          <p className="text-gray-600 mt-2">Live GPS Tracking with Backend Integration</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Panel */}
          <div className="lg:col-span-1 space-y-6">
            {/* Order Form */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">📦 Create Order</h2>
              <form onSubmit={createOrder} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Customer Name</label>
                  <input type="text" name="customerName" required 
                         className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Pickup Address</label>
                  <input type="text" name="pickupAddress" required 
                         className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Address</label>
                  <input type="text" name="deliveryAddress" required 
                         className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                </div>
                <button type="submit" disabled={loading} 
                        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50">
                  {loading ? 'Creating...' : '🚚 Create Order & GPS Route'}
                </button>
              </form>
            </div>

            {/* GPS Details */}
            {routeInfo && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">📍 GPS Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">📏 Distance:</span>
                    <strong className="text-blue-600">{routeInfo.distance}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">⏱️ Time:</span>
                    <strong className="text-blue-600">{routeInfo.time}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">🚚 Vehicle:</span>
                    <strong className="text-green-600">{routeInfo.vehicle}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">📊 Status:</span>
                    <strong className="text-orange-600">{routeInfo.status}</strong>
                  </div>
                </div>
              </div>
            )}

            {/* Active Orders */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">📋 Active Orders</h3>
              <div className="space-y-3">
                {orders.length === 0 ? (
                  <p className="text-gray-500 text-sm">No active orders</p>
                ) : (
                  orders.map(order => (
                    <div key={order.id} className="border-l-4 border-blue-500 pl-3 py-2">
                      <div className="font-medium text-sm">{order.customer}</div>
                      <div className="text-xs text-gray-600">
                        📍 {order.pickup} → 🏠 {order.delivery}
                      </div>
                      <div className="text-xs text-blue-600 mt-1">{order.status}</div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Map */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-900">🗺️ Live GPS Navigation</h2>
                <div className="flex space-x-2">
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">LIVE</span>
                  <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">GPS CONNECTED</span>
                </div>
              </div>
              <div id="map" className="h-96 rounded-lg border-2 border-gray-200"></div>
              <div className="mt-4 p-3 bg-gray-50 rounded text-xs text-gray-600">
                <div className="flex justify-between">
                  <span>🛰️ GPS: <strong className="text-green-600">Connected</strong></span>
                  <span>📡 Signal: <strong className="text-green-600">Strong</strong></span>
                  <span>🔄 Update: <strong className="text-blue-600">Live</strong></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
}
