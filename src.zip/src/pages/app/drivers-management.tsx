import Head from 'next/head';
import { useState } from 'react';

export default function DriversManagement() {
  const [drivers, setDrivers] = useState([
    { id: 'DRV-001', name: 'Ravi Kumar', phone: '+91 98765 43210', email: 'ravi.kumar@fleetroute.ai', license: 'DL-12345678', experience: '5 years', status: 'active', rating: 4.8, totalDeliveries: 1247, currentVehicle: 'TRK-102', joinDate: '2021-03-15', lastActive: '2024-03-09 14:30' },
    { id: 'DRV-002', name: 'Arun Singh', phone: '+91 98765 43211', email: 'arun.singh@fleetroute.ai', license: 'DL-23456789', experience: '3 years', status: 'active', rating: 4.6, totalDeliveries: 892, currentVehicle: 'TRK-221', joinDate: '2022-01-20', lastActive: '2024-03-09 12:15' },
    { id: 'DRV-003', name: 'Sameer Khan', phone: '+91 98765 43212', email: 'sameer.khan@fleetroute.ai', license: 'DL-34567890', experience: '7 years', status: 'delivering', rating: 4.9, totalDeliveries: 1567, currentVehicle: 'TRK-340', joinDate: '2020-06-10', lastActive: '2024-03-09 15:45' },
    { id: 'DRV-004', name: 'Raj Kumar', phone: '+91 98765 43213', email: 'raj.kumar@fleetroute.ai', license: 'DL-45678901', experience: '4 years', status: 'active', rating: 4.7, totalDeliveries: 1103, currentVehicle: 'TRK-451', joinDate: '2021-09-05', lastActive: '2024-03-09 13:20' },
    { id: 'DRV-005', name: 'Priya Sharma', phone: '+91 98765 43214', email: 'priya.sharma@fleetroute.ai', license: 'DL-56789012', experience: '2 years', status: 'off-duty', rating: 4.5, totalDeliveries: 456, currentVehicle: 'TRK-562', joinDate: '2023-01-15', lastActive: '2024-03-08 18:00' }
  ]);

  const [selectedDriver, setSelectedDriver] = useState(null);

  const getStatusColor = (status) => {
    switch(status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'delivering': return 'bg-blue-100 text-blue-800';
      case 'off-duty': return 'bg-gray-100 text-gray-800';
      case 'on-break': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRatingStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push('⭐');
    }
    if (hasHalfStar) {
      stars.push('✨');
    }
    
    return stars.join(' ');
  };

  return (
    <>
      <Head>
        <title>Drivers Management - FleetRoute AI</title>
      </Head>

      <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
        {/* Header Navigation */}
        <header style={{ background: 'white', borderBottom: '1px solid #e2e8f0', padding: '1rem 2rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
              <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>🚛 FleetRoute AI</h1>
              <nav style={{ display: 'flex', gap: '1rem' }}>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Dashboard</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Fleet</a>
                <a href="#" style={{ textDecoration: 'none', color: '#3b82f6', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#eff6ff', fontWeight: '500' }}>Drivers</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Routes</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Analytics</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Settings</a>
              </nav>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <button style={{ background: '#f1f5f9', border: 'none', padding: '0.5rem', borderRadius: '0.5rem', cursor: 'pointer' }}>🔔</button>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{ width: '32px', height: '32px', background: '#3b82f6', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 'bold' }}>D</div>
                <span style={{ fontSize: '0.875rem', color: '#64748b' }}>dispatcher</span>
              </div>
            </div>
          </div>
        </header>

        <div style={{ padding: '2rem', maxWidth: '1600px', margin: '0 auto' }}>
          {/* Header */}
          <div style={{ marginBottom: '2rem' }}>
            <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b', marginBottom: '0.5rem' }}>👥 Drivers Management</h1>
            <p style={{ color: '#64748b', fontSize: '1.125rem' }}>Manage your drivers, track performance, and monitor their activities</p>
          </div>

          {/* Driver Statistics */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{drivers.length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Total Drivers</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#10b981' }}>{drivers.filter(d => d.status === 'active').length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Active Now</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#3b82f6' }}>{drivers.filter(d => d.status === 'delivering').length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>On Delivery</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#f59e0b' }}>{drivers.filter(d => d.rating >= 4.5).length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Top Rated</div>
            </div>
          </div>

          {/* Drivers Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '1.5rem' }}>
            {drivers.map((driver, index) => (
              <div 
                key={index}
                onClick={() => setSelectedDriver(driver)}
                style={{ 
                  background: 'white', 
                  borderRadius: '0.75rem', 
                  padding: '1.5rem', 
                  boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  border: '2px solid transparent'
                }}
                onMouseEnter={(e) => {
                  const target = e.currentTarget;
                  target.style.transform = 'translateY(-2px)';
                  target.style.boxShadow = '0 8px 25px rgba(0,0,0,0.1)';
                  target.style.borderColor = '#3b82f6';
                }}
                onMouseLeave={(e) => {
                  const target = e.currentTarget;
                  target.style.transform = 'translateY(0)';
                  target.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
                  target.style.borderColor = 'transparent';
                }}
              >
                {/* Driver Header */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                  <div>
                    <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: '#1e293b', margin: '0 0 0.25rem 0' }}>{driver.name}</h3>
                    <p style={{ fontSize: '0.875rem', color: '#64748b', margin: 0 }}>{driver.id}</p>
                  </div>
                  <span style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontWeight: '500' }} className={getStatusColor(driver.status)}>
                    {driver.status}
                  </span>
                </div>

                {/* Driver Info */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1rem' }}>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>📱 Phone</div>
                    <div style={{ fontSize: '0.875rem', color: '#1e293b', fontWeight: '500' }}>{driver.phone}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>🚚 Vehicle</div>
                    <div style={{ fontSize: '0.875rem', color: '#1e293b', fontWeight: '500' }}>{driver.currentVehicle}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>📊 Experience</div>
                    <div style={{ fontSize: '0.875rem', color: '#1e293b', fontWeight: '500' }}>{driver.experience}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>📦 Deliveries</div>
                    <div style={{ fontSize: '0.875rem', color: '#1e293b', fontWeight: '500' }}>{driver.totalDeliveries.toLocaleString()}</div>
                  </div>
                </div>

                {/* Rating */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Rating:</span>
                    <span style={{ fontSize: '1rem', fontWeight: '500', color: '#1e293b' }}>{driver.rating}</span>
                    <span style={{ fontSize: '0.875rem' }}>{getRatingStars(driver.rating)}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button 
                    style={{ 
                      flex: 1, 
                      padding: '0.5rem', 
                      background: '#3b82f6', 
                      color: 'white', 
                      border: 'none', 
                      borderRadius: '0.375rem', 
                      cursor: 'pointer', 
                      fontSize: '0.875rem',
                      fontWeight: '500'
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      console.log('Tracking driver:', driver);
                      
                      const params = new URLSearchParams({
                        driver: driver.name,
                        vehicle: driver.currentVehicle,
                        start: 'Hyderabad Central',
                        destination: 'Vanasthalipuram',
                        stops: ['Nalla Narasimha Reddy College', 'Uppal X Roads', 'Vanasthalipuram'].join(','),
                        status: driver.status,
                        driverId: driver.id,
                        experience: driver.experience,
                        rating: driver.rating.toString()
                      });
                      
                      const gpsMapUrl = `file:///C:/Users/Abhi/Desktop/JEEVAN%20JAVA/intelligent_fleet_routing_platform_structure/DETAILED_GPS_MAP.html?${params.toString()}`;
                      console.log('Opening GPS map for driver:', gpsMapUrl);
                      window.open(gpsMapUrl, '_blank', 'width=1400,height=900');
                    }}
                  >
                    📍 Track
                  </button>
                  <button 
                    style={{ 
                      flex: 1, 
                      padding: '0.5rem', 
                      background: '#f59e0b', 
                      color: 'white', 
                      border: 'none', 
                      borderRadius: '0.375rem', 
                      cursor: 'pointer', 
                      fontSize: '0.875rem',
                      fontWeight: '500'
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      // Assign vehicle action
                    }}
                  >
                    🚛 Assign
                  </button>
                  <button 
                    style={{ 
                      flex: 1, 
                      padding: '0.5rem', 
                      background: '#64748b', 
                      color: 'white', 
                      border: 'none', 
                      borderRadius: '0.375rem', 
                      cursor: 'pointer', 
                      fontSize: '0.875rem',
                      fontWeight: '500'
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      // View profile action
                    }}
                  >
                    👤 Profile
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Driver Details Modal */}
          {selectedDriver && (
            <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
              <div style={{ background: 'white', borderRadius: '0.75rem', padding: '2rem', maxWidth: '700px', width: '90%', maxHeight: '80vh', overflowY: 'auto' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                  <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>👤 {selectedDriver.name}</h2>
                  <button onClick={() => setSelectedDriver(null)} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#64748b' }}>✕</button>
                </div>

                {/* Driver Profile Header */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem', padding: '1rem', background: '#f8fafc', borderRadius: '0.5rem' }}>
                  <div style={{ width: '60px', height: '60px', background: '#3b82f6', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '1.5rem', fontWeight: 'bold' }}>
                    {selectedDriver.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div style={{ flex: 1 }}>
                    <h3 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1e293b', margin: '0 0 0.25rem 0' }}>{selectedDriver.name}</h3>
                    <p style={{ color: '#64748b', margin: '0 0 0.25rem 0' }}>{selectedDriver.id}</p>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <span style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontWeight: '500' }} className={getStatusColor(selectedDriver.status)}>
                        {selectedDriver.status}
                      </span>
                      <span style={{ fontSize: '0.875rem', color: '#64748b' }}>⭐ {selectedDriver.rating} {getRatingStars(selectedDriver.rating)}</span>
                    </div>
                  </div>
                </div>

                {/* Driver Details Grid */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>📱 Phone Number</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedDriver.phone}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>📧 Email Address</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedDriver.email}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>🪪 License Number</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedDriver.license}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>🚚 Current Vehicle</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedDriver.currentVehicle}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>📊 Experience</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedDriver.experience}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>📦 Total Deliveries</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedDriver.totalDeliveries.toLocaleString()}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>📅 Join Date</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedDriver.joinDate}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>🕐 Last Active</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedDriver.lastActive}</div>
                  </div>
                </div>

                {/* Performance Metrics */}
                <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem', marginBottom: '1.5rem' }}>
                  <h4 style={{ fontSize: '1rem', fontWeight: '600', color: '#1e293b', margin: '0 0 0.75rem 0' }}>📈 Performance Metrics</h4>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem' }}>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#10b981' }}>{selectedDriver.rating}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Average Rating</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#3b82f6' }}>{Math.floor(selectedDriver.totalDeliveries / 30)}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Monthly Deliveries</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#f59e0b' }}>{selectedDriver.experience.split(' ')[0]}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Years Experience</div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.75rem' }}>
                  <button style={{ padding: '0.75rem', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    📍 Track Live
                  </button>
                  <button style={{ padding: '0.75rem', background: '#10b981', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    📞 Contact
                  </button>
                  <button style={{ padding: '0.75rem', background: '#f59e0b', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    📊 Performance
                  </button>
                  <button style={{ padding: '0.75rem', background: '#64748b', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    📄 History
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
