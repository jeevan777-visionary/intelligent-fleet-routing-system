import Head from 'next/head';
import { useState, useEffect } from 'react';

export default function FleetManagement() {
  const [vehicles, setVehicles] = useState([
    { id: 'TRK-102', type: 'Heavy Truck', model: 'Tata 407', year: '2022', driver: 'Ravi Kumar', status: 'moving', fuel: 78, mileage: 45678, lastMaintenance: '2024-01-15', nextMaintenance: '2024-04-15', insurance: '2024-12-31' },
    { id: 'TRK-221', type: 'Light Truck', model: 'Mahindra Bolero', year: '2021', driver: 'Arun Singh', status: 'idle', fuel: 92, mileage: 32145, lastMaintenance: '2024-02-01', nextMaintenance: '2024-05-01', insurance: '2024-11-30' },
    { id: 'TRK-340', type: 'Medium Truck', model: 'Ashok Leyland', year: '2023', driver: 'Sameer Khan', status: 'delivering', fuel: 65, mileage: 28990, lastMaintenance: '2024-01-20', nextMaintenance: '2024-04-20', insurance: '2025-01-15' },
    { id: 'TRK-451', type: 'Heavy Truck', model: 'Tata Prima', year: '2022', driver: 'Raj Kumar', status: 'moving', fuel: 88, mileage: 51234, lastMaintenance: '2024-01-10', nextMaintenance: '2024-04-10', insurance: '2024-12-15' },
    { id: 'TRK-562', type: 'Van', model: 'Maruti Eeco', year: '2023', driver: 'Priya Sharma', status: 'maintenance', fuel: 45, mileage: 15678, lastMaintenance: '2024-03-01', nextMaintenance: '2024-06-01', insurance: '2025-02-28' }
  ]);

  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [showAddVehicle, setShowAddVehicle] = useState(false);

  const getStatusColor = (status) => {
    switch(status) {
      case 'moving': return 'bg-green-100 text-green-800';
      case 'delivering': return 'bg-blue-100 text-blue-800';
      case 'idle': return 'bg-yellow-100 text-yellow-800';
      case 'maintenance': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getMaintenanceStatus = (nextMaintenance: string) => {
    const today = new Date();
    const maintenanceDate = new Date(nextMaintenance);
    const daysUntilMaintenance = Math.ceil((maintenanceDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilMaintenance <= 7) return { color: 'text-red-600', status: 'Urgent' };
    if (daysUntilMaintenance <= 30) return { color: 'text-yellow-600', status: 'Soon' };
    return { color: 'text-green-600', status: 'OK' };
  };

  const getInsuranceStatus = (insuranceDate: string) => {
    const today = new Date();
    const insurance = new Date(insuranceDate);
    const daysUntilExpiry = Math.ceil((insurance.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry <= 30) return { color: 'text-red-600', status: 'Expiring Soon' };
    return { color: 'text-green-600', status: 'Valid' };
  };

  return (
    <>
      <Head>
        <title>Fleet Management - FleetRoute AI</title>
      </Head>

      <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
        {/* Header Navigation */}
        <header style={{ background: 'white', borderBottom: '1px solid #e2e8f0', padding: '1rem 2rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
              <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>🚛 FleetRoute AI</h1>
              <nav style={{ display: 'flex', gap: '1rem' }}>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Dashboard</a>
                <a href="#" style={{ textDecoration: 'none', color: '#3b82f6', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#eff6ff', fontWeight: '500' }}>Fleet</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Drivers</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Routes</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Analytics</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Settings</a>
              </nav>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <button style={{ background: '#f1f5f9', border: 'none', padding: '0.5rem', borderRadius: '0.5rem', cursor: 'pointer' }}>🔔</button>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{ width: '32px', height: '32px', background: '#3b82f6', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 'bold' }}>D</div>
                <span style={{ fontSize: '0.875rem', color: '#64748b' }}>dispatcher</span>
              </div>
            </div>
          </div>
        </header>

        <div style={{ padding: '2rem', maxWidth: '1600px', margin: '0 auto' }}>
          {/* Header Actions */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
            <div>
              <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b', marginBottom: '0.5rem' }}>🚛 Fleet Management</h1>
              <p style={{ color: '#64748b', fontSize: '1.125rem' }}>Manage your entire fleet of vehicles and track their maintenance</p>
            </div>
            <button
              onClick={() => setShowAddVehicle(true)}
              style={{ padding: '0.75rem 1.5rem', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500', display: 'flex', alignItems: 'center', gap: '0.5rem' }}
            >
              ➕ Add Vehicle
            </button>
          </div>

          {/* Fleet Statistics */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{vehicles.length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Total Vehicles</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#10b981' }}>{vehicles.filter(v => v.status === 'moving').length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Active Vehicles</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#f59e0b' }}>{vehicles.filter(v => v.status === 'maintenance').length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>In Maintenance</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#ef4444' }}>{vehicles.filter(v => getMaintenanceStatus(v.nextMaintenance).status === 'Urgent').length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Urgent Maintenance</div>
            </div>
          </div>

          {/* Vehicles Table */}
          <div style={{ background: 'white', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
            <div style={{ padding: '1.5rem', borderBottom: '1px solid #e2e8f0' }}>
              <h2 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1e293b', margin: 0 }}>🚚 Vehicle Fleet</h2>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: '#f8fafc' }}>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Vehicle ID</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Type & Model</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Driver</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Status</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Fuel</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Mileage</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Maintenance</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Insurance</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {vehicles.map((vehicle, index) => {
                    const maintenanceStatus = getMaintenanceStatus(vehicle.nextMaintenance);
                    const insuranceStatus = getInsuranceStatus(vehicle.insurance);
                    
                    return (
                      <tr key={index} style={{ borderBottom: '1px solid #f1f5f9', cursor: 'pointer' }} 
                          onClick={() => setSelectedVehicle(vehicle)}
                          onMouseEnter={(e) => {
                            const target = e.currentTarget;
                            target.style.background = '#f8fafc';
                          }}
                          onMouseLeave={(e) => {
                            const target = e.currentTarget;
                            target.style.background = 'white';
                          }}>
                        <td style={{ padding: '1rem', fontWeight: '600', color: '#1e293b' }}>{vehicle.id}</td>
                        <td style={{ padding: '1rem' }}>
                          <div>
                            <div style={{ fontWeight: '500', color: '#1e293b' }}>{vehicle.type}</div>
                            <div style={{ fontSize: '0.875rem', color: '#64748b' }}>{vehicle.model} ({vehicle.year})</div>
                          </div>
                        </td>
                        <td style={{ padding: '1rem', color: '#64748b' }}>{vehicle.driver}</td>
                        <td style={{ padding: '1rem' }}>
                          <span style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontWeight: '500' }} className={getStatusColor(vehicle.status)}>
                            {vehicle.status}
                          </span>
                        </td>
                        <td style={{ padding: '1rem' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <div style={{ width: '8px', height: '8px', background: vehicle.fuel > 50 ? '#10b981' : vehicle.fuel > 25 ? '#f59e0b' : '#ef4444', borderRadius: '50%' }}></div>
                            <span style={{ color: '#64748b' }}>{vehicle.fuel}%</span>
                          </div>
                        </td>
                        <td style={{ padding: '1rem', color: '#64748b' }}>{vehicle.mileage.toLocaleString()} km</td>
                        <td style={{ padding: '1rem' }}>
                          <div>
                            <div style={{ fontSize: '0.875rem', color: '#64748b' }}>{vehicle.nextMaintenance}</div>
                            <div style={{ fontSize: '0.75rem', fontWeight: '500' }} className={maintenanceStatus.color}>{maintenanceStatus.status}</div>
                          </div>
                        </td>
                        <td style={{ padding: '1rem' }}>
                          <div>
                            <div style={{ fontSize: '0.875rem', color: '#64748b' }}>{vehicle.insurance}</div>
                            <div style={{ fontSize: '0.75rem', fontWeight: '500' }} className={insuranceStatus.color}>{insuranceStatus.status}</div>
                          </div>
                        </td>
                        <td style={{ padding: '1rem' }}>
                          <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                console.log('Tracking vehicle:', vehicle);
                                
                                const params = new URLSearchParams({
                                  driver: vehicle.driver,
                                  vehicle: vehicle.id,
                                  start: 'Hyderabad Central',
                                  destination: 'Vanasthalipuram',
                                  stops: ['Warehouse', 'Distribution Center', 'Nalla Narasimha Reddy College'].join(','),
                                  status: vehicle.status,
                                  fuel: vehicle.fuel.toString(),
                                  mileage: vehicle.mileage.toString(),
                                  model: vehicle.model,
                                  type: vehicle.type
                                });
                                
                                const gpsMapUrl = `file:///C:/Users/Abhi/Desktop/JEEVAN%20JAVA/intelligent_fleet_routing_platform_structure/DETAILED_GPS_MAP.html?${params.toString()}`;
                                console.log('Opening GPS map for vehicle:', gpsMapUrl);
                                window.open(gpsMapUrl, '_blank', 'width=1400,height=900');
                              }} 
                              style={{ padding: '0.25rem 0.5rem', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '0.375rem', cursor: 'pointer', fontSize: '0.75rem' }}>
                              📍 Track
                            </button>
                            <button style={{ padding: '0.25rem 0.5rem', background: '#f59e0b', color: 'white', border: 'none', borderRadius: '0.375rem', cursor: 'pointer', fontSize: '0.75rem' }}>
                              🔧 Service
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Vehicle Details Modal */}
          {selectedVehicle && (
            <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
              <div style={{ background: 'white', borderRadius: '0.75rem', padding: '2rem', maxWidth: '600px', width: '90%', maxHeight: '80vh', overflowY: 'auto' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                  <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>🚚 {selectedVehicle.id}</h2>
                  <button onClick={() => setSelectedVehicle(null)} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#64748b' }}>✕</button>
                </div>
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>Vehicle Type</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedVehicle.type}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>Model</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedVehicle.model} ({selectedVehicle.year})</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>Current Driver</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedVehicle.driver}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>Status</div>
                    <span style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontWeight: '500' }} className={getStatusColor(selectedVehicle.status)}>
                      {selectedVehicle.status}
                    </span>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>Fuel Level</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <div style={{ width: '100px', height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                        <div style={{ width: `${selectedVehicle.fuel}%`, height: '100%', background: selectedVehicle.fuel > 50 ? '#10b981' : selectedVehicle.fuel > 25 ? '#f59e0b' : '#ef4444' }}></div>
                      </div>
                      <span style={{ fontWeight: '500', color: '#1e293b' }}>{selectedVehicle.fuel}%</span>
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>Total Mileage</div>
                    <div style={{ fontWeight: '500', color: '#1e293b' }}>{selectedVehicle.mileage.toLocaleString()} km</div>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '1rem' }}>
                  <button style={{ flex: 1, padding: '0.75rem', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    📍 Track Vehicle
                  </button>
                  <button style={{ flex: 1, padding: '0.75rem', background: '#f59e0b', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    🔧 Schedule Maintenance
                  </button>
                  <button style={{ flex: 1, padding: '0.75rem', background: '#ef4444', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    📄 View History
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
