import Head from 'next/head';
import { useState } from 'react';

export default function RoutesManagement() {
  const [routes, setRoutes] = useState([
    { 
      id: 'RTE-001', 
      name: 'Hyderabad Central to Vanasthalipuram', 
      driver: 'Sameer Khan', 
      vehicle: 'TRK-340', 
      status: 'active', 
      progress: 65,
      distance: 12.5, 
      estimatedTime: 45, 
      actualTime: 28,
      stops: ['Nalla Narasimha Reddy College', 'Uppal X Roads', 'Vanasthalipuram Phase 1'],
      startTime: '2024-03-09 14:30',
      estimatedArrival: '2024-03-09 15:15',
      priority: 'high',
      fuelUsed: 8.2
    },
    { 
      id: 'RTE-002', 
      name: 'Banjara Hills to Hitech City', 
      driver: 'Raj Kumar', 
      vehicle: 'TRK-451', 
      status: 'active', 
      progress: 35,
      distance: 8.3, 
      estimatedTime: 30, 
      actualTime: 18,
      stops: ['Jubilee Hills', 'Madhapur', 'Hitech City'],
      startTime: '2024-03-09 13:20',
      estimatedArrival: '2024-03-09 13:50',
      priority: 'medium',
      fuelUsed: 4.1
    },
    { 
      id: 'RTE-003', 
      name: 'Secunderabad to Kukatpally', 
      driver: 'Ravi Kumar', 
      vehicle: 'TRK-102', 
      status: 'completed', 
      progress: 100,
      distance: 15.7, 
      estimatedTime: 55, 
      actualTime: 52,
      stops: ['Begumpet', 'Ameerpet', 'Kukatpally Phase 3'],
      startTime: '2024-03-09 11:00',
      actualArrival: '2024-03-09 11:52',
      priority: 'normal',
      fuelUsed: 12.8
    },
    { 
      id: 'RTE-004', 
      name: 'Gachibowli to Charminar', 
      driver: 'Arun Singh', 
      vehicle: 'TRK-221', 
      status: 'pending', 
      progress: 0,
      distance: 22.1, 
      estimatedTime: 75, 
      actualTime: 0,
      stops: ['Mehdipatnam', 'Masab Tank', 'Charminar'],
      scheduledTime: '2024-03-09 16:00',
      estimatedArrival: '2024-03-09 17:15',
      priority: 'low',
      fuelUsed: 0
    }
  ]);

  const [selectedRoute, setSelectedRoute] = useState(null);
  const [showCreateRoute, setShowCreateRoute] = useState(false);

  const getStatusColor = (status) => {
    switch(status) {
      case 'active': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-gray-100 text-gray-800';
      case 'delayed': return 'bg-red-100 text-red-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'normal': return 'bg-green-100 text-green-800';
      case 'low': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressColor = (progress) => {
    if (progress >= 75) return '#10b981';
    if (progress >= 50) return '#3b82f6';
    if (progress >= 25) return '#f59e0b';
    return '#ef4444';
  };

  return (
    <>
      <Head>
        <title>Routes Management - FleetRoute AI</title>
      </Head>

      <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
        {/* Header Navigation */}
        <header style={{ background: 'white', borderBottom: '1px solid #e2e8f0', padding: '1rem 2rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
              <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>🚛 FleetRoute AI</h1>
              <nav style={{ display: 'flex', gap: '1rem' }}>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Dashboard</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Fleet</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Drivers</a>
                <a href="#" style={{ textDecoration: 'none', color: '#3b82f6', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#eff6ff', fontWeight: '500' }}>Routes</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Analytics</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Settings</a>
              </nav>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <button style={{ background: '#f1f5f9', border: 'none', padding: '0.5rem', borderRadius: '0.5rem', cursor: 'pointer' }}>🔔</button>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{ width: '32px', height: '32px', background: '#3b82f6', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 'bold' }}>D</div>
                <span style={{ fontSize: '0.875rem', color: '#64748b' }}>dispatcher</span>
              </div>
            </div>
          </div>
        </header>

        <div style={{ padding: '2rem', maxWidth: '1600px', margin: '0 auto' }}>
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
            <div>
              <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b', marginBottom: '0.5rem' }}>🛣️ Routes Management</h1>
              <p style={{ color: '#64748b', fontSize: '1.125rem' }}>Manage delivery routes, track progress, and optimize logistics</p>
            </div>
            <div style={{ display: 'flex', gap: '1rem' }}>
              <button
                onClick={() => setShowCreateRoute(true)}
                style={{ padding: '0.75rem 1.5rem', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500', display: 'flex', alignItems: 'center', gap: '0.5rem' }}
              >
                ➕ Create Route
              </button>
              <button style={{ padding: '0.75rem 1.5rem', background: '#10b981', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                ⚛️ Optimize All
              </button>
            </div>
          </div>

          {/* Route Statistics */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{routes.length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Total Routes</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#3b82f6' }}>{routes.filter(r => r.status === 'active').length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Active Routes</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#10b981' }}>{routes.filter(r => r.status === 'completed').length}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Completed Today</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#f59e0b' }}>{routes.reduce((acc, r) => acc + r.distance, 0).toFixed(1)}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Total Distance (km)</div>
            </div>
          </div>

          {/* Routes List */}
          <div style={{ background: 'white', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
            <div style={{ padding: '1.5rem', borderBottom: '1px solid #e2e8f0' }}>
              <h2 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1e293b', margin: 0 }}>🚚 Active Routes</h2>
            </div>
            
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {routes.map((route, index) => (
                <div 
                  key={index}
                  onClick={() => setSelectedRoute(route)}
                  style={{ 
                    padding: '1.5rem', 
                    borderBottom: index < routes.length - 1 ? '1px solid #f1f5f9' : 'none',
                    cursor: 'pointer',
                    transition: 'background 0.2s ease'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = '#f8fafc'}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'white'}
                >
                  {/* Route Header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '0.5rem' }}>
                        <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: '#1e293b', margin: 0 }}>{route.name}</h3>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>{route.id}</span>
                      </div>
                      <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                        <span style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontWeight: '500' }} className={getStatusColor(route.status)}>
                          {route.status}
                        </span>
                        <span style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontWeight: '500' }} className={getPriorityColor(route.priority)}>
                          {route.priority} priority
                        </span>
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '1.25rem', fontWeight: 'bold', color: '#1e293b' }}>{route.distance} km</div>
                      <div style={{ fontSize: '0.875rem', color: '#64748b' }}>{route.estimatedTime} mins</div>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  {route.status === 'active' && (
                    <div style={{ marginBottom: '1rem' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Route Progress</span>
                        <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{route.progress}%</span>
                      </div>
                      <div style={{ width: '100%', height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                        <div style={{ 
                          width: `${route.progress}%`, 
                          height: '100%', 
                          background: getProgressColor(route.progress),
                          transition: 'width 0.3s ease'
                        }}></div>
                      </div>
                    </div>
                  )}

                  {/* Route Details */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', marginBottom: '1rem' }}>
                    <div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>👤 Driver</div>
                      <div style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{route.driver}</div>
                    </div>
                    <div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>🚚 Vehicle</div>
                      <div style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{route.vehicle}</div>
                    </div>
                    <div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>🕐 Start Time</div>
                      <div style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{route.startTime}</div>
                    </div>
                    <div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>⛽ Fuel Used</div>
                      <div style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{route.fuelUsed} L</div>
                    </div>
                  </div>

                  {/* Delivery Stops */}
                  <div style={{ marginBottom: '1rem' }}>
                    <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.5rem' }}>📍 Delivery Stops ({route.stops.length})</div>
                    <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                      {route.stops.map((stop, stopIndex) => (
                        <span key={stopIndex} style={{ 
                          fontSize: '0.75rem', 
                          padding: '0.25rem 0.5rem', 
                          background: '#f1f5f9', 
                          borderRadius: '0.375rem', 
                          color: '#475569',
                          border: '1px solid #e2e8f0'
                        }}>
                          {stopIndex + 1}. {stop}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button 
                      style={{ 
                        padding: '0.5rem 1rem', 
                        background: '#3b82f6', 
                        color: 'white', 
                        border: 'none', 
                        borderRadius: '0.375rem', 
                        cursor: 'pointer', 
                        fontSize: '0.875rem',
                        fontWeight: '500'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        console.log('Tracking route:', route);
                        const params = new URLSearchParams({
                          driver: route.driver,
                          vehicle: route.vehicle,
                          start: route.stops[0],
                          destination: route.stops[route.stops.length - 1],
                          stops: route.stops.join(','),
                          status: route.status,
                          routeId: route.id,
                          progress: route.progress.toString()
                        });
                        
                        const gpsMapUrl = `file:///C:/Users/Abhi/Desktop/JEEVAN%20JAVA/intelligent_fleet_routing_platform_structure/DETAILED_GPS_MAP.html?${params.toString()}`;
                        console.log('Opening GPS map for route:', gpsMapUrl);
                        window.open(gpsMapUrl, '_blank', 'width=1400,height=900');
                      }}
                    >
                      🗺️ Track
                    </button>
                    <button 
                      style={{ 
                        padding: '0.5rem 1rem', 
                        background: '#10b981', 
                        color: 'white', 
                        border: 'none', 
                        borderRadius: '0.375rem', 
                        cursor: 'pointer', 
                        fontSize: '0.875rem',
                        fontWeight: '500'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        console.log('Optimizing route with QAOA:', route);
                        
                        // Simulate QAOA optimization with better route
                        const optimizedStops = [...route.stops].sort(() => Math.random() - 0.5); // Random optimization for demo
                        
                        const params = new URLSearchParams({
                          driver: route.driver,
                          vehicle: route.vehicle,
                          start: optimizedStops[0],
                          destination: optimizedStops[optimizedStops.length - 1],
                          stops: optimizedStops.join(','),
                          status: 'optimizing',
                          routeId: route.id,
                          optimization: 'qaoa',
                          originalStops: route.stops.join(',')
                        });
                        
                        const gpsMapUrl = `file:///C:/Users/Abhi/Desktop/JEEVAN%20JAVA/intelligent_fleet_routing_platform_structure/DETAILED_GPS_MAP.html?${params.toString()}`;
                        console.log('Opening optimized GPS map:', gpsMapUrl);
                        window.open(gpsMapUrl, '_blank', 'width=1400,height=900');
                        
                        // Update route status
                        setRoutes(prev => prev.map(r => 
                          r.id === route.id ? { ...r, status: 'optimizing' } : r
                        ));
                      }}
                    >
                      ⚛️ Optimize
                    </button>
                    <button 
                      style={{ 
                        padding: '0.5rem 1rem', 
                        background: '#f59e0b', 
                        color: 'white', 
                        border: 'none', 
                        borderRadius: '0.375rem', 
                        cursor: 'pointer', 
                        fontSize: '0.875rem',
                        fontWeight: '500'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        // Edit route action
                      }}
                    >
                      ✏️ Edit
                    </button>
                    <button 
                      style={{ 
                        padding: '0.5rem 1rem', 
                        background: '#ef4444', 
                        color: 'white', 
                        border: 'none', 
                        borderRadius: '0.375rem', 
                        cursor: 'pointer', 
                        fontSize: '0.875rem',
                        fontWeight: '500'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        // Cancel route action
                      }}
                    >
                      ❌ Cancel
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Route Details Modal */}
          {selectedRoute && (
            <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
              <div style={{ background: 'white', borderRadius: '0.75rem', padding: '2rem', maxWidth: '800px', width: '90%', maxHeight: '80vh', overflowY: 'auto' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                  <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>🛣️ {selectedRoute.name}</h2>
                  <button onClick={() => setSelectedRoute(null)} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#64748b' }}>✕</button>
                </div>

                {/* Route Overview */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
                  <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem' }}>
                    <h4 style={{ fontSize: '1rem', fontWeight: '600', color: '#1e293b', margin: '0 0 0.75rem 0' }}>Route Information</h4>
                    <div style={{ display: 'grid', gap: '0.5rem' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Route ID:</span>
                        <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{selectedRoute.id}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Distance:</span>
                        <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{selectedRoute.distance} km</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Est. Time:</span>
                        <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{selectedRoute.estimatedTime} mins</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Fuel Used:</span>
                        <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{selectedRoute.fuelUsed} L</span>
                      </div>
                    </div>
                  </div>

                  <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '0.5rem' }}>
                    <h4 style={{ fontSize: '1rem', fontWeight: '600', color: '#1e293b', margin: '0 0 0.75rem 0' }}>Assignment</h4>
                    <div style={{ display: 'grid', gap: '0.5rem' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Driver:</span>
                        <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{selectedRoute.driver}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Vehicle:</span>
                        <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{selectedRoute.vehicle}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Priority:</span>
                        <span style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontWeight: '500' }} className={getPriorityColor(selectedRoute.priority)}>
                          {selectedRoute.priority}
                        </span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Status:</span>
                        <span style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontWeight: '500' }} className={getStatusColor(selectedRoute.status)}>
                          {selectedRoute.status}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Progress Section */}
                {selectedRoute.status === 'active' && (
                  <div style={{ marginBottom: '1.5rem' }}>
                    <h4 style={{ fontSize: '1rem', fontWeight: '600', color: '#1e293b', margin: '0 0 0.75rem 0' }}>📊 Route Progress</h4>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                      <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Completion</span>
                      <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{selectedRoute.progress}%</span>
                    </div>
                    <div style={{ width: '100%', height: '12px', background: '#e2e8f0', borderRadius: '6px', overflow: 'hidden', marginBottom: '0.5rem' }}>
                      <div style={{ 
                        width: `${selectedRoute.progress}%`, 
                        height: '100%', 
                        background: getProgressColor(selectedRoute.progress),
                        transition: 'width 0.3s ease'
                      }}></div>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: '#64748b' }}>
                      <span>Started: {selectedRoute.startTime}</span>
                      <span>ETA: {selectedRoute.estimatedArrival}</span>
                    </div>
                  </div>
                )}

                {/* Delivery Stops */}
                <div style={{ marginBottom: '1.5rem' }}>
                  <h4 style={{ fontSize: '1rem', fontWeight: '600', color: '#1e293b', margin: '0 0 0.75rem 0' }}>📍 Delivery Stops</h4>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {selectedRoute.stops.map((stop, index) => (
                      <div key={index} style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: '0.75rem',
                        padding: '0.75rem',
                        background: '#f8fafc',
                        borderRadius: '0.5rem',
                        border: '1px solid #e2e8f0'
                      }}>
                        <div style={{ 
                          width: '32px', 
                          height: '32px', 
                          background: selectedRoute.status === 'completed' || (selectedRoute.status === 'active' && index < Math.floor(selectedRoute.stops.length * selectedRoute.progress / 100)) ? '#10b981' : '#e2e8f0',
                          borderRadius: '50%',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: 'white',
                          fontWeight: 'bold',
                          fontSize: '0.875rem'
                        }}>
                          {index + 1}
                        </div>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: '500', color: '#1e293b' }}>{stop}</div>
                          <div style={{ fontSize: '0.75rem', color: '#64748b' }}>
                            {selectedRoute.status === 'completed' || (selectedRoute.status === 'active' && index < Math.floor(selectedRoute.stops.length * selectedRoute.progress / 100)) ? '✅ Completed' : '⏳ Pending'}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.75rem' }}>
                  <button style={{ padding: '0.75rem', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    🗺️ Track Live
                  </button>
                  <button style={{ padding: '0.75rem', background: '#10b981', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    ⚛️ Re-optimize
                  </button>
                  <button style={{ padding: '0.75rem', background: '#f59e0b', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    📞 Contact Driver
                  </button>
                  <button style={{ padding: '0.75rem', background: '#ef4444', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
                    📄 Export Report
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
