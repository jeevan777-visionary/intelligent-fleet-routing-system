import Head from 'next/head';
import { useState, useEffect } from 'react';
import { PlusIcon, EyeIcon, PencilIcon, TrashIcon } from '@heroicons/react/24/outline';
import { Layout } from '../../components/Layout';

export default function Fleet() {
  const [vehicles, setVehicles] = useState([
    { id: 'TRK-001', name: 'Truck 001', driver: 'Raj Kumar', status: 'active', location: { lat: 19.0760, lng: 72.8777 }, speed: 45, fuel: 78 },
    { id: 'TRK-002', name: 'Truck 002', driver: 'Sarah Johnson', status: 'active', location: { lat: 19.0860, lng: 72.8877 }, speed: 52, fuel: 65 },
    { id: 'TRK-003', name: 'Truck 003', driver: 'Mike Chen', status: 'maintenance', location: { lat: 19.0660, lng: 72.8677 }, speed: 0, fuel: 82 }
  ]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Load data in background without blocking UI
    const timer = setTimeout(() => {
      fetchVehicles();
    }, 200);

    return () => clearTimeout(timer);
  }, []);

  const fetchVehicles = async () => {
    setLoading(true);
    try {
      const response = await fetch('http://localhost:8000/api/fleet/vehicles');
      const data = await response.json();
      setVehicles(data);
    } catch (error) {
      console.log('Using mock fleet data');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'maintenance': return 'bg-yellow-100 text-yellow-800';
      case 'inactive': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <Layout user={{ id: "1", name: "John Doe", email: "john@example.com", role: "dispatcher", organization: "Demo Fleet" }}>
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">Loading fleet data...</div>
        </div>
      </Layout>
    );
  }

  return (
    <>
      <Head>
        <title>Fleet - FleetRoute AI</title>
      </Head>

      <Layout user={{ id: "1", name: "John Doe", email: "john@example.com", role: "dispatcher", organization: "Demo Fleet" }}>
        <div className="mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Fleet Management</h1>
              <p className="text-gray-600">Manage your vehicles and drivers</p>
            </div>
            <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700">
              <PlusIcon className="h-5 w-5 mr-2" />
              Add Vehicle
            </button>
          </div>
        </div>

        {/* Fleet Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-gray-900">{vehicles.length}</div>
            <div className="text-gray-600">Total Vehicles</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-green-600">
              {vehicles.filter((v: any) => v.status === 'active').length}
            </div>
            <div className="text-gray-600">Active</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-yellow-600">
              {vehicles.filter((v: any) => v.status === 'maintenance').length}
            </div>
            <div className="text-gray-600">Maintenance</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-red-600">
              {vehicles.filter((v: any) => v.status === 'inactive').length}
            </div>
            <div className="text-gray-600">Inactive</div>
          </div>
        </div>

        {/* Vehicles Table */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Vehicle ID
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Driver
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Speed
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Fuel
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Location
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {vehicles.map((vehicle: any) => (
                    <tr key={vehicle.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {vehicle.id}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {vehicle.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {vehicle.driver}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(vehicle.status)}`}>
                          {vehicle.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {vehicle.speed || '--'} km/h
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {vehicle.fuel || '--'}%
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {vehicle.lat && vehicle.lng ? `${vehicle.lat.toFixed(4)}, ${vehicle.lng.toFixed(4)}` : '--'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <button className="text-primary-600 hover:text-primary-900">
                            <EyeIcon className="h-5 w-5" />
                          </button>
                          <button className="text-yellow-600 hover:text-yellow-900">
                            <PencilIcon className="h-5 w-5" />
                          </button>
                          <button className="text-red-600 hover:text-red-900">
                            <TrashIcon className="h-5 w-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
}
