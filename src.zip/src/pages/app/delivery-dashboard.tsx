import Head from 'next/head';
import { useState, useEffect } from 'react';
import { 
  MapPinIcon, 
  ClockIcon, 
  CurrencyDollarIcon,
  UserIcon,
  TruckIcon,
  CheckCircleIcon,
  PlusIcon
} from '@heroicons/react/24/outline';
import { Layout } from '../../components/Layout';

export default function DeliveryDashboard() {
  const [user, setUser] = useState({
    name: 'Raj Kumar',
    email: 'raj.kumar@example.com',
    phone: '+91 98765 43210',
    vehicle: 'Bike - MH12 AB 1234',
    rating: 4.8,
    totalDeliveries: 156,
    todayEarnings: 2450
  });

  const [activeOrders, setActiveOrders] = useState([
    {
      id: 'ORD-001',
      customer: 'Priya Sharma',
      pickup: 'Restaurant - Mumbai Central',
      delivery: 'Andheri West, Mumbai',
      distance: '5.2 km',
      estimatedTime: '25 mins',
      earnings: '₹85',
      status: 'active',
      timeLeft: '18 mins'
    },
    {
      id: 'ORD-002', 
      customer: 'Amit Patel',
      pickup: 'Grocery Store - Bandra',
      delivery: 'Worli, Mumbai',
      distance: '3.8 km',
      estimatedTime: '20 mins',
      earnings: '₹65',
      status: 'pending',
      timeLeft: '20 mins'
    }
  ]);

  const [completedOrders, setCompletedOrders] = useState([
    {
      id: 'ORD-999',
      customer: 'Neha Gupta',
      delivery: 'Marine Drive, Mumbai',
      earnings: '₹120',
      completedAt: '10 mins ago',
      rating: 5
    }
  ]);

  const [showCreateOrder, setShowCreateOrder] = useState(false);

  const handleAcceptOrder = (orderId: string) => {
    setActiveOrders(prev => 
      prev.map(order => 
        order.id === orderId 
          ? { ...order, status: 'active' }
          : order
      )
    );
  };

  const handleCompleteOrder = (orderId: string) => {
    const order = activeOrders.find(o => o.id === orderId);
    if (order) {
      const completedOrder = {
        ...order,
        completedAt: 'Just now',
        rating: 5
      };
      setCompletedOrders(prev => [completedOrder, ...prev]);
      setActiveOrders(prev => prev.filter(o => o.id !== orderId));
      setUser(prev => ({
        ...prev,
        todayEarnings: prev.todayEarnings + parseInt(order.earnings.replace('₹', ''))
      }));
    }
  };

  return (
    <>
      <Head>
        <title>Delivery Dashboard - FleetRoute AI</title>
      </Head>

      <Layout user={{ id: "1", name: user.name, email: user.email, role: "delivery_person", organization: "FleetRoute AI" }}>
        {/* Driver Profile */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 mb-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
                <UserIcon className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">{user.name}</h1>
                <p className="opacity-90">Delivery Partner • Rating: ⭐ {user.rating}</p>
                <p className="text-sm opacity-80">{user.vehicle}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">₹{user.todayEarnings}</div>
              <div className="text-sm opacity-90">Today's Earnings</div>
              <div className="text-sm opacity-80">{user.totalDeliveries} deliveries</div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center space-x-2">
              <TruckIcon className="h-5 w-5 text-blue-600" />
              <div>
                <div className="text-lg font-bold">{activeOrders.filter(o => o.status === 'active').length}</div>
                <div className="text-sm text-gray-600">Active</div>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center space-x-2">
              <ClockIcon className="h-5 w-5 text-orange-600" />
              <div>
                <div className="text-lg font-bold">{activeOrders.filter(o => o.status === 'pending').length}</div>
                <div className="text-sm text-gray-600">Pending</div>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center space-x-2">
              <CheckCircleIcon className="h-5 w-5 text-green-600" />
              <div>
                <div className="text-lg font-bold">{completedOrders.length}</div>
                <div className="text-sm text-gray-600">Completed</div>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center space-x-2">
              <CurrencyDollarIcon className="h-5 w-5 text-purple-600" />
              <div>
                <div className="text-lg font-bold">₹{user.todayEarnings}</div>
                <div className="text-sm text-gray-600">Today</div>
              </div>
            </div>
          </div>
        </div>

        {/* Active Orders */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">🚚 Active Orders</h2>
          <div className="space-y-4">
            {activeOrders.map((order) => (
              <div key={order.id} className="bg-white rounded-lg shadow p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-gray-900">Order {order.id}</h3>
                    <p className="text-sm text-gray-600">Customer: {order.customer}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-green-600">{order.earnings}</div>
                    <p className="text-sm text-gray-500">{order.distance} • {order.estimatedTime}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 text-sm text-gray-600 mb-3">
                  <MapPinIcon className="h-4 w-4" />
                  <span>{order.pickup}</span>
                  <span>→</span>
                  <span>{order.delivery}</span>
                </div>

                {order.status === 'active' && (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-2 mb-3">
                    <p className="text-sm text-yellow-800">⏰ Time remaining: {order.timeLeft}</p>
                  </div>
                )}

                <div className="flex space-x-3">
                  {order.status === 'pending' ? (
                    <button
                      onClick={() => handleAcceptOrder(order.id)}
                      className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
                    >
                      Accept Order
                    </button>
                  ) : (
                    <button
                      onClick={() => handleCompleteOrder(order.id)}
                      className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700"
                    >
                      Mark as Delivered
                    </button>
                  )}
                  <button className="bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300">
                    Call Customer
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Completed Orders */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">✅ Completed Today</h2>
          <div className="space-y-3">
            {completedOrders.map((order) => (
              <div key={order.id} className="bg-white rounded-lg shadow p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-900">Order {order.id}</h3>
                    <p className="text-sm text-gray-600">{order.customer} • {order.delivery}</p>
                    <p className="text-sm text-gray-500">{order.completedAt}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-green-600">{order.earnings}</div>
                    <p className="text-sm text-yellow-600">⭐ {order.rating}/5</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="fixed bottom-4 right-4 space-y-2">
          <button
            onClick={() => setShowCreateOrder(true)}
            className="bg-blue-600 text-white rounded-full p-4 shadow-lg hover:bg-blue-700"
          >
            <PlusIcon className="h-6 w-6" />
          </button>
        </div>
      </Layout>
    </>
  );
}
