import Head from 'next/head';
import { useState, useEffect, useRef } from 'react';

declare global {
  interface Window {
    L: any;
    currentRoute?: any;
  }
}

export default function ProfessionalFleetDashboard() {
  const mapRef = useRef(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [vehicles, setVehicles] = useState([
    { id: 'TRK-102', driver: 'Ravi Kumar', status: 'moving', lat: 17.3850, lng: 78.4867, speed: 45, fuel: 78, nextStop: 'Nalla Narasimha Reddy' },
    { id: 'TRK-221', driver: 'Arun Singh', status: 'idle', lat: 17.3750, lng: 78.4767, speed: 0, fuel: 92, nextStop: 'None' },
    { id: 'TRK-340', driver: 'Sameer Khan', status: 'delivering', lat: 17.4050, lng: 78.5067, speed: 25, fuel: 65, nextStop: 'Vanasthalipuram' },
    { id: 'TRK-451', driver: 'Raj Kumar', status: 'moving', lat: 17.4177, lng: 78.4533, speed: 55, fuel: 88, nextStop: 'Banjara Hills' },
    { id: 'TRK-562', driver: 'Priya Sharma', status: 'maintenance', lat: 17.4495, lng: 78.3810, speed: 0, fuel: 45, nextStop: 'Workshop' }
  ]);

  const [stats, setStats] = useState({
    totalVehicles: 48,
    activeDrivers: 35,
    deliveriesToday: 112,
    delayedRoutes: 4,
    totalDistance: 2456.7,
    avgFuelEfficiency: 12.5
  });

  useEffect(() => {
    const loadLeaflet = async () => {
      try {
        if (typeof window !== 'undefined' && !window.L) {
          const leafletCSS = document.createElement('link');
          leafletCSS.rel = 'stylesheet';
          leafletCSS.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
          leafletCSS.crossOrigin = 'anonymous';
          document.head.appendChild(leafletCSS);

          const leafletScript = document.createElement('script');
          leafletScript.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
          leafletScript.crossOrigin = 'anonymous';
          leafletScript.async = true;
          leafletScript.defer = true;
          
          leafletScript.onload = () => {
            setTimeout(() => initializeMap(), 100);
          };
          
          document.head.appendChild(leafletScript);
        } else if (window.L && mapRef.current && !mapLoaded) {
          setTimeout(() => initializeMap(), 100);
        }
      } catch (error) {
        console.error('Error loading Leaflet:', error);
      }
    };

    const initializeMap = () => {
      try {
        if (mapRef.current && window.L) {
          const map = window.L.map(mapRef.current).setView([17.3850, 78.4867], 12);
          
          window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
          }).addTo(map);

          // Add vehicle markers
          vehicles.forEach(vehicle => {
            const color = vehicle.status === 'moving' ? '#10b981' : 
                         vehicle.status === 'delivering' ? '#3b82f6' : 
                         vehicle.status === 'idle' ? '#f59e0b' : '#ef4444';
            
            const vehicleIcon = window.L.divIcon({
              html: `<div style="background: ${color}; color: white; border: 3px solid white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-size: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.4);">🚚</div>`,
              iconSize: [30, 30]
            });

            window.L.marker([vehicle.lat, vehicle.lng], { icon: vehicleIcon })
              .addTo(map)
              .bindPopup(`<b>${vehicle.id}</b><br>Driver: ${vehicle.driver}<br>Status: ${vehicle.status}<br>Speed: ${vehicle.speed} km/h`);
          });

          setMapLoaded(true);
        }
      } catch (error) {
        console.error('Error initializing map:', error);
      }
    };

    loadLeaflet();
  }, [vehicles, mapLoaded]);

  const getStatusColor = (status) => {
    switch(status) {
      case 'moving': return 'bg-green-100 text-green-800';
      case 'delivering': return 'bg-blue-100 text-blue-800';
      case 'idle': return 'bg-yellow-100 text-yellow-800';
      case 'maintenance': return 'bg-red-100 text-red-800';
      case 'tracking': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const openDetailedMap = (vehicle) => {
    console.log('Opening GPS map for vehicle:', vehicle);
    
    // Create realistic delivery stops based on vehicle status
    const deliveryStops = vehicle.status === 'delivering' 
      ? ['Nalla Narasimha Reddy College', 'Uppal X Roads', 'Vanasthalipuram Phase 1']
      : vehicle.status === 'moving'
      ? ['Hyderabad Central', 'Secunderabad Station', 'Begumpet']
      : ['Warehouse', 'Distribution Center'];
    
    const params = new URLSearchParams({
      driver: vehicle.driver,
      vehicle: vehicle.id,
      start: 'Hyderabad Central',
      destination: vehicle.nextStop || 'Vanasthalipuram',
      stops: deliveryStops.join(','),
      status: vehicle.status,
      speed: vehicle.speed.toString(),
      fuel: vehicle.fuel.toString()
    });
    
    const gpsMapUrl = `file:///C:/Users/Abhi/Desktop/JEEVAN%20JAVA/intelligent_fleet_routing_platform_structure/DETAILED_GPS_MAP.html?${params.toString()}`;
    console.log('Opening GPS map URL:', gpsMapUrl);
    
    // Open the detailed GPS map
    window.open(gpsMapUrl, '_blank', 'width=1400,height=900');
    
    // Update vehicle status to tracking
    setVehicles(prev => prev.map(v => 
      v.id === vehicle.id ? { ...v, status: 'tracking' } : v
    ));
  };

  return (
    <>
      <Head>
        <title>FleetRoute AI - Professional Fleet Dashboard</title>
        <style>{`
          @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
          }
          .card-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
          }
          .status-dot {
            animation: pulse 2s infinite;
          }
        `}</style>
      </Head>

      <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
        {/* Header Navigation */}
        <header style={{ background: 'white', borderBottom: '1px solid #e2e8f0', padding: '1rem 2rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
              <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>🚛 FleetRoute AI</h1>
              <nav style={{ display: 'flex', gap: '1rem' }}>
                <a href="#" style={{ textDecoration: 'none', color: '#3b82f6', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#eff6ff', fontWeight: '500' }}>Dashboard</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Fleet</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Drivers</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Routes</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Analytics</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Settings</a>
              </nav>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <button style={{ background: '#f1f5f9', border: 'none', padding: '0.5rem', borderRadius: '0.5rem', cursor: 'pointer' }}>🔔</button>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{ width: '32px', height: '32px', background: '#3b82f6', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 'bold' }}>D</div>
                <span style={{ fontSize: '0.875rem', color: '#64748b' }}>dispatcher</span>
              </div>
            </div>
          </div>
        </header>

        <div style={{ padding: '2rem', maxWidth: '1600px', margin: '0 auto' }}>
          {/* Fleet Overview Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', transition: 'all 0.3s ease' }} className="card-hover">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ fontSize: '2rem' }}>🚛</span>
                <span className="status-dot" style={{ width: '8px', height: '8px', background: '#10b981', borderRadius: '50%' }}></span>
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{stats.totalVehicles}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Total Vehicles</div>
            </div>
            
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', transition: 'all 0.3s ease' }} className="card-hover">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ fontSize: '2rem' }}>👤</span>
                <span className="status-dot" style={{ width: '8px', height: '8px', background: '#3b82f6', borderRadius: '50%' }}></span>
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{stats.activeDrivers}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Active Drivers</div>
            </div>
            
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', transition: 'all 0.3s ease' }} className="card-hover">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ fontSize: '2rem' }}>📦</span>
                <span className="status-dot" style={{ width: '8px', height: '8px', background: '#10b981', borderRadius: '50%' }}></span>
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{stats.deliveriesToday}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Deliveries Today</div>
            </div>
            
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', transition: 'all 0.3s ease' }} className="card-hover">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ fontSize: '2rem' }}>⚠️</span>
                <span className="status-dot" style={{ width: '8px', height: '8px', background: '#ef4444', borderRadius: '50%' }}></span>
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{stats.delayedRoutes}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Delayed Routes</div>
            </div>
            
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', transition: 'all 0.3s ease' }} className="card-hover">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ fontSize: '2rem' }}>🛣️</span>
                <span className="status-dot" style={{ width: '8px', height: '8px', background: '#10b981', borderRadius: '50%' }}></span>
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{stats.totalDistance.toFixed(1)}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Total Distance (km)</div>
            </div>
            
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', transition: 'all 0.3s ease' }} className="card-hover">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ fontSize: '2rem' }}>⛽</span>
                <span className="status-dot" style={{ width: '8px', height: '8px', background: '#10b981', borderRadius: '50%' }}></span>
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{stats.avgFuelEfficiency}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Avg Fuel (km/l)</div>
            </div>
          </div>

          {/* Main Content Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '2rem' }}>
            {/* Vehicle List Panel */}
            <div style={{ background: 'white', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ padding: '1.5rem', borderBottom: '1px solid #e2e8f0' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1e293b', margin: 0 }}>🚛 Fleet Vehicles</h2>
              </div>
              <div style={{ maxHeight: '600px', overflowY: 'auto' }}>
                {vehicles.map((vehicle, index) => (
                  <div
                    key={index}
                    onClick={() => setSelectedVehicle(vehicle)}
                    style={{ 
                      padding: '1rem 1.5rem', 
                      borderBottom: '1px solid #f1f5f9', 
                      cursor: 'pointer',
                      background: selectedVehicle?.id === vehicle.id ? '#f8fafc' : 'white',
                      transition: 'background 0.2s ease'
                    }}
                    onMouseEnter={(e) => {
                      const target = e.currentTarget;
                      target.style.background = '#f8fafc';
                    }}
                    onMouseLeave={(e) => {
                      const target = e.currentTarget;
                      target.style.background = selectedVehicle?.id === vehicle.id ? '#f8fafc' : 'white';
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                      <div style={{ fontWeight: '600', color: '#1e293b' }}>{vehicle.id}</div>
                      <span style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontWeight: '500' }} className={getStatusColor(vehicle.status)}>
                        {vehicle.status}
                      </span>
                    </div>
                    <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>Driver: {vehicle.driver}</div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: '#64748b' }}>
                      <span>⚡ {vehicle.speed} km/h</span>
                      <span>⛽ {vehicle.fuel}%</span>
                      <span>📍 {vehicle.nextStop}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Map Overview Panel */}
            <div style={{ background: 'white', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ padding: '1.5rem', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1e293b', margin: 0 }}>🗺️ Fleet Overview</h2>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <span style={{ background: '#10b981', color: 'white', fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px' }}>LIVE</span>
                  <span style={{ background: '#3b82f6', color: 'white', fontSize: '0.75rem', padding: '0.25rem 0.5rem', borderRadius: '9999px' }}>GPS ACTIVE</span>
                </div>
              </div>
              <div style={{ height: '600px', position: 'relative' }}>
                <div 
                  ref={mapRef} 
                  style={{ 
                    height: '100%', 
                    borderRadius: '0 0 0.75rem 0.75rem',
                    background: '#f8fafc',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.125rem',
                    color: '#64748b'
                  }}
                >
                  {!mapLoaded && '🗺️ Loading Fleet Map...'}
                </div>
                {selectedVehicle && (
                  <div style={{ position: 'absolute', top: '1rem', right: '1rem', background: 'white', padding: '1rem', borderRadius: '0.5rem', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
                    <h3 style={{ fontSize: '1rem', fontWeight: '600', color: '#1e293b', margin: '0 0 0.5rem 0' }}>{selectedVehicle.id}</h3>
                    <div style={{ fontSize: '0.875rem', color: '#64748b' }}>
                      <div>Driver: {selectedVehicle.driver}</div>
                      <div>Status: {selectedVehicle.status}</div>
                      <div>Speed: {selectedVehicle.speed} km/h</div>
                      <div>Fuel: {selectedVehicle.fuel}%</div>
                    </div>
                    <button
                      onClick={() => openDetailedMap(selectedVehicle)}
                      style={{ marginTop: '0.5rem', width: '100%', padding: '0.5rem', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '0.375rem', cursor: 'pointer', fontSize: '0.875rem' }}
                    >
                      🗺️ Track Vehicle
                    </button>
                    <button
                      onClick={() => {
                        console.log('Starting QAOA optimization for vehicle:', selectedVehicle);
                        // Create route optimization
                        const optimizedStops = ['Warehouse', 'Distribution Center', 'Nalla Narasimha Reddy College', 'Vanasthalipuram'];
                        const params = new URLSearchParams({
                          driver: selectedVehicle.driver,
                          vehicle: selectedVehicle.id,
                          start: 'Hyderabad Central',
                          destination: 'Vanasthalipuram',
                          stops: optimizedStops.join(','),
                          status: 'optimizing',
                          optimization: 'qaoa'
                        });
                        
                        const gpsMapUrl = `file:///C:/Users/Abhi/Desktop/JEEVAN%20JAVA/intelligent_fleet_routing_platform_structure/DETAILED_GPS_MAP.html?${params.toString()}`;
                        console.log('Opening optimized GPS map URL:', gpsMapUrl);
                        window.open(gpsMapUrl, '_blank', 'width=1400,height=900');
                      }}
                      style={{ marginTop: '0.5rem', width: '100%', padding: '0.5rem', background: '#10b981', color: 'white', border: 'none', borderRadius: '0.375rem', cursor: 'pointer', fontSize: '0.875rem' }}
                    >
                      ⚛️ Optimize Route
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
