import Head from 'next/head';
import { useState, useEffect } from 'react';
import { 
  CpuChipIcon, 
  BeakerIcon,
  ChartBarIcon,
  PlayIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline';
import { Layout } from '../../components/Layout';

export default function QuantumOptimization() {
  const [optimization, setOptimization] = useState(null);
  const [isRunning, setIsRunning] = useState(false);
  const [quantumResults, setQuantumResults] = useState({
    classicalTime: 180, // seconds
    quantumTime: 45, // seconds
    improvement: 75, // percentage
    qubits: 8,
    iterations: 1000
  });

  const runQuantumOptimization = async () => {
    setIsRunning(true);
    
    // Simulate QAOA quantum optimization
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const results = {
      algorithm: 'QAOA (Quantum Approximate Optimization Algorithm)',
      qubitsUsed: 8,
      classicalTime: '3 minutes',
      quantumTime: '45 seconds',
      improvement: '75% faster',
      routes: [
        {
          vehicle: 'Bike - MH12 AB 1234',
          driver: 'Raj Kumar',
          optimizedRoute: ['Depot', 'Customer A', 'Customer C', 'Customer B', 'Depot'],
          distance: '12.5 km',
          time: '45 mins',
          quantumScore: 0.92
        },
        {
          vehicle: 'Van - MH12 CD 5678', 
          driver: 'Sarah Johnson',
          optimizedRoute: ['Depot', 'Customer D', 'Customer E', 'Customer F', 'Depot'],
          distance: '18.3 km',
          time: '67 mins',
          quantumScore: 0.89
        }
      ],
      savings: {
        distance: '35%',
        time: '50%',
        fuel: '28%',
        cost: '₹1,250/day'
      }
    };
    
    setOptimization(results);
    setIsRunning(false);
  };

  return (
    <>
      <Head>
        <title>Quantum Route Optimization - FleetRoute AI</title>
      </Head>

      <Layout user={{ id: "1", name: "Quantum Optimizer", email: "quantum@fleetai.com", role: "quantum_optimizer", organization: "FleetRoute AI" }}>
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">🚀 Quantum Route Optimization</h1>
          <p className="text-gray-600 mt-2">QAOA optimization through quantum computing using classical tools</p>
        </div>

        {/* Quantum Computing Status */}
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg p-6 mb-8 text-white">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold">8</div>
              <div className="text-sm opacity-90">Qubits Used</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">1000</div>
              <div className="text-sm opacity-90">Iterations</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">75%</div>
              <div className="text-sm opacity-90">Faster</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">0.92</div>
              <div className="text-sm opacity-90">Quantum Score</div>
            </div>
          </div>
        </div>

        {/* Optimization Control */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">⚛️ Quantum Optimization Engine</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="border-2 border-gray-200 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                <CpuChipIcon className="h-5 w-5 mr-2 text-blue-600" />
                Classical Computing
              </h3>
              <div className="space-y-2 text-sm">
                <div>• Brute force approach</div>
                <div>• 180 seconds processing time</div>
                <div>• Limited to local optimum</div>
                <div>• High computational cost</div>
              </div>
            </div>
            
            <div className="border-2 border-purple-200 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                <BeakerIcon className="h-5 w-5 mr-2 text-purple-600" />
                Quantum Computing (QAOA)
              </h3>
              <div className="space-y-2 text-sm">
                <div>• Quantum approximate optimization</div>
                <div>• 45 seconds processing time</div>
                <div>• Global optimum approximation</div>
                <div>• 75% faster processing</div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <button
              onClick={runQuantumOptimization}
              disabled={isRunning}
              className="bg-purple-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-purple-700 disabled:opacity-50 flex items-center"
            >
              {isRunning ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                  Running Quantum Optimization...
                </>
              ) : (
                <>
                  <PlayIcon className="h-5 w-5 mr-2" />
                  Run QAOA Optimization
                </>
              )}
            </button>
          </div>
        </div>

        {/* Optimization Results */}
        {optimization && (
          <div className="bg-white rounded-lg shadow p-6 mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">🎯 Quantum Optimization Results</h2>
            
            {/* Performance Comparison */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="text-2xl font-bold text-blue-600">3 min</div>
                <div className="text-sm text-gray-600">Classical Time</div>
              </div>
              <div className="bg-purple-50 rounded-lg p-4">
                <div className="text-2xl font-bold text-purple-600">45 sec</div>
                <div className="text-sm text-gray-600">Quantum Time</div>
              </div>
              <div className="bg-green-50 rounded-lg p-4">
                <div className="text-2xl font-bold text-green-600">75%</div>
                <div className="text-sm text-gray-600">Time Reduction</div>
              </div>
            </div>

            {/* Optimized Routes */}
            <div className="border-2 border-green-200 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                <ArrowPathIcon className="h-5 w-5 mr-2 text-green-600" />
                Optimized Delivery Routes
              </h3>
              
              <div className="space-y-4">
                {optimization.routes.map((route, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">{route.vehicle}</h4>
                      <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-sm">
                        Quantum Score: {route.quantumScore}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-gray-600">Route:</div>
                        <div className="font-medium">{route.optimizedRoute.join(' → ')}</div>
                      </div>
                      <div>
                        <div className="text-gray-600">Performance:</div>
                        <div className="font-medium">{route.distance} • {route.time}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Savings Summary */}
            <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-4 mt-6">
              <h3 className="font-semibold text-gray-900 mb-3">💰 Quantum Optimization Savings</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-gray-600">Distance</div>
                  <div className="font-bold text-green-600">{optimization.savings.distance}</div>
                </div>
                <div>
                  <div className="text-gray-600">Time</div>
                  <div className="font-bold text-green-600">{optimization.savings.time}</div>
                </div>
                <div>
                  <div className="text-gray-600">Fuel</div>
                  <div className="font-bold text-green-600">{optimization.savings.fuel}</div>
                </div>
                <div>
                  <div className="text-gray-600">Cost</div>
                  <div className="font-bold text-green-600">{optimization.savings.cost}</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Live Map Integration */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">🗺️ Live GPS Tracking</h2>
          <div className="h-96 bg-gray-100 rounded-lg flex items-center justify-center border-2 border-gray-300">
            <div className="text-center">
              <div className="mb-4">
                <div className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg">
                  <span className="font-medium">⚛️ Quantum GPS Active</span>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="bg-white p-3 rounded-lg border">
                  <div className="text-blue-600 font-bold">🏢 Depot</div>
                  <div className="text-gray-600">Mumbai Central</div>
                  <div className="text-gray-500">19.0760°N, 72.8777°E</div>
                </div>
                <div className="bg-white p-3 rounded-lg border">
                  <div className="text-green-600 font-bold">🚚 Vehicle 1</div>
                  <div className="text-gray-600">Optimized Route</div>
                  <div className="text-gray-500">19.1196°N, 72.8465°E</div>
                </div>
                <div className="bg-white p-3 rounded-lg border">
                  <div className="text-purple-600 font-bold">🚚 Vehicle 2</div>
                  <div className="text-gray-600">Quantum Route</div>
                  <div className="text-gray-500">19.0596°N, 72.8295°E</div>
                </div>
              </div>
              <div className="mt-4 text-purple-600 font-medium">
                ✅ Quantum-optimized routes • 35% distance reduction • Real-time tracking
              </div>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
}
