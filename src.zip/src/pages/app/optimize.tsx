import Head from 'next/head';
import { useState, useEffect } from 'react';
import { PlayIcon, CogIcon, ChartBarIcon } from '@heroicons/react/24/outline';
import { Layout } from '../../components/Layout';

export default function Optimize() {
  const [vehicles, setVehicles] = useState([
    { id: 'TRK-001', name: 'Truck 001', driver: 'Raj Kumar', status: 'active', location: { lat: 19.0760, lng: 72.8777 } },
    { id: 'TRK-002', name: 'Truck 002', driver: 'Sarah Johnson', status: 'active', location: { lat: 19.0860, lng: 72.8877 } },
    { id: 'TRK-003', name: 'Truck 003', driver: 'Mike Chen', status: 'maintenance', location: { lat: 19.0660, lng: 72.8677 } }
  ]);
  const [orders, setOrders] = useState([
    {
      id: 'ORD-1234',
      customer: 'Mumbai Electronics',
      pickup: 'Warehouse A',
      delivery: 'Mumbai, Maharashtra',
      status: 'pending',
      priority: 'high'
    },
    {
      id: 'ORD-1235',
      customer: 'Pune Logistics',
      pickup: 'Warehouse B',
      delivery: 'Pune, Maharashtra',
      status: 'pending',
      priority: 'medium'
    }
  ]);
  const [optimization, setOptimization] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Load data in background without blocking UI
    const timer = setTimeout(() => {
      fetchData();
    }, 200);

    return () => clearTimeout(timer);
  }, []);

  const fetchData = async () => {
    try {
      const [vehiclesRes, ordersRes] = await Promise.all([
        fetch('http://localhost:8000/api/fleet/vehicles'),
        fetch('http://localhost:8000/api/orders')
      ]);
      setVehicles(await vehiclesRes.json());
      setOrders(await ordersRes.json());
    } catch (error) {
      console.log('Using mock optimization data');
    }
  };

  const runOptimization = async (type: string) => {
    setLoading(true);
    try {
      const response = await fetch('http://localhost:8000/api/optimize/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type,
          vehicles: vehicles.map((v: any) => v.id),
          orders: orders.map((o: any) => o.id)
        })
      });
      const result = await response.json();
      setOptimization(result);
    } catch (error) {
      console.error('Optimization failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Head>
        <title>Route Optimization - FleetRoute AI</title>
      </Head>

      <Layout user={{ id: "1", name: "John Doe", email: "john@example.com", role: "dispatcher", organization: "Demo Fleet" }}>
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Route Optimization</h1>
          <p className="text-gray-600">Optimize your fleet routes using quantum-inspired algorithms</p>
        </div>

        {/* Optimization Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Optimization Settings</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-md font-medium text-gray-900 mb-3">Available Vehicles</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {vehicles.map((vehicle: any) => (
                      <div key={vehicle.id} className="border border-gray-200 rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{vehicle.id}</span>
                          <span className={`px-2 py-1 text-xs ${
                            vehicle.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {vehicle.status}
                          </span>
                        </div>
                        <div className="text-sm text-gray-500">{vehicle.driver}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-md font-medium text-gray-900 mb-3">Pending Orders</h3>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {orders.filter((o: any) => o.status === 'pending').map((order: any) => (
                      <div key={order.id} className="border border-gray-200 rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{order.id}</span>
                          <span className="px-2 py-1 text-xs bg-yellow-100 text-yellow-800">
                            {order.priority}
                          </span>
                        </div>
                        <div className="text-sm text-gray-500">{order.customer}</div>
                        <div className="text-sm text-gray-500">{order.pickup} → {order.delivery}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-4">
                  <button
                    onClick={() => runOptimization('classical')}
                    disabled={loading}
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 disabled:opacity-50"
                  >
                    <CogIcon className="h-5 w-5 mr-2" />
                    {loading ? 'Running...' : 'Classical Optimization'}
                  </button>
                  <button
                    onClick={() => runOptimization('hybrid')}
                    disabled={loading}
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-success-600 hover:bg-success-700 disabled:opacity-50"
                  >
                    <PlayIcon className="h-5 w-5 mr-2" />
                    {loading ? 'Running...' : 'Hybrid Quantum Optimization'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Optimization Results</h2>
              
              {optimization ? (
                <div className="space-y-4">
                  <div>
                    <div className="text-sm text-gray-500">Run ID</div>
                    <div className="font-medium">{optimization.run_id}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Status</div>
                    <div className="font-medium text-green-600">{optimization.status}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Algorithm</div>
                    <div className="font-medium capitalize">{optimization.type}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Routes Generated</div>
                    <div className="font-medium">{optimization.routes?.length || 0}</div>
                  </div>
                  
                  {optimization.savings && (
                    <div className="border-t pt-4">
                      <h3 className="font-medium text-gray-900 mb-2">Savings</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Distance</span>
                          <span className="text-sm font-medium text-green-600">
                            -{optimization.savings.distance_reduction}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Time</span>
                          <span className="text-sm font-medium text-green-600">
                            -{optimization.savings.time_reduction}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Cost</span>
                          <span className="text-sm font-medium text-green-600">
                            ₹{optimization.savings.cost_savings}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center text-gray-500 py-8">
                  <ChartBarIcon className="h-12 w-12 mx-auto mb-2" />
                  <p>Run an optimization to see results</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Routes Display */}
        {optimization?.routes && (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Optimized Routes</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {optimization.routes.map((route: any, index: number) => {
                // Safety check for route and stops
                const safeRoute = route || {};
                const safeStops = Array.isArray(safeRoute.stops) ? safeRoute.stops : [];
                
                return (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium">{safeRoute.vehicle_id || 'Unknown Vehicle'}</h3>
                    <span className="text-sm text-gray-500">{safeRoute.driver || 'Unknown Driver'}</span>
                  </div>
                  <div className="space-y-2">
                    {safeStops.map((stop: any, stopIndex: number) => (
                      <div key={stopIndex} className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-primary-600 rounded-full"></div>
                        <div className="text-sm">
                          <span className="font-medium">{stop.order_id}</span>
                          <span className="text-gray-500 ml-2">{stop.location}</span>
                          <span className="text-gray-400 ml-2">{stop.estimated_time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 pt-3 border-t text-sm text-gray-500">
                    Distance: {safeRoute.total_distance || '--'} km | Time: {safeRoute.estimated_time || '--'}
                  </div>
                </div>
                );
              })}
            </div>
          </div>
        )}
      </Layout>
    </>
  );
}
