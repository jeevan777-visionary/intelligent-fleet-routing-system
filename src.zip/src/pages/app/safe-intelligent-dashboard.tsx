import Head from 'next/head';
import { useState, useEffect, useRef } from 'react';
import { Layout } from '../../components/Layout';

declare global {
  interface Window {
    L: any;
    mapInstance: any;
  }
}

export default function SafeIntelligentDashboard() {
  const mapRef = useRef(null);
  const [isTracking, setIsTracking] = useState(false);
  const [currentRoute, setCurrentRoute] = useState(null);
  const [vehiclePosition, setVehiclePosition] = useState({ lat: 17.3850, lng: 78.4867 });
  const [deliveryStops, setDeliveryStops] = useState([]);
  const [optimizedRoute, setOptimizedRoute] = useState(null);
  const [routeStats, setRouteStats] = useState({ distance: 0, time: 0, completed: 0, remaining: 0 });
  const [mapLoaded, setMapLoaded] = useState(false);

  // Form states
  const [driverName, setDriverName] = useState('Raj Kumar');
  const [vehicleId, setVehicleId] = useState('MH12 AB 1234');
  const [startLocation, setStartLocation] = useState('Nalla Narasimha Reddy Education Society\'s Group of Institutions, CM23+774, Korremula Rd, Via Narapally, Peerzadiguda, Hyderabad, Majarguda, Telangana 500088');
  const [destination, setDestination] = useState('B 85 ,Phase-1, Sachivalaya Colony, Vanasthalipuram, Hyderabad, Telangana 500070');
  const [newStop, setNewStop] = useState('');

  useEffect(() => {
    // Load Leaflet scripts with safe approach
    const loadScripts = () => {
      // Check if already loaded
      if (window.L) {
        setMapLoaded(true);
        setTimeout(initializeMap, 100);
        return;
      }

      // Create a script tag with proper cross-origin handling
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.crossOrigin = 'anonymous';
      script.async = true;
      
      script.onload = () => {
        // Load CSS
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        document.head.appendChild(link);

        // Load routing machine
        const routingScript = document.createElement('script');
        routingScript.src = 'https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.js';
        routingScript.crossOrigin = 'anonymous';
        routingScript.async = true;
        
        routingScript.onload = () => {
          const routingCSS = document.createElement('link');
          routingCSS.rel = 'stylesheet';
          routingCSS.href = 'https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.css';
          document.head.appendChild(routingCSS);
          
          setMapLoaded(true);
          setTimeout(initializeMap, 200);
        };
        
        document.body.appendChild(routingScript);
      };
      
      script.onerror = () => {
        console.error('Failed to load Leaflet');
      };
      
      document.body.appendChild(script);
    };

    loadScripts();
  }, []);

  const initializeMap = () => {
    if (!window.L || !mapRef.current) return;

    try {
      // Initialize map with safe configuration
      const map = window.L.map(mapRef.current, {
        center: [17.3850, 78.4867],
        zoom: 14,
        zoomControl: true
      });

      window.mapInstance = map;

      // Add tile layer
      window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
      }).addTo(map);

      // Add vehicle marker
      const vehicleIcon = window.L.divIcon({
        html: '<div style="background: #34A853; color: white; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; font-size: 18px; border: 3px solid white; box-shadow: 0 4px 8px rgba(0,0,0,0.3);">🚚</div>',
        iconSize: [35, 35],
        className: 'vehicle-marker'
      });

      window.L.marker([vehiclePosition.lat, vehiclePosition.lng], { icon: vehicleIcon })
        .addTo(map)
        .bindPopup(`<b>Current Vehicle Position</b><br>Driver: ${driverName}<br>Vehicle: ${vehicleId}`);

      // Add depot marker
      const depotIcon = window.L.divIcon({
        html: '<div style="background: #4285F4; color: white; border-radius: 50%; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; font-size: 16px; border: 3px solid white;">🏢</div>',
        iconSize: [32, 32]
      });
      
      window.L.marker([17.3850, 78.4867], { icon: depotIcon })
        .addTo(map)
        .bindPopup('<b>Main Depot</b><br>Hyderabad Central');

    } catch (error) {
      console.error('Error initializing map:', error);
    }
  };

  const startLiveTracking = () => {
    setIsTracking(true);
    
    // Open detailed GPS map in new window with proper parameters
    const params = new URLSearchParams({
      driver: driverName,
      vehicle: vehicleId,
      start: startLocation,
      destination: destination,
      stops: deliveryStops.join(',')
    });
    
    const gpsMapUrl = `file:///C:/Users/Abhi/Desktop/JEEVAN%20JAVA/intelligent_fleet_routing_platform_structure/DETAILED_GPS_MAP.html?${params.toString()}`;
    console.log('Opening GPS map with URL:', gpsMapUrl);
    window.open(gpsMapUrl, '_blank', 'width=1200,height=800');
  };

  const addDeliveryStop = () => {
    if (newStop.trim()) {
      setDeliveryStops([...deliveryStops, newStop.trim()]);
      setNewStop('');
    }
  };

  const removeDeliveryStop = (index) => {
    setDeliveryStops(deliveryStops.filter((_, i) => i !== index));
  };

  const runQAOAOptimization = () => {
    if (!startLocation || !destination) {
      alert('Please enter start location and destination');
      return;
    }

    // Simulate QAOA optimization
    const allStops = [startLocation, ...deliveryStops, destination];
    const optimizedStops = [...allStops]; // In real implementation, this would use QAOA algorithm
    
    setOptimizedRoute(optimizedStops);
    setRouteStats({
      distance: Math.random() * 20 + 10, // Random distance 10-30 km
      time: Math.random() * 60 + 30, // Random time 30-90 mins
      completed: 0,
      remaining: optimizedStops.length
    });

    // Update map with route
    updateMapWithRoute(optimizedStops);
  };

  const updateMapWithRoute = (stops) => {
    if (!window.L || !window.L.Routing || !window.mapInstance) return;

    try {
      const waypoints = stops.map(stop => {
        const coords = getCoordinatesForLocation(stop);
        return window.L.latLng(coords.lat, coords.lng);
      });

      // Clear existing route
      if (window.mapInstance.routeControl) {
        window.mapInstance.removeControl(window.mapInstance.routeControl);
      }

      const routeControl = window.L.Routing.control({
        waypoints: waypoints,
        routeWhileDragging: false,
        addWaypoints: false,
        createMarker: () => null,
        lineOptions: { 
          styles: [
            { color: '#4285F4', weight: 6, opacity: 0.8 },
            { color: 'white', weight: 8, opacity: 0.3 }
          ]
        }
      }).on('routesfound', (e) => {
        const routes = e.routes;
        const summary = routes[0].summary;
        
        setRouteStats(prev => ({
          ...prev,
          distance: parseFloat((summary.totalDistance / 1000).toFixed(1)),
          time: Math.round(summary.totalTime / 60)
        }));
      }).addTo(window.mapInstance);

      window.mapInstance.routeControl = routeControl;
    } catch (error) {
      console.error('Error updating map with route:', error);
    }
  };

  const getCoordinatesForLocation = (location) => {
    // Simplified coordinate mapping for Hyderabad locations
    const coords = {
      'nalla narasimha reddy': { lat: 17.3750, lng: 78.4767 },
      'vanasthalipuram': { lat: 17.4050, lng: 78.5067 },
      'hyderabad central': { lat: 17.3850, lng: 78.4867 },
      'banjara hills': { lat: 17.4177, lng: 78.4533 },
      'gachibowli': { lat: 17.4495, lng: 78.3810 },
      'hitec city': { lat: 17.4480, lng: 78.3780 },
      'madhapur': { lat: 17.4474, lng: 78.3786 }
    };

    const lowerLocation = location.toLowerCase();
    for (let place in coords) {
      if (lowerLocation.includes(place)) {
        return coords[place];
      }
    }

    // Default random coordinates around Hyderabad
    return {
      lat: 17.3850 + (Math.random() - 0.5) * 0.1,
      lng: 78.4867 + (Math.random() - 0.5) * 0.1
    };
  };

  const simulateVehicleMovement = () => {
    if (isTracking && optimizedRoute && optimizedRoute.length > 0) {
      // Simulate movement along route
      setVehiclePosition(prev => ({
        lat: prev.lat + (Math.random() - 0.5) * 0.001,
        lng: prev.lng + (Math.random() - 0.5) * 0.001
      }));

      // Update completed stops
      setRouteStats(prev => ({
        ...prev,
        completed: Math.min(prev.completed + 0.1, prev.remaining),
        remaining: Math.max(prev.remaining - 0.1, 0)
      }));
    }
  };

  useEffect(() => {
    // Simulate vehicle movement every 3 seconds
    const interval = setInterval(simulateVehicleMovement, 3000);
    return () => clearInterval(interval);
  }, [isTracking, optimizedRoute]);

  return (
    <>
      <Head>
        <title>FleetRoute AI - Safe Intelligent Dashboard</title>
        <style>{`
          @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
          }
          .tracking-active {
            animation: pulse 2s infinite;
            background: #10b981;
          }
          .vehicle-marker {
            z-index: 1000 !important;
          }
        `}</style>
      </Head>

      <Layout user={{ id: "1", name: "Fleet Manager", email: "manager@fleetai.com", role: "dispatcher", organization: "FleetRoute AI" }}>
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">🚀 FleetRoute AI - Safe Intelligent Dashboard</h1>
          <p className="text-gray-600 mt-2">Advanced Fleet Routing with QAOA Quantum Optimization (Cross-Origin Safe)</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Panel - Delivery Inputs */}
          <div className="lg:col-span-1 space-y-6">
            {/* Driver & Vehicle Info */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">👤 Driver & Vehicle</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Driver Name</label>
                  <input
                    type="text"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter driver name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle ID</label>
                  <input
                    type="text"
                    value={vehicleId}
                    onChange={(e) => setVehicleId(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter vehicle ID"
                  />
                </div>
              </div>
            </div>

            {/* Delivery Details */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">📍 Delivery Details</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Start Location</label>
                  <textarea
                    value={startLocation}
                    onChange={(e) => setStartLocation(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter start location"
                    rows={2}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Destination</label>
                  <textarea
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter destination"
                    rows={2}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Stops</label>
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={newStop}
                      onChange={(e) => setNewStop(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addDeliveryStop()}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="Add delivery stop"
                    />
                    <button
                      onClick={addDeliveryStop}
                      className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                    >
                      Add
                    </button>
                  </div>
                  {deliveryStops.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {deliveryStops.map((stop, index) => (
                        <div key={index} className="flex items-center justify-between bg-gray-50 px-3 py-2 rounded">
                          <span className="text-sm">{stop}</span>
                          <button
                            onClick={() => removeDeliveryStop(index)}
                            className="text-red-600 hover:text-red-800 text-sm"
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Start Tracking Button */}
            <button
              onClick={startLiveTracking}
              className={`w-full py-4 rounded-lg font-semibold text-white transition-all ${
                isTracking 
                  ? 'tracking-active' 
                  : 'bg-green-600 hover:bg-green-700'
              }`}
            >
              {isTracking ? '🛰️ Live Tracking Active' : '🚀 Start Live Routing'}
            </button>

            {/* Route Optimization */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">⚛️ QAOA Optimization</h2>
              <button
                onClick={runQAOAOptimization}
                className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 font-semibold"
              >
                🧬 Run Quantum Optimization
              </button>
              {optimizedRoute && (
                <div className="mt-4 p-3 bg-purple-50 rounded">
                  <div className="text-sm font-medium text-purple-800">✅ Route Optimized</div>
                  <div className="text-xs text-purple-600 mt-1">
                    {optimizedRoute.length} stops optimized using QAOA
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Main Panel - Interactive Map */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-gray-900">🗺️ Interactive GPS Map</h2>
                <div className="flex space-x-2">
                  {isTracking && (
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">LIVE</span>
                  )}
                  <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">GPS ACTIVE</span>
                  {!mapLoaded && (
                    <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">LOADING...</span>
                  )}
                </div>
              </div>
              
              <div 
                ref={mapRef} 
                className="h-96 rounded-lg border-2 border-gray-200 mb-4"
                style={{ minHeight: '400px' }}
              />

              {/* Route Information */}
              {optimizedRoute && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{routeStats.distance.toFixed(1)}</div>
                    <div className="text-sm text-gray-600">Total Distance (km)</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{routeStats.time.toFixed(0)}</div>
                    <div className="text-sm text-gray-600">Est. Time (mins)</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">{routeStats.completed.toFixed(0)}</div>
                    <div className="text-sm text-gray-600">Completed Stops</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">{routeStats.remaining.toFixed(0)}</div>
                    <div className="text-sm text-gray-600">Remaining Stops</div>
                  </div>
                </div>
              )}

              {/* Current Vehicle Position */}
              {isTracking && (
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-semibold text-gray-900 mb-2">🚚 Current Vehicle Position</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Latitude:</span>
                      <span className="font-mono font-semibold">{vehiclePosition.lat.toFixed(6)}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Longitude:</span>
                      <span className="font-mono font-semibold">{vehiclePosition.lng.toFixed(6)}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Driver:</span>
                      <span className="font-semibold">{driverName}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Vehicle:</span>
                      <span className="font-semibold">{vehicleId}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
}
