import Head from 'next/head';
import { useState, useEffect } from 'react';
import { Layout } from '../../components/Layout';

export default function FinalDashboard() {
  const [vehicles, setVehicles] = useState([
    { id: 'VH-001', type: 'Bike', plate: 'MH12 AB 1234', driver: 'Raj Kumar', status: 'active', lat: 19.0760, lng: 72.8777 },
    { id: 'VH-002', type: 'Van', plate: 'MH12 CD 5678', driver: 'Sarah Johnson', status: 'active', lat: 19.0860, lng: 72.8877 },
    { id: 'VH-003', type: 'Bike', plate: 'MH12 EF 9012', driver: 'Mike Chen', status: 'maintenance', lat: 19.0660, lng: 72.8677 }
  ]);

  const [quantumResults, setQuantumResults] = useState(null);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    // Simulate real-time GPS updates
    const interval = setInterval(() => {
      setVehicles(prev => prev.map(vehicle => ({
        ...vehicle,
        lat: vehicle.lat + (Math.random() - 0.5) * 0.001,
        lng: vehicle.lng + (Math.random() - 0.5) * 0.001
      })));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const runQuantumOptimization = async () => {
    setIsRunning(true);
    
    // Simulate QAOA quantum optimization
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setQuantumResults({
      algorithm: 'QAOA (Quantum Approximate Optimization Algorithm)',
      qubitsUsed: 8,
      classicalTime: '3 minutes (180 seconds)',
      quantumTime: '45 seconds',
      improvement: '75% faster',
      routes: [
        {
          vehicle: 'Bike - MH12 AB 1234',
          driver: 'Raj Kumar',
          optimizedRoute: ['Depot', 'Customer A', 'Customer C', 'Customer B', 'Depot'],
          distance: '12.5 km',
          time: '45 mins',
          quantumScore: 0.92
        }
      ],
      savings: {
        distance: '35%',
        time: '50%',
        fuel: '28%',
        cost: '₹1,250/day'
      }
    });
    
    setIsRunning(false);
  };

  return (
    <>
      <Head>
        <title>FleetRoute AI - Live Map & QAOA Optimization</title>
      </Head>

      <Layout user={{ id: "1", name: "Delivery Manager", email: "manager@fleetai.com", role: "dispatcher", organization: "FleetRoute AI" }}>
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">🚀 Live Fleet Management Dashboard</h1>
          <p className="text-gray-600 mt-2">Real-time GPS tracking with QAOA quantum optimization</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-green-600">1.5 Days</div>
            <div className="text-gray-600">Optimized Delivery Time</div>
            <div className="text-sm text-green-600">Was 3.0 days</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-blue-600">35%</div>
            <div className="text-gray-600">Distance Reduction</div>
            <div className="text-sm text-blue-600">Through QAOA</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-purple-600">75%</div>
            <div className="text-gray-600">Faster Processing</div>
            <div className="text-sm text-purple-600">Quantum vs Classical</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-2xl font-bold text-orange-600">₹1,250</div>
            <div className="text-gray-600">Daily Cost Savings</div>
            <div className="text-sm text-orange-600">After Optimization</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* LIVE GPS MAP */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">🗺️ LIVE GPS TRACKING MAP</h2>
            <div className="h-96 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg border-2 border-blue-300 relative overflow-hidden">
              {/* Animated Grid Background */}
              <div className="absolute inset-0 grid grid-cols-8 grid-rows-8 gap-1 opacity-20">
                {Array.from({ length: 64 }).map((_, i) => (
                  <div key={i} className={`bg-${i % 2 === 0 ? 'blue' : 'green'}-200 rounded`}></div>
                ))}
              </div>
              
              {/* Vehicle Positions */}
              {vehicles.map((vehicle, index) => {
                const x = ((vehicle.lng - 72.8660) * 100) + 50; // Map to grid
                const y = ((19.0760 - vehicle.lat) * 100) + 50;
                const isActive = vehicle.status === 'active';
                
                return (
                  <div
                    key={vehicle.id}
                    className={`absolute w-4 h-4 rounded-full transition-all duration-1000 ${
                      isActive ? 'bg-green-600 animate-pulse' : 'bg-yellow-600'
                    }`}
                    style={{
                      left: `${Math.max(0, Math.min(100, x))}%`,
                      top: `${Math.max(0, Math.min(100, y))}%`,
                      transform: 'translate(-50%, -50%)'
                    }}
                  >
                    <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-white rounded px-2 py-1 text-xs whitespace-nowrap shadow-lg">
                      <div className="font-bold">{vehicle.plate}</div>
                      <div className="text-gray-600">{vehicle.driver}</div>
                      <div className={`text-xs ${isActive ? 'text-green-600' : 'text-yellow-600'}`}>
                        {isActive ? '🚚 Active' : '🔧 Maintenance'}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Depot */}
              <div className="absolute w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center" style={{ left: '46%', top: '46%' }}>
                <span className="text-white text-xs font-bold">🏢</span>
              </div>

              {/* Map Legend */}
              <div className="absolute bottom-4 left-4 bg-white rounded-lg p-3 shadow-lg">
                <div className="text-xs font-semibold text-gray-900 mb-2">🗺️ LIVE GPS STATUS</div>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-600 rounded-full animate-pulse"></div>
                    <span className="text-xs">Active Vehicle</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-yellow-600 rounded-full"></div>
                    <span className="text-xs">Maintenance</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                    <span className="text-xs">Depot</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* QAOA QUANTUM OPTIMIZATION */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">⚛️ QAOA QUANTUM OPTIMIZATION</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="border-2 border-gray-200 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3">Classical Computing</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <div>• Brute force approach</div>
                  <div>• 180 seconds processing</div>
                  <div>• Limited to local optimum</div>
                  <div>• High computational cost</div>
                </div>
              </div>
              
              <div className="border-2 border-purple-200 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3">Quantum Computing (QAOA)</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <div>• Quantum approximate optimization</div>
                  <div>• 45 seconds processing</div>
                  <div>• Global optimum approximation</div>
                  <div>• 75% faster processing</div>
                </div>
              </div>
            </div>

            <div className="flex justify-center mb-6">
              <button
                onClick={runQuantumOptimization}
                disabled={isRunning}
                className="bg-purple-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-purple-700 disabled:opacity-50 flex items-center"
              >
                {isRunning ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                    Running QAOA Optimization...
                  </>
                ) : (
                  <>
                    ⚛️ Run QAOA Optimization
                  </>
                )}
              </button>
            </div>

            {quantumResults && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3">✅ Quantum Optimization Results</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="text-gray-600">Algorithm</div>
                    <div className="font-medium">{quantumResults.algorithm}</div>
                  </div>
                  <div>
                    <div className="text-gray-600">Qubits Used</div>
                    <div className="font-medium">{quantumResults.qubitsUsed}</div>
                  </div>
                  <div>
                    <div className="text-gray-600">Time Improvement</div>
                    <div className="font-medium text-green-600">{quantumResults.improvement}</div>
                  </div>
                  <div>
                    <div className="text-gray-600">Processing Time</div>
                    <div className="font-medium">{quantumResults.quantumTime}</div>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t">
                  <h4 className="font-semibold text-gray-900 mb-2">💰 Cost Savings</h4>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <div className="text-gray-600">Distance</div>
                      <div className="font-medium text-green-600">{quantumResults.savings.distance}</div>
                    </div>
                    <div>
                      <div className="text-gray-600">Time</div>
                      <div className="font-medium text-green-600">{quantumResults.savings.time}</div>
                    </div>
                    <div>
                      <div className="text-gray-600">Cost</div>
                      <div className="font-medium text-green-600">{quantumResults.savings.cost}</div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Real-time Updates */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">📊 Real-time Performance</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-blue-600">{vehicles.filter(v => v.status === 'active').length}</div>
              <div className="text-gray-600">Active Vehicles</div>
              <div className="text-sm text-blue-600">Real-time GPS tracking</div>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-green-600">1.5 Days</div>
              <div className="text-gray-600">Avg Delivery Time</div>
              <div className="text-sm text-green-600">After QAOA optimization</div>
            </div>
            <div className="bg-purple-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-purple-600">75%</div>
              <div className="text-gray-600">Efficiency Improvement</div>
              <div className="text-sm text-purple-600">Quantum advantage</div>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
}
