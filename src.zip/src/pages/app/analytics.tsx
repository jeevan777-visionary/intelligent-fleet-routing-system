import Head from 'next/head';
import { useState, useEffect } from 'react';
import { ChartBarIcon, ArrowTrendingUpIcon, CurrencyDollarIcon, TruckIcon } from '@heroicons/react/24/outline';
import { Layout } from '../../components/Layout';

export default function Analytics() {
  const [analytics, setAnalytics] = useState({
    totalRevenue: 1250000,
    totalDeliveries: 1247,
    averageDeliveryTime: 2.5,
    fuelCosts: 245000,
    efficiency: 87,
    customerSatisfaction: 94
  });

  return (
    <>
      <Head>
        <title>Analytics - FleetRoute AI</title>
      </Head>

      <Layout user={{ id: "1", name: "John Doe", email: "john@example.com", role: "dispatcher", organization: "Demo Fleet" }}>
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
          <p className="text-gray-600">Detailed insights into your fleet performance</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary-100 rounded-lg p-3">
                <CurrencyDollarIcon className="h-6 w-6 text-primary-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Total Revenue</dt>
                  <dd className="text-lg font-medium text-gray-900">₹{analytics.totalRevenue.toLocaleString()}</dd>
                </dl>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-success-100 rounded-lg p-3">
                <TruckIcon className="h-6 w-6 text-success-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Total Deliveries</dt>
                  <dd className="text-lg font-medium text-gray-900">{analytics.totalDeliveries}</dd>
                </dl>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-info-100 rounded-lg p-3">
                <ArrowTrendingUpIcon className="h-6 w-6 text-info-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Avg Delivery Time</dt>
                  <dd className="text-lg font-medium text-gray-900">{analytics.averageDeliveryTime} hrs</dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Revenue Trend</h2>
            <div className="h-64 flex items-center justify-center bg-gray-50 rounded">
              <div className="text-gray-500 text-center">
                <ChartBarIcon className="h-12 w-12 mx-auto mb-2" />
                <p>Revenue chart visualization</p>
                <p className="text-sm">Chart integration would go here</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Delivery Performance</h2>
            <div className="h-64 flex items-center justify-center bg-gray-50 rounded">
              <div className="text-gray-500 text-center">
                <ArrowTrendingUpIcon className="h-12 w-12 mx-auto mb-2" />
                <p>Performance metrics chart</p>
                <p className="text-sm">Chart integration would go here</p>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Metrics */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Performance Metrics</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="border-l-4 border-primary-500 pl-4">
                <div className="text-sm text-gray-500">Fuel Efficiency</div>
                <div className="text-2xl font-bold text-gray-900">{analytics.efficiency}%</div>
                <div className="text-sm text-green-600">+3% from last month</div>
              </div>
              <div className="border-l-4 border-success-500 pl-4">
                <div className="text-sm text-gray-500">Customer Satisfaction</div>
                <div className="text-2xl font-bold text-gray-900">{analytics.customerSatisfaction}%</div>
                <div className="text-sm text-green-600">+2% from last month</div>
              </div>
              <div className="border-l-4 border-warning-500 pl-4">
                <div className="text-sm text-gray-500">Fuel Costs</div>
                <div className="text-2xl font-bold text-gray-900">₹{analytics.fuelCosts.toLocaleString()}</div>
                <div className="text-sm text-red-600">+5% from last month</div>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Reports */}
        <div className="mt-8 bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Reports</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
                <div>
                  <h3 className="font-medium text-gray-900">Monthly Performance Report</h3>
                  <p className="text-sm text-gray-500">Generated on March 1, 2026</p>
                </div>
                <button className="text-primary-600 hover:text-primary-900 font-medium">Download</button>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
                <div>
                  <h3 className="font-medium text-gray-900">Fuel Efficiency Analysis</h3>
                  <p className="text-sm text-gray-500">Generated on February 28, 2026</p>
                </div>
                <button className="text-primary-600 hover:text-primary-900 font-medium">Download</button>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
                <div>
                  <h3 className="font-medium text-gray-900">Customer Satisfaction Survey</h3>
                  <p className="text-sm text-gray-500">Generated on February 25, 2026</p>
                </div>
                <button className="text-primary-600 hover:text-primary-900 font-medium">Download</button>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
}
