import Head from 'next/head';
import { useState, useEffect } from 'react';

export default function AnalyticsDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState('week');
  const [analyticsData, setAnalyticsData] = useState({
    overview: {
      totalDeliveries: 1247,
      totalDistance: 15678.5,
      totalFuel: 1254.8,
      avgDeliveryTime: 42.3,
      onTimeRate: 94.5,
      customerSatisfaction: 4.7
    },
    performance: {
      daily: [
        { day: 'Mon', deliveries: 45, distance: 567.8, fuel: 45.2 },
        { day: 'Tue', deliveries: 52, distance: 623.4, fuel: 49.8 },
        { day: 'Wed', deliveries: 48, distance: 589.1, fuel: 47.3 },
        { day: 'Thu', deliveries: 61, distance: 734.2, fuel: 58.7 },
        { day: 'Fri', deliveries: 58, distance: 698.9, fuel: 56.1 },
        { day: 'Sat', deliveries: 35, distance: 423.7, fuel: 34.1 },
        { day: 'Sun', deliveries: 28, distance: 345.6, fuel: 27.8 }
      ],
      monthly: [
        { month: 'Jan', deliveries: 1247, distance: 15678.5, fuel: 1254.8 },
        { month: 'Feb', deliveries: 1189, distance: 14892.3, fuel: 1192.1 },
        { month: 'Mar', deliveries: 1356, distance: 16987.4, fuel: 1358.9 }
      ]
    },
    topPerformers: [
      { driver: 'Sameer Khan', deliveries: 1567, rating: 4.9, efficiency: 12.5 },
      { driver: 'Raj Kumar', deliveries: 1247, rating: 4.7, efficiency: 11.8 },
      { driver: 'Ravi Kumar', deliveries: 1103, rating: 4.8, efficiency: 12.1 },
      { driver: 'Arun Singh', deliveries: 892, rating: 4.6, efficiency: 11.2 },
      { driver: 'Priya Sharma', deliveries: 456, rating: 4.5, efficiency: 10.9 }
    ],
    vehiclePerformance: [
      { vehicle: 'TRK-102', utilization: 78, efficiency: 12.1, maintenance: 'Good' },
      { vehicle: 'TRK-221', utilization: 65, efficiency: 11.8, maintenance: 'Good' },
      { vehicle: 'TRK-340', utilization: 92, efficiency: 12.5, maintenance: 'Excellent' },
      { vehicle: 'TRK-451', utilization: 71, efficiency: 11.9, maintenance: 'Fair' },
      { vehicle: 'TRK-562', utilization: 45, efficiency: 10.9, maintenance: 'Needs Service' }
    ]
  });

  const getPerformanceColor = (value, type) => {
    if (type === 'rating') {
      if (value >= 4.5) return '#10b981';
      if (value >= 4.0) return '#3b82f6';
      if (value >= 3.5) return '#f59e0b';
      return '#ef4444';
    }
    if (type === 'efficiency') {
      if (value >= 12.0) return '#10b981';
      if (value >= 11.0) return '#3b82f6';
      if (value >= 10.0) return '#f59e0b';
      return '#ef4444';
    }
    if (type === 'utilization') {
      if (value >= 75) return '#10b981';
      if (value >= 60) return '#3b82f6';
      if (value >= 45) return '#f59e0b';
      return '#ef4444';
    }
    return '#64748b';
  };

  const getMaintenanceColor = (status) => {
    switch(status) {
      case 'Excellent': return '#10b981';
      case 'Good': return '#3b82f6';
      case 'Fair': return '#f59e0b';
      case 'Needs Service': return '#ef4444';
      default: return '#64748b';
    }
  };

  const renderBarChart = (data, metric) => {
    const maxValue = Math.max(...data.map(d => d[metric]));
    
    return (
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: '0.5rem', height: '200px' }}>
        {data.map((item, index) => (
          <div key={index} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ 
              width: '100%', 
              background: '#3b82f6', 
              borderRadius: '4px 4px 0 0',
              height: `${(item[metric] / maxValue) * 180}px`,
              transition: 'height 0.3s ease'
            }}></div>
            <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.5rem', textAlign: 'center' }}>
              {metric === 'day' ? item.day.substring(0, 3) : item.month}
            </div>
            <div style={{ fontSize: '0.75rem', fontWeight: '500', color: '#1e293b' }}>
              {item[metric]}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <>
      <Head>
        <title>Analytics Dashboard - FleetRoute AI</title>
      </Head>

      <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
        {/* Header Navigation */}
        <header style={{ background: 'white', borderBottom: '1px solid #e2e8f0', padding: '1rem 2rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
              <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>🚛 FleetRoute AI</h1>
              <nav style={{ display: 'flex', gap: '1rem' }}>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Dashboard</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Fleet</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Drivers</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Routes</a>
                <a href="#" style={{ textDecoration: 'none', color: '#3b82f6', padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#eff6ff', fontWeight: '500' }}>Analytics</a>
                <a href="#" style={{ textDecoration: 'none', color: '#64748b', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>Settings</a>
              </nav>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <button style={{ background: '#f1f5f9', border: 'none', padding: '0.5rem', borderRadius: '0.5rem', cursor: 'pointer' }}>🔔</button>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{ width: '32px', height: '32px', background: '#3b82f6', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 'bold' }}>D</div>
                <span style={{ fontSize: '0.875rem', color: '#64748b' }}>dispatcher</span>
              </div>
            </div>
          </div>
        </header>

        <div style={{ padding: '2rem', maxWidth: '1600px', margin: '0 auto' }}>
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
            <div>
              <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b', marginBottom: '0.5rem' }}>📊 Analytics Dashboard</h1>
              <p style={{ color: '#64748b', fontSize: '1.125rem' }}>Comprehensive insights into your fleet performance and operations</p>
            </div>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              {['day', 'week', 'month', 'year'].map((period) => (
                <button
                  key={period}
                  onClick={() => setSelectedPeriod(period)}
                  style={{
                    padding: '0.5rem 1rem',
                    background: selectedPeriod === period ? '#3b82f6' : 'white',
                    color: selectedPeriod === period ? 'white' : '#64748b',
                    border: selectedPeriod === period ? 'none' : '1px solid #e2e8f0',
                    borderRadius: '0.5rem',
                    cursor: 'pointer',
                    fontWeight: '500'
                  }}
                >
                  {period.charAt(0).toUpperCase() + period.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Overview Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{analyticsData.overview.totalDeliveries.toLocaleString()}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Total Deliveries</div>
              <div style={{ fontSize: '0.75rem', color: '#10b981', marginTop: '0.25rem' }}>↑ 12.5% vs last period</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{analyticsData.overview.totalDistance.toLocaleString()}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Distance (km)</div>
              <div style={{ fontSize: '0.75rem', color: '#10b981', marginTop: '0.25rem' }}>↑ 8.3% vs last period</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{analyticsData.overview.totalFuel.toLocaleString()}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Fuel (L)</div>
              <div style={{ fontSize: '0.75rem', color: '#ef4444', marginTop: '0.25rem' }}>↑ 5.2% vs last period</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{analyticsData.overview.avgDeliveryTime}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Avg Time (min)</div>
              <div style={{ fontSize: '0.75rem', color: '#10b981', marginTop: '0.25rem' }}>↓ 3.1% vs last period</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{analyticsData.overview.onTimeRate}%</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>On-Time Rate</div>
              <div style={{ fontSize: '0.75rem', color: '#10b981', marginTop: '0.25rem' }}>↑ 2.4% vs last period</div>
            </div>
            <div style={{ background: 'white', padding: '1.5rem', borderRadius: '0.75rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e293b' }}>{analyticsData.overview.customerSatisfaction}</div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Satisfaction</div>
              <div style={{ fontSize: '0.75rem', color: '#10b981', marginTop: '0.25rem' }}>↑ 0.3 vs last period</div>
            </div>
          </div>

          {/* Performance Charts */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem', marginBottom: '2rem' }}>
            {/* Daily Performance Chart */}
            <div style={{ background: 'white', borderRadius: '0.75rem', padding: '1.5rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1e293b', marginBottom: '1rem' }}>📈 Daily Performance</h3>
              <div style={{ marginBottom: '1rem' }}>
                <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.5rem' }}>Daily Deliveries</div>
                {renderBarChart(analyticsData.performance.daily, 'deliveries')}
              </div>
              <div>
                <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.5rem' }}>Daily Distance (km)</div>
                {renderBarChart(analyticsData.performance.daily, 'distance')}
              </div>
            </div>

            {/* Top Performers */}
            <div style={{ background: 'white', borderRadius: '0.75rem', padding: '1.5rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1e293b', marginBottom: '1rem' }}>🏆 Top Performers</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {analyticsData.topPerformers.map((driver, index) => (
                  <div key={index} style={{ 
                    padding: '1rem', 
                    background: '#f8fafc', 
                    borderRadius: '0.5rem',
                    border: '1px solid #e2e8f0'
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                      <div style={{ fontWeight: '600', color: '#1e293b' }}>{driver.driver}</div>
                      <div style={{ fontSize: '0.875rem', color: '#64748b' }}>#{index + 1}</div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', fontSize: '0.875rem' }}>
                      <div>
                        <span style={{ color: '#64748b' }}>Deliveries:</span>
                        <span style={{ fontWeight: '500', color: '#1e293b', marginLeft: '0.25rem' }}>{driver.deliveries}</span>
                      </div>
                      <div>
                        <span style={{ color: '#64748b' }}>Rating:</span>
                        <span style={{ fontWeight: '500', color: getPerformanceColor(driver.rating, 'rating'), marginLeft: '0.25rem' }}>{driver.rating}</span>
                      </div>
                      <div style={{ gridColumn: '1 / -1' }}>
                        <span style={{ color: '#64748b' }}>Efficiency:</span>
                        <span style={{ fontWeight: '500', color: getPerformanceColor(driver.efficiency, 'efficiency'), marginLeft: '0.25rem' }}>{driver.efficiency} km/L</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Vehicle Performance */}
          <div style={{ background: 'white', borderRadius: '0.75rem', padding: '1.5rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1e293b', marginBottom: '1rem' }}>🚛 Vehicle Performance Analysis</h3>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: '#f8fafc' }}>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Vehicle</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Utilization</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Fuel Efficiency</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Maintenance Status</th>
                    <th style={{ padding: '1rem', textAlign: 'left', fontSize: '0.875rem', fontWeight: '600', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>Performance Score</th>
                  </tr>
                </thead>
                <tbody>
                  {analyticsData.vehiclePerformance.map((vehicle, index) => (
                    <tr key={index} style={{ borderBottom: '1px solid #f1f5f9' }}>
                      <td style={{ padding: '1rem', fontWeight: '600', color: '#1e293b' }}>{vehicle.vehicle}</td>
                      <td style={{ padding: '1rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                          <div style={{ width: '60px', height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                            <div style={{ 
                              width: `${vehicle.utilization}%`, 
                              height: '100%', 
                              background: getPerformanceColor(vehicle.utilization, 'utilization')
                            }}></div>
                          </div>
                          <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#1e293b' }}>{vehicle.utilization}%</span>
                        </div>
                      </td>
                      <td style={{ padding: '1rem' }}>
                        <span style={{ fontSize: '0.875rem', fontWeight: '500', color: getPerformanceColor(vehicle.efficiency, 'efficiency') }}>
                          {vehicle.efficiency} km/L
                        </span>
                      </td>
                      <td style={{ padding: '1rem' }}>
                        <span style={{ 
                          fontSize: '0.75rem', 
                          padding: '0.25rem 0.5rem', 
                          borderRadius: '9999px', 
                          fontWeight: '500',
                          color: getMaintenanceColor(vehicle.maintenance),
                          background: getMaintenanceColor(vehicle.maintenance) + '20'
                        }}>
                          {vehicle.maintenance}
                        </span>
                      </td>
                      <td style={{ padding: '1rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                          <div style={{ fontSize: '1.25rem', fontWeight: 'bold', color: '#1e293b' }}>
                            {Math.round((vehicle.utilization + vehicle.efficiency * 10) / 2)}
                          </div>
                          <div style={{ fontSize: '0.75rem', color: '#64748b' }}>/100</div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Export Options */}
          <div style={{ marginTop: '2rem', display: 'flex', justifyContent: 'center', gap: '1rem' }}>
            <button style={{ padding: '0.75rem 1.5rem', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
              📊 Generate Report
            </button>
            <button style={{ padding: '0.75rem 1.5rem', background: '#10b981', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
              📥 Export CSV
            </button>
            <button style={{ padding: '0.75rem 1.5rem', background: '#f59e0b', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: '500' }}>
              📧 Email Report
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
