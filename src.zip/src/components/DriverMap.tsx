'use client'

import { useEffect, useRef, useState } from 'react'
import dynamic from 'next/dynamic'
import { MapPinIcon, ArrowRightIcon, ClockIcon, CurrencyDollarIcon } from '@heroicons/react/24/outline'

// Dynamically import Leaflet components like live map
const MapContainer = dynamic(() => import('react-leaflet').then(mod => mod.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import('react-leaflet').then(mod => mod.TileLayer), { ssr: false })
const Marker = dynamic(() => import('react-leaflet').then(mod => mod.Marker), { ssr: false })
const Polyline = dynamic(() => import('react-leaflet').then(mod => mod.Polyline), { ssr: false })
const Popup = dynamic(() => import('react-leaflet').then(mod => mod.Popup), { ssr: false })

import 'leaflet/dist/leaflet.css'

// MapController component like live map
const MapController = ({ center, zoom }: { center: [number, number]; zoom: number }) => {
  // Import useMap inside component to avoid SSR issues
  const { useMap } = require('react-leaflet')
  const map = useMap()
  useEffect(() => {
    map.setView(center, zoom)
  }, [center, zoom, map])
  return null
}

// Fix for default markers
const createIcon = () => {
  if (typeof window !== 'undefined') {
    const L = require('leaflet')
    delete L.Icon.Default.prototype._getIconUrl
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
      iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
      shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    })
  }
}

interface Route {
  id: string
  name: string
  distance: string
  duration: string
  traffic: 'light' | 'moderate' | 'heavy'
  tolls: boolean
  coordinates: { lat: number; lng: number }[]
  color: string
}

interface DriverMapProps {
  currentLocation: { lat: number; lng: number }
  currentOrder: any
}

export default function DriverMap({ currentLocation, currentOrder }: DriverMapProps) {
  const [selectedRoute, setSelectedRoute] = useState<string>('route1')
  const [routes, setRoutes] = useState<Route[]>([])

  useEffect(() => {
    createIcon()
    if (!currentOrder) return

    const generatedRoutes: Route[] = [
      {
        id: 'route1',
        name: 'Fastest Route',
        distance: '8.5 km',
        duration: '25 mins',
        traffic: 'light',
        tolls: false,
        coordinates: [
          { lat: currentLocation.lat, lng: currentLocation.lng },
          { lat: currentLocation.lat + 0.002, lng: currentLocation.lng + 0.003 },
          { lat: currentLocation.lat + 0.005, lng: currentLocation.lng + 0.006 },
          { lat: currentLocation.lat + 0.008, lng: currentLocation.lng + 0.008 },
          { lat: currentLocation.lat + 0.010, lng: currentLocation.lng + 0.011 },
          { lat: currentLocation.lat + 0.012, lng: currentLocation.lng + 0.014 },
          { lat: 17.4380, lng: 78.4560 }
        ],
        color: '#3B82F6'
      },
      {
        id: 'route2',
        name: 'Shortest Distance',
        distance: '7.2 km',
        duration: '30 mins',
        traffic: 'moderate',
        tolls: false,
        coordinates: [
          { lat: currentLocation.lat, lng: currentLocation.lng },
          { lat: currentLocation.lat + 0.001, lng: currentLocation.lng + 0.002 },
          { lat: currentLocation.lat + 0.003, lng: currentLocation.lng + 0.004 },
          { lat: currentLocation.lat + 0.006, lng: currentLocation.lng + 0.007 },
          { lat: currentLocation.lat + 0.008, lng: currentLocation.lng + 0.010 },
          { lat: 17.4380, lng: 78.4560 }
        ],
        color: '#10B981'
      },
      {
        id: 'route3',
        name: 'Avoid Traffic',
        distance: '9.1 km',
        duration: '28 mins',
        traffic: 'light',
        tolls: false,
        coordinates: [
          { lat: currentLocation.lat, lng: currentLocation.lng },
          { lat: currentLocation.lat - 0.001, lng: currentLocation.lng + 0.002 },
          { lat: currentLocation.lat + 0.002, lng: currentLocation.lng + 0.004 },
          { lat: currentLocation.lat + 0.004, lng: currentLocation.lng + 0.006 },
          { lat: currentLocation.lat + 0.007, lng: currentLocation.lng + 0.008 },
          { lat: currentLocation.lat + 0.009, lng: currentLocation.lng + 0.010 },
          { lat: currentLocation.lat + 0.011, lng: currentLocation.lng + 0.012 },
          { lat: 17.4380, lng: 78.4560 }
        ],
        color: '#F59E0B'
      },
      {
        id: 'route4',
        name: 'Highway Route',
        distance: '11.2 km',
        duration: '22 mins',
        traffic: 'moderate',
        tolls: true,
        coordinates: [
          { lat: currentLocation.lat, lng: currentLocation.lng },
          { lat: currentLocation.lat - 0.002, lng: currentLocation.lng + 0.001 },
          { lat: currentLocation.lat + 0.001, lng: currentLocation.lng + 0.003 },
          { lat: currentLocation.lat + 0.003, lng: currentLocation.lng + 0.005 },
          { lat: currentLocation.lat + 0.006, lng: currentLocation.lng + 0.007 },
          { lat: currentLocation.lat + 0.008, lng: currentLocation.lng + 0.009 },
          { lat: currentLocation.lat + 0.010, lng: currentLocation.lng + 0.011 },
          { lat: 17.4380, lng: 78.4560 }
        ],
        color: '#EF4444'
      }
    ]

    setRoutes(generatedRoutes)
    setSelectedRoute('route1')
  }, [currentOrder, currentLocation])

  if (!currentOrder) {
    return (
      <div className="w-full h-full bg-gray-100 rounded-lg flex items-center justify-center">
        <div className="text-center">
          <MapPinIcon className="h-12 w-12 text-gray-400 mx-auto mb-2" />
          <p className="text-gray-500">No active order</p>
        </div>
      </div>
    )
  }

  const selectedRouteData = routes.find(r => r.id === selectedRoute)

  return (
    <div className="w-full h-full relative">
      {/* Real Leaflet Map like live map */}
      <div className="h-full w-full">
        <MapContainer
          style={{ height: '100%', width: '100%' }}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapController center={[currentLocation.lat, currentLocation.lng]} zoom={13} />
          
          {/* Current Location */}
          <Marker position={[currentLocation.lat, currentLocation.lng] as [number, number]}>
            <Popup>
              <div className="text-sm">
                <div className="font-semibold">Your Location</div>
                <div className="text-gray-600">{currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}</div>
              </div>
            </Popup>
          </Marker>

          {/* Pickup Location */}
          <Marker position={[currentLocation.lat + 0.01, currentLocation.lng + 0.01] as [number, number]}>
            <Popup>
              <div className="text-sm">
                <div className="font-semibold">Pickup Location</div>
                <div className="text-gray-600">{currentOrder.pickupAddress || 'GPS Pickup'}</div>
              </div>
            </Popup>
          </Marker>

          {/* Delivery Location */}
          <Marker position={[17.4380, 78.4560] as [number, number]}>
            <Popup>
              <div className="text-sm">
                <div className="font-semibold">Delivery Location</div>
                <div className="text-gray-600">{currentOrder.deliveryAddress}</div>
              </div>
            </Popup>
          </Marker>

          {/* Route Lines */}
          {selectedRouteData && (
            <Polyline
              positions={selectedRouteData.coordinates.map(coord => [coord.lat, coord.lng] as [number, number])}
              pathOptions={{
                color: selectedRouteData.color,
                weight: 4,
                opacity: 0.9,
                smoothFactor: 2,
                dashArray: "10, 5"
              }}
            />
          )}
        </MapContainer>
      </div>
      
      {/* Route Options Panel */}
      <div className="absolute bottom-4 left-4 right-4 bg-white rounded-lg shadow-xl max-h-64 overflow-y-auto" style={{ zIndex: 1000 }}>
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-900">Route Options</h3>
            <div className="flex items-center text-xs text-gray-500">
              <ClockIcon className="h-3 w-3 mr-1" />
              <span>Live traffic</span>
            </div>
          </div>
          
          <div className="space-y-2">
            {routes.map((route) => (
              <div
                key={route.id}
                onClick={() => setSelectedRoute(route.id)}
                className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                  selectedRoute === route.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center">
                      <div
                        className="w-3 h-3 rounded-full mr-2"
                        style={{ backgroundColor: route.color }}
                      ></div>
                      <span className="font-medium text-gray-900">{route.name}</span>
                      {route.tolls && (
                        <span className="ml-2 text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">Tolls</span>
                      )}
                    </div>
                    <div className="flex items-center mt-1 text-sm text-gray-600">
                      <span className="mr-3">{route.distance}</span>
                      <span className="mr-3">{route.duration}</span>
                      <div className="flex items-center">
                        <div className={`w-2 h-2 rounded-full mr-1 ${
                          route.traffic === 'light' ? 'bg-green-500' :
                          route.traffic === 'moderate' ? 'bg-yellow-500' : 'bg-red-500'
                        }`}></div>
                        <span className="text-xs">{route.traffic} traffic</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    {selectedRoute === route.id && (
                      <div className="bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-medium">
                        Selected
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {selectedRouteData && (
            <div className="mt-3 pt-3 border-t border-gray-200">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center text-gray-600">
                  <CurrencyDollarIcon className="h-4 w-4 mr-1" />
                  <span>Est. fare: ₹{150 + Math.floor(Math.random() * 50)}</span>
                </div>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700">
                  Start Navigation
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
