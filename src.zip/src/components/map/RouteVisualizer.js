
export default function RouteVisualizer(){
  return <div>Map Component</div>
}
