import { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import 'leaflet/dist/leaflet.css';

const Map = dynamic(() => import('react-leaflet').then((mod) => mod.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import('react-leaflet').then((mod) => mod.TileLayer), { ssr: false });
const Marker = dynamic(() => import('react-leaflet').then((mod) => mod.Marker), { ssr: false });
const Popup = dynamic(() => import('react-leaflet').then((mod) => mod.Popup), { ssr: false });

interface RoutesMapProps {
  vehicles?: Array<{
    id: string;
    name: string;
    driver: string;
    status: string;
    location: { lat: number; lng: number };
  }>;
}

export function RoutesMap({ vehicles = [] }: RoutesMapProps) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    
    // Fix for default markers in Leaflet with webpack
    if (typeof window !== 'undefined' && (window as any).L) {
      delete (window as any).L.Icon.Default.prototype._getIconUrl;
      (window as any).L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
      });
    }
  }, []);

  if (!isClient) {
    return (
      <div className="h-96 bg-gray-100 rounded-lg flex items-center justify-center">
        <div className="text-gray-500">Loading map...</div>
      </div>
    );
  }

  // Default vehicles if none provided
  const defaultVehicles = [
    { id: 'TRK-001', name: 'Truck 001', driver: 'Raj Kumar', status: 'active', location: { lat: 19.0760, lng: 72.8777 } },
    { id: 'TRK-002', name: 'Truck 002', driver: 'Sarah Johnson', status: 'active', location: { lat: 19.0860, lng: 72.8877 } },
    { id: 'TRK-003', name: 'Truck 003', driver: 'Mike Chen', status: 'maintenance', location: { lat: 19.0660, lng: 72.8677 } }
  ];

  const displayVehicles = vehicles.length > 0 ? vehicles : defaultVehicles;

  return (
    <div className="h-96 rounded-lg overflow-hidden">
      <Map 
        center={[19.0760, 72.8777] as [number, number]} 
        zoom={12} 
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {/* Depot Marker */}
        <Marker position={[19.0760, 72.8777]}>
          <Popup>
            <div className="text-sm">
              <strong>Main Depot</strong><br />
              Mumbai, Maharashtra
            </div>
          </Popup>
        </Marker>

        {/* Vehicle Markers */}
        {displayVehicles.map((vehicle) => (
          <Marker 
            key={vehicle.id} 
            position={[vehicle.location.lat, vehicle.location.lng]}
          >
            <Popup>
              <div className="text-sm">
                <strong>{vehicle.id}</strong><br />
                Driver: {vehicle.driver}<br />
                Status: <span className={`capitalize ${vehicle.status === 'active' ? 'text-green-600' : 'text-yellow-600'}`}>
                  {vehicle.status}
                </span><br />
                Location: {vehicle.location.lat.toFixed(4)}, {vehicle.location.lng.toFixed(4)}
              </div>
            </Popup>
          </Marker>
        ))}
      </Map>
    </div>
  );
}
