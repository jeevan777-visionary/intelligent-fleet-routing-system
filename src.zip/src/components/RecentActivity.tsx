interface Activity {
  id: string;
  type: string;
  description: string;
  timestamp: string;
  user: string;
}

interface RecentActivityProps {
  activities?: Activity[];
}

export function RecentActivity({ activities = [] }: RecentActivityProps) {
  // Double safety: ensure activities is always an array
  const safeActivities = Array.isArray(activities) ? activities : [];
  
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'route_optimized':
        return '⚡';
      case 'order_created':
        return '📦';
      case 'vehicle_maintenance':
        return '🔧';
      case 'delivery_completed':
        return '✅';
      default:
        return '📄';
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'route_optimized':
        return 'text-success-600 bg-success-100';
      case 'order_created':
        return 'text-primary-600 bg-primary-100';
      case 'vehicle_maintenance':
        return 'text-warning-600 bg-warning-100';
      case 'delivery_completed':
        return 'text-success-600 bg-success-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="px-4 py-5 sm:p-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Recent Activity</h3>
        <div className="flow-root">
          <ul className="-mb-8">
            {safeActivities.map((activity, activityIdx) => (
              <li key={activity.id}>
                <div className="relative pb-8">
                  {activityIdx !== safeActivities.length - 1 ? (
                    <span
                      className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200"
                      aria-hidden="true"
                    />
                  ) : null}
                  <div className="relative flex items-start space-x-3">
                    <div className="relative">
                      <span
                        className={`h-8 w-8 rounded-full flex items-center justify-center ring-8 ring-white ${getActivityColor(
                          activity.type
                        )}`}
                      >
                        {getActivityIcon(activity.type)}
                      </span>
                    </div>
                    <div className="min-w-0 flex-1 py-1.5">
                      <div className="text-sm text-gray-500">
                        <span className="font-medium text-gray-900">{activity.user}</span>{' '}
                        {activity.description}
                      </div>
                      <div className="text-xs text-gray-400 mt-1">
                        {formatTime(activity.timestamp)}
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
        {safeActivities.length === 0 && (
          <div className="text-center py-4 text-gray-500">
            No recent activity
          </div>
        )}
      </div>
    </div>
  );
}
