import { useState, useEffect } from 'react';

interface WorkingMapProps {
  vehicles?: Array<{
    id: string;
    name: string;
    driver: string;
    status: string;
    location: { lat: number; lng: number };
  }>;
}

export function WorkingMap({ vehicles = [] }: WorkingMapProps) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return (
      <div className="h-96 bg-gray-100 rounded-lg flex items-center justify-center">
        <div className="text-gray-500">Loading map...</div>
      </div>
    );
  }

  return (
    <div className="h-96 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg border-2 border-blue-200 relative overflow-hidden">
      {/* Map Background with Grid */}
      <div className="absolute inset-0 opacity-10">
        <div className="grid grid-cols-10 grid-rows-10 h-full">
          {Array.from({ length: 100 }).map((_, i) => (
            <div key={i} className="border border-gray-300"></div>
          ))}
        </div>
      </div>
      
      {/* Map Content */}
      <div className="relative h-full p-4">
        {/* Depot - Center */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center shadow-lg">
            <span className="text-white text-sm">🏢</span>
          </div>
          <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 bg-white rounded px-2 py-1 text-xs whitespace-nowrap shadow">
            Depot
          </div>
        </div>
        
        {/* Vehicle Markers */}
        {vehicles.map((vehicle, index) => {
          const positions = [
            { top: '20%', left: '15%' },  // Vehicle 1
            { top: '60%', left: '70%' },  // Vehicle 2
            { top: '30%', left: '45%' },  // Vehicle 3
          ];
          const pos = positions[index] || { top: '50%', left: '50%' };
          const isActive = vehicle.status === 'active';
          
          return (
            <div
              key={vehicle.id}
              className="absolute z-10"
              style={pos}
            >
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shadow-lg ${
                isActive ? 'bg-green-600 animate-pulse' : 'bg-yellow-600'
              }`}>
                <span className="text-white text-xs">
                  {isActive ? '🚚' : '🔧'}
                </span>
              </div>
              <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-white rounded px-2 py-1 text-xs whitespace-nowrap shadow-lg">
                <div className="font-bold text-xs">{vehicle.name}</div>
                <div className="text-gray-600 text-xs">{vehicle.driver}</div>
                <div className={`text-xs font-medium ${
                  isActive ? 'text-green-600' : 'text-yellow-600'
                }`}>
                  {isActive ? 'Active' : 'Maintenance'}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 bg-white rounded-lg p-3 shadow-lg z-30">
        <div className="text-sm font-semibold text-gray-900 mb-2">🗺️ Live GPS Map</div>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-blue-600 rounded-full flex items-center justify-center">
              <span className="text-white text-xs">🏢</span>
            </div>
            <span className="text-xs">Depot</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-green-600 rounded-full flex items-center justify-center">
              <span className="text-white text-xs">🚚</span>
            </div>
            <span className="text-xs">Active Vehicle</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-yellow-600 rounded-full flex items-center justify-center">
              <span className="text-white text-xs">🔧</span>
            </div>
            <span className="text-xs">Maintenance</span>
          </div>
        </div>
      </div>

      {/* Vehicle Status Panel */}
      <div className="absolute top-4 right-4 bg-white rounded-lg p-3 shadow-lg z-30">
        <div className="text-sm font-semibold text-gray-900 mb-2">📊 Vehicle Status</div>
        <div className="space-y-2">
          {vehicles.map((vehicle) => (
            <div key={vehicle.id} className="border-b pb-2">
              <div className="font-medium text-xs">{vehicle.name}</div>
              <div className="text-gray-600 text-xs">{vehicle.driver}</div>
              <div className={`text-xs font-medium px-2 py-1 rounded inline-block ${
                vehicle.status === 'active' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {vehicle.status === 'active' ? '🚚 Active' : '🔧 Maintenance'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Map Title */}
      <div className="absolute top-4 left-4 bg-white rounded-lg px-3 py-2 shadow-lg z-30">
        <div className="text-sm font-bold text-gray-900">🗺️ Mumbai Delivery Area</div>
        <div className="text-xs text-gray-600">Real-time GPS Tracking</div>
      </div>
    </div>
  );
}
