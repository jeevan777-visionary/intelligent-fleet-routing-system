import { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import 'leaflet/dist/leaflet.css';

// Fix for default markers in Leaflet with webpack
if (typeof window !== 'undefined' && (window as any).L) {
  delete (window as any).L.Icon.Default.prototype._getIconUrl;
  (window as any).L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  });
}

const Map = dynamic(() => import('react-leaflet').then((mod) => mod.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import('react-leaflet').then((mod) => mod.TileLayer), { ssr: false });
const Marker = dynamic(() => import('react-leaflet').then((mod) => mod.Marker), { ssr: false });
const Popup = dynamic(() => import('react-leaflet').then((mod) => mod.Popup), { ssr: false });
const Polyline = dynamic(() => import('react-leaflet').then((mod) => mod.Polyline), { ssr: false });

interface RouteVisualizationMapProps {
  showBeforeAfter?: boolean;
}

export function RouteVisualizationMap({ showBeforeAfter = true }: RouteVisualizationMapProps) {
  const [isClient, setIsClient] = useState(false);
  const [showOptimized, setShowOptimized] = useState(true);

  useEffect(() => {
    setIsClient(true);
    
    // Fix for default markers in Leaflet with webpack
    if (typeof window !== 'undefined' && (window as any).L) {
      delete (window as any).L.Icon.Default.prototype._getIconUrl;
      (window as any).L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
      });
    }
  }, []);

  if (!isClient) {
    return (
      <div className="h-96 bg-gray-100 rounded-lg flex items-center justify-center">
        <div className="text-gray-500">Loading route visualization...</div>
      </div>
    );
  }

  // Delivery locations (customers)
  const deliveryLocations = [
    { id: 'depot', name: 'Main Depot', lat: 19.0760, lng: 72.8777, type: 'depot' },
    { id: 'customer1', name: 'Customer A - Mumbai', lat: 19.0860, lng: 72.8877, type: 'customer' },
    { id: 'customer2', name: 'Customer B - Pune', lat: 18.5204, lng: 73.8567, type: 'customer' },
    { id: 'customer3', name: 'Customer C - Thane', lat: 19.2183, lng: 72.9781, type: 'customer' },
    { id: 'customer4', name: 'Customer D - Navi Mumbai', lat: 19.0330, lng: 73.0297, type: 'customer' },
  ];

  // Inefficient route (3 days) - zigzag pattern
  const inefficientRoute = [
    [19.0760, 72.8777], // Depot
    [19.0860, 72.8877], // Customer A
    [18.5204, 73.8567], // Customer B (far away)
    [19.2183, 72.9781], // Customer C (backtracking)
    [19.0330, 73.0297], // Customer D
    [19.0760, 72.8777], // Back to depot
  ];

  // Optimized route (1.5 days) - logical sequence
  const optimizedRoute = [
    [19.0760, 72.8777], // Depot
    [19.0330, 73.0297], // Customer D (closest)
    [19.0860, 72.8877], // Customer A
    [19.2183, 72.9781], // Customer C
    [18.5204, 73.8567], // Customer B (farthest, last)
    [19.0760, 72.8777], // Back to depot
  ];

  const currentRoute = showOptimized ? optimizedRoute : inefficientRoute;
  const routeColor = showOptimized ? '#10b981' : '#ef4444';
  const routeInfo = showOptimized 
    ? { distance: '45 km', time: '1.5 days', savings: '35%' }
    : { distance: '69 km', time: '3 days', savings: '0%' };

  return (
    <div className="space-y-4">
      {/* Route Comparison Toggle */}
      {showBeforeAfter && (
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowOptimized(false)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                !showOptimized 
                  ? 'bg-red-600 text-white' 
                  : 'bg-white text-gray-700 border border-gray-300'
              }`}
            >
              Before: 3 Days (Inefficient)
            </button>
            <button
              onClick={() => setShowOptimized(true)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                showOptimized 
                  ? 'bg-green-600 text-white' 
                  : 'bg-white text-gray-700 border border-gray-300'
              }`}
            >
              After: 1.5 Days (Optimized)
            </button>
          </div>
          <div className="text-sm text-gray-600">
            Distance: {routeInfo.distance} | Time: {routeInfo.time}
          </div>
        </div>
      )}

      {/* Map */}
      <div className="h-96 rounded-lg overflow-hidden border-2 border-gray-200">
        <Map 
          center={[19.0760, 72.8777] as [number, number]} 
          zoom={10} 
          style={{ height: '100%', width: '100%' }}
          scrollWheelZoom={false}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          {/* Route Line */}
          <Polyline
            positions={currentRoute}
            color={routeColor}
            weight={4}
            opacity={0.8}
            dashArray={!showOptimized ? "10, 10" : undefined}
          />
          
          {/* Markers */}
          {deliveryLocations.map((location) => (
            <Marker 
              key={location.id} 
              position={[location.lat, location.lng]}
            >
              <Popup>
                <div className="text-sm">
                  <strong>{location.name}</strong>
                  <br />
                  {location.type === 'depot' ? 'Starting Point' : 'Delivery Location'}
                </div>
              </Popup>
            </Marker>
          ))}
        </Map>
      </div>

      {/* Route Statistics */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg border">
          <div className="text-sm text-gray-500">Total Distance</div>
          <div className={`text-lg font-bold ${showOptimized ? 'text-green-600' : 'text-red-600'}`}>
            {routeInfo.distance}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg border">
          <div className="text-sm text-gray-500">Delivery Time</div>
          <div className={`text-lg font-bold ${showOptimized ? 'text-green-600' : 'text-red-600'}`}>
            {routeInfo.time}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg border">
          <div className="text-sm text-gray-500">Cost Savings</div>
          <div className={`text-lg font-bold ${showOptimized ? 'text-green-600' : 'text-gray-600'}`}>
            {routeInfo.savings}
          </div>
        </div>
      </div>
    </div>
  );
}
