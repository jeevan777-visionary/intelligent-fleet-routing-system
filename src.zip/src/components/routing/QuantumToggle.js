
export default function QuantumToggle(){
  return <button>Hybrid Mode</button>
}
