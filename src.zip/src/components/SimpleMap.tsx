import { useState, useEffect } from 'react';

interface SimpleMapProps {
  vehicles?: Array<{
    id: string;
    name: string;
    driver: string;
    status: string;
    location: { lat: number; lng: number };
  }>;
}

export function SimpleMap({ vehicles = [] }: SimpleMapProps) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return (
      <div className="h-96 bg-gray-100 rounded-lg flex items-center justify-center">
        <div className="text-gray-500">Loading map...</div>
      </div>
    );
  }

  return (
    <div className="h-96 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg border-2 border-blue-300 relative overflow-hidden">
      {/* Map Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-green-100 opacity-50"></div>
      
      {/* Map Grid */}
      <div className="absolute inset-0 grid grid-cols-8 grid-rows-8 gap-1 p-4">
        {/* Depot */}
        <div className="col-start-4 row-start-4 bg-blue-600 rounded-full w-8 h-8 flex items-center justify-center z-10">
          <span className="text-white text-xs font-bold">🏢</span>
        </div>
        
        {/* Vehicle Markers */}
        {vehicles.map((vehicle, index) => {
          const col = ((index + 1) % 6) + 1;
          const row = Math.floor(((index + 1) / 6)) + 2;
          const isActive = vehicle.status === 'active';
          
          return (
            <div 
              key={vehicle.id}
              className={`col-start-${col} row-start-${row} ${
                isActive ? 'bg-green-600' : 'bg-yellow-600'
              } rounded-full w-6 h-6 flex items-center justify-center animate-pulse z-10`}
            >
              <span className="text-white text-xs font-bold">
                {isActive ? '🚚' : '🏍'}
              </span>
            </div>
          );
        })}
      </div>

      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 bg-white rounded-lg p-3 shadow-lg z-20">
        <div className="text-xs font-semibold text-gray-900 mb-2">Live GPS Tracking</div>
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
            <span className="text-xs">Depot</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-600 rounded-full"></div>
            <span className="text-xs">Active Vehicle</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-600 rounded-full"></div>
            <span className="text-xs">Idle Vehicle</span>
          </div>
        </div>
      </div>

      {/* Vehicle Info Overlay */}
      <div className="absolute top-4 right-4 bg-white rounded-lg p-3 shadow-lg max-w-xs z-20">
        <div className="text-xs font-semibold text-gray-900 mb-2">Active Vehicles</div>
        <div className="space-y-2">
          {vehicles.map((vehicle) => (
            <div key={vehicle.id} className="text-xs">
              <div className="font-medium">{vehicle.name}</div>
              <div className="text-gray-600">{vehicle.driver}</div>
              <div className={`px-2 py-1 rounded text-xs ${
                vehicle.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
              }`}>
                {vehicle.status}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
